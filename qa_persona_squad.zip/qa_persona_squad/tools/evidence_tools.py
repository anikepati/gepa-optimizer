"""Evidence Collector tools.

These tools are read-only data acquisition. The EvidenceCollector agent
uses them to assemble the qa_evidence bundle that downstream agents
reason against. None of these tools issue judgments.
"""

from __future__ import annotations

import hashlib
import json
import pathlib
import statistics
from datetime import datetime, timezone
from typing import Any

import yaml

# -----------------------------------------------------------------------------
# Paths — resolved once at import. In production these become env vars or DI.
# -----------------------------------------------------------------------------
ROOT = pathlib.Path(__file__).resolve().parent.parent
PROJECTS_DIR = ROOT / "config" / "projects"
SCHEMAS_DIR = ROOT / "config" / "schemas"
STORAGE_DIR = ROOT / "storage"
AUDIT_DIR = STORAGE_DIR / "audit"
RULES_DIR = STORAGE_DIR / "rules"

for d in (STORAGE_DIR, AUDIT_DIR, RULES_DIR):
    d.mkdir(parents=True, exist_ok=True)


# =============================================================================
# Project profile
# =============================================================================
def load_project_profile(project_id: str) -> dict[str, Any]:
    """Load the project profile YAML for the given project_id.

    Returns the profile dict on success, or {"error": ...} if missing.
    The agent's hard constraint forces FAIL when error is returned, so
    we don't raise — we surface the error structurally.
    """
    profile_path = PROJECTS_DIR / f"{project_id}.yaml"
    if not profile_path.exists():
        return {
            "error": "no_profile",
            "project_id": project_id,
            "searched_path": str(profile_path),
        }
    try:
        return yaml.safe_load(profile_path.read_text())
    except yaml.YAMLError as e:
        return {"error": "invalid_yaml", "project_id": project_id, "detail": str(e)}


# =============================================================================
# Pipeline outputs (read from session.state via passthrough)
# =============================================================================
def fetch_pipeline_outputs(
    state_keys: dict[str, str],
    session_state: dict[str, Any],
) -> dict[str, Any]:
    """Pull each pipeline stage's output from session.state.

    state_keys maps stage name -> session.state key (per project profile).
    Missing keys are flagged but do not raise — the reasoner needs to
    know what is missing.
    """
    outputs: dict[str, Any] = {}
    missing: list[str] = []
    for stage, key in state_keys.items():
        if key in session_state:
            outputs[stage] = session_state[key]
        else:
            missing.append(f"{stage}:{key}")
    return {"outputs": outputs, "missing_keys": missing}


# =============================================================================
# Source files (the original pipeline inputs)
# =============================================================================
def fetch_source_file(file_ref: str) -> dict[str, Any]:
    """Return parsed source file metadata + a small sample.

    The reasoner uses this for row count reconciliation and spot-checks
    against ingestion output.
    """
    path = pathlib.Path(file_ref)
    if not path.exists():
        return {"error": "file_not_found", "file_ref": file_ref}

    raw = path.read_bytes()
    checksum = hashlib.sha256(raw).hexdigest()

    # Lightweight row count + sample. Real implementation should dispatch
    # by extension (csv, json, xlsx, pipe-delimited for EDR v8.x).
    text = raw.decode("utf-8", errors="replace")
    lines = [ln for ln in text.splitlines() if ln.strip()]

    sample_rows = lines[:10]
    schema_version = "unknown"
    if lines and lines[0].startswith("#schema:"):
        schema_version = lines[0].split(":", 1)[1].strip()

    return {
        "file_ref": file_ref,
        "row_count": max(0, len(lines) - 1),  # minus header
        "checksum": checksum,
        "schema_version": schema_version,
        "sample_rows": sample_rows,
        "size_bytes": len(raw),
    }


# =============================================================================
# Regulatory schemas (used by validate_schema in reasoning_tools)
# =============================================================================
def fetch_regulatory_schema(schema_ref: str) -> dict[str, Any]:
    """Load a schema YAML. schema_ref is a relative path under config/."""
    # schema_ref looks like 'schemas/edr_alert_v2.yaml' — strip leading
    # 'schemas/' since SCHEMAS_DIR is already config/schemas.
    rel = schema_ref.removeprefix("schemas/")
    path = SCHEMAS_DIR / rel
    if not path.exists():
        return {"error": "schema_not_found", "schema_ref": schema_ref}
    try:
        return yaml.safe_load(path.read_text())
    except yaml.YAMLError as e:
        return {"error": "invalid_schema_yaml", "detail": str(e)}


# =============================================================================
# Rule library (the regulatory rules cited by classifications)
# =============================================================================
def fetch_rule_library(framework: str, version: str = "current") -> dict[str, Any]:
    """Return the regulatory rule library for the framework.

    The reasoner uses this to verify that classification rule_ids
    actually exist and are not deprecated.
    """
    rules_file = RULES_DIR / f"{framework.lower()}_{version}.yaml"
    if not rules_file.exists():
        # Seed with a minimal stub so the system is functional out of the
        # box. Production deployments wire this to a rule management
        # system (Collibra, internal rule store, etc.).
        return _stub_rule_library(framework)
    return yaml.safe_load(rules_file.read_text())


def _stub_rule_library(framework: str) -> dict[str, Any]:
    """Minimal in-memory rule library. Replace with real source."""
    common = {
        "BSA": {
            "rules": {
                "EDR-CLS-RULE-001": {"name": "Structuring Pattern", "active": True},
                "EDR-CLS-RULE-002": {"name": "High-Velocity Wire", "active": True},
                "EDR-CLS-RULE-003": {"name": "Cash-to-Wire Ratio", "active": True},
            },
            "deprecated_rules": ["EDR-DEPRECATED-007"],
            "applicability": {"alert_types": ["WIRE", "CASH", "STRUCTURING"]},
        },
        "FinCEN_SAR": {
            "rules": {"SAR-FILE-001": {"name": "SAR Filing Required", "active": True}},
            "deprecated_rules": [],
            "applicability": {"alert_types": ["SAR"]},
        },
        "FinCEN_CTR": {
            "rules": {"CTR-10K-001": {"name": "$10K Threshold", "active": True}},
            "deprecated_rules": [],
            "applicability": {"case_types": ["CASH"]},
        },
        "OFAC": {
            "rules": {"OFAC-SDN-001": {"name": "SDN Match", "active": True}},
            "deprecated_rules": [],
            "applicability": {"case_types": ["WIRE", "PAYMENT"]},
        },
    }
    return common.get(framework, {"rules": {}, "deprecated_rules": []})


# =============================================================================
# Historical baseline
# =============================================================================
def fetch_baseline(project_id: str, lookback_runs: int = 5) -> dict[str, Any]:
    """Return last N runs' aggregate scores for drift detection.

    Reads from storage/audit/<project_id>/*.yaml. If fewer than
    `lookback_runs` exist, drift detection is disabled.
    """
    project_audit_dir = AUDIT_DIR / project_id
    if not project_audit_dir.exists():
        return {
            "lookback_runs": 0,
            "score_mean": 0.0,
            "score_stddev": 0.0,
            "common_findings": [],
            "drift_detection_enabled": False,
            "reason": "no_prior_runs",
        }

    audit_files = sorted(project_audit_dir.glob("*.yaml"), reverse=True)[:lookback_runs]
    runs: list[dict[str, Any]] = []
    for f in audit_files:
        try:
            runs.append(yaml.safe_load(f.read_text()))
        except yaml.YAMLError:
            continue

    if len(runs) < 2:
        return {
            "lookback_runs": len(runs),
            "score_mean": runs[0]["findings_summary"]["aggregate_score"] if runs else 0.0,
            "score_stddev": 0.0,
            "common_findings": [],
            "drift_detection_enabled": False,
            "reason": "insufficient_runs",
        }

    scores = [r["findings_summary"]["aggregate_score"] for r in runs]
    return {
        "lookback_runs": len(runs),
        "score_mean": statistics.mean(scores),
        "score_stddev": statistics.stdev(scores),
        "common_findings": _top_recurring_rules(runs),
        "drift_detection_enabled": True,
        "runs": [
            {
                "run_id": r["run_id"],
                "verdict": r["verdict"],
                "aggregate_score": r["findings_summary"]["aggregate_score"],
            }
            for r in runs
        ],
    }


def _top_recurring_rules(runs: list[dict[str, Any]], top_n: int = 5) -> list[str]:
    """Find rule_ids that appear in findings across multiple runs."""
    from collections import Counter

    counter: Counter[str] = Counter()
    for run in runs:
        rules = run.get("findings_summary", {}).get("recurring_rule_ids", [])
        counter.update(rules)
    return [rule for rule, _ in counter.most_common(top_n)]


# =============================================================================
# Tamper-evidence
# =============================================================================
def hash_evidence_bundle(evidence_bundle: dict[str, Any]) -> dict[str, str]:
    """Produce a deterministic SHA-256 hash of the evidence bundle.

    Used in audit_record.evidence_hash for tamper-evidence. The aggregator
    re-hashes during verdict assembly; if it differs from collector's
    hash, the bundle was modified mid-pipeline (S1 finding).
    """
    canonical = json.dumps(evidence_bundle, sort_keys=True, default=str)
    digest = hashlib.sha256(canonical.encode()).hexdigest()
    return {
        "algorithm": "sha256",
        "hash": digest,
        "bundle_size_bytes": len(canonical),
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }
