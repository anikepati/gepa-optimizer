"""Verdict Aggregator tools.

These tools roll structured findings into a regulator-defensible verdict
with severity weighting, SLA metrics, and a signed audit record.
"""

from __future__ import annotations

import pathlib
from datetime import datetime, timezone
from typing import Any

import yaml

ROOT = pathlib.Path(__file__).resolve().parent.parent
AUDIT_DIR = ROOT / "storage" / "audit"


# =============================================================================
# Severity-weighted scoring
# =============================================================================
SEVERITY_WEIGHTS = {"S1": 10, "S2": 5, "S3": 2, "S4": 1}


def weight_findings(per_stage_findings: dict[str, Any]) -> dict[str, Any]:
    """Compute severity-weighted scores per stage and aggregate."""
    per_stage_scores: dict[str, dict[str, Any]] = {}
    s_counts = {"S1": 0, "S2": 0, "S3": 0, "S4": 0}
    aggregate = 0

    stages = per_stage_findings.get("per_stage_findings", []) \
        if isinstance(per_stage_findings, dict) else per_stage_findings

    for stage_data in stages:
        stage_name = stage_data.get("stage", "unknown")
        findings = stage_data.get("findings", [])
        stage_score = 0
        stage_counts = {"S1": 0, "S2": 0, "S3": 0, "S4": 0}
        for f in findings:
            sev = f.get("severity", "S4")
            w = SEVERITY_WEIGHTS.get(sev, 1)
            stage_score += w
            stage_counts[sev] = stage_counts.get(sev, 0) + 1
            s_counts[sev] = s_counts.get(sev, 0) + 1
        per_stage_scores[stage_name] = {
            "score": stage_score,
            "counts": stage_counts,
            "finding_count": len(findings),
        }
        aggregate += stage_score

    return {
        "per_stage": per_stage_scores,
        "aggregate": aggregate,
        "severity_counts": s_counts,
        "weights_applied": SEVERITY_WEIGHTS,
    }


# =============================================================================
# SLA metrics
# =============================================================================
def compute_sla_metrics(
    per_stage_findings: dict[str, Any],
    project_profile: dict[str, Any],
    review_started_at: str,
    review_completed_at: str,
) -> dict[str, Any]:
    """Compute coverage, high-risk review %, and review latency."""
    stages = per_stage_findings.get("per_stage_findings", []) \
        if isinstance(per_stage_findings, dict) else per_stage_findings

    rules_by_stage = project_profile.get("stage_specific_rules", {})
    rules_total = sum(len(v) for v in rules_by_stage.values())
    rules_evaluated = sum(len(s.get("rules_checked", [])) for s in stages)
    coverage = (rules_evaluated / rules_total * 100) if rules_total else 0.0

    # High-risk coverage: aggregate across stages that recorded sampling.
    high_risk_count = 0
    high_risk_reviewed = 0
    for s in stages:
        sr = s.get("sampling_record") or {}
        high_risk_count += sr.get("high_risk_count", 0)
        high_risk_reviewed += sr.get("high_risk_reviewed", 0)

    if high_risk_count > 0:
        hr_pct = high_risk_reviewed / high_risk_count * 100
    else:
        hr_pct = 100.0  # vacuously true if no high-risk items

    latency_ms = _latency_ms(review_started_at, review_completed_at)

    return {
        "coverage_pct": round(coverage, 2),
        "high_risk_review_pct": round(hr_pct, 2),
        "review_latency_ms": latency_ms,
        "rules_evaluated": rules_evaluated,
        "rules_total": rules_total,
    }


def _latency_ms(start_iso: str, end_iso: str) -> int:
    try:
        s = datetime.fromisoformat(start_iso.replace("Z", "+00:00"))
        e = datetime.fromisoformat(end_iso.replace("Z", "+00:00"))
        return int((e - s).total_seconds() * 1000)
    except (ValueError, TypeError):
        return 0


# =============================================================================
# Audit record (the durable, regulator-facing artifact)
# =============================================================================
def render_audit_record(
    run_id: str,
    project_id: str,
    verdict: str,
    verdict_reasons: list[str],
    severity_scores: dict[str, Any],
    baseline_comparison: dict[str, Any],
    sla_metrics: dict[str, Any],
    evidence_hash: str,
    per_stage_findings: dict[str, Any],
) -> dict[str, Any]:
    """Render and persist the audit record to durable storage.

    Returns the record. Side effect: writes to
    storage/audit/<project_id>/<run_id>.yaml.
    """
    s_counts = severity_scores.get("severity_counts", {})

    # Defensibility check — every S1/S2 finding must have evidence_refs
    # AND non-empty reasoning. If anything fails this bar, we cannot
    # call the verdict regulator-defensible.
    defensible = _check_defensibility(per_stage_findings)

    # Recurring rule_ids surfaced in this run, for future drift baselines
    recurring_ids = _extract_recurring_rule_ids(per_stage_findings)

    record = {
        "schema_version": "qa-audit-1.0",
        "run_id": run_id,
        "project_id": project_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict,
        "verdict_reasons": verdict_reasons,
        "evidence_hash": evidence_hash,
        "findings_summary": {
            "s1_count": s_counts.get("S1", 0),
            "s2_count": s_counts.get("S2", 0),
            "s3_count": s_counts.get("S3", 0),
            "s4_count": s_counts.get("S4", 0),
            "aggregate_score": severity_scores.get("aggregate", 0),
            "per_stage_scores": severity_scores.get("per_stage", {}),
            "recurring_rule_ids": recurring_ids,
        },
        "baseline_comparison": {
            "z_score": baseline_comparison.get("z_score"),
            "drift_detected": baseline_comparison.get("drift_detected", False),
            "baseline_mean": baseline_comparison.get("baseline_mean"),
            "baseline_stddev": baseline_comparison.get("baseline_stddev"),
        },
        "sla_metrics": sla_metrics,
        "signed_by": "QAReviewSquad",
        "regulator_defensible": defensible,
    }

    # Persist
    project_audit_dir = AUDIT_DIR / project_id
    project_audit_dir.mkdir(parents=True, exist_ok=True)
    out_path = project_audit_dir / f"{run_id}.yaml"
    out_path.write_text(yaml.safe_dump(record, sort_keys=False))

    return {
        "record": record,
        "persisted_to": str(out_path),
        "regulator_defensible": defensible,
    }


def _check_defensibility(per_stage_findings: dict[str, Any]) -> bool:
    """Every S1/S2 finding must have non-empty evidence_refs and reasoning."""
    stages = per_stage_findings.get("per_stage_findings", []) \
        if isinstance(per_stage_findings, dict) else per_stage_findings
    for stage in stages:
        for f in stage.get("findings", []):
            if f.get("severity") in ("S1", "S2"):
                if not f.get("evidence_refs"):
                    return False
                if not (f.get("reasoning") or "").strip():
                    return False
    return True


def _extract_recurring_rule_ids(per_stage_findings: dict[str, Any]) -> list[str]:
    stages = per_stage_findings.get("per_stage_findings", []) \
        if isinstance(per_stage_findings, dict) else per_stage_findings
    return list({f.get("rule_id") for s in stages for f in s.get("findings", [])
                 if f.get("rule_id")})
