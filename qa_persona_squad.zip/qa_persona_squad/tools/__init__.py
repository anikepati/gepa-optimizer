"""QA squad tools package.

Three tool modules, one per agent mode:
- evidence_tools: data acquisition for the EvidenceCollector
- reasoning_tools: validation and sampling for the StageReasoner
- aggregation_tools: scoring and audit record for the VerdictAggregator
"""

from tools.evidence_tools import (
    load_project_profile,
    fetch_source_file,
    fetch_pipeline_outputs,
    fetch_regulatory_schema,
    fetch_rule_library,
    fetch_baseline,
    hash_evidence_bundle,
)
from tools.reasoning_tools import (
    validate_schema,
    sample_decisions,
    cross_check_aggregations,
    compare_to_baseline,
    lookup_regulatory_rule,
)
from tools.aggregation_tools import (
    weight_findings,
    compute_sla_metrics,
    render_audit_record,
)

__all__ = [
    # evidence
    "load_project_profile",
    "fetch_source_file",
    "fetch_pipeline_outputs",
    "fetch_regulatory_schema",
    "fetch_rule_library",
    "fetch_baseline",
    "hash_evidence_bundle",
    # reasoning
    "validate_schema",
    "sample_decisions",
    "cross_check_aggregations",
    "compare_to_baseline",
    "lookup_regulatory_rule",
    # aggregation
    "weight_findings",
    "compute_sla_metrics",
    "render_audit_record",
]
