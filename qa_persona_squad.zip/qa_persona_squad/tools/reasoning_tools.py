"""Stage Reasoner tools.

These tools transform fetched evidence into structured findings. They
do not issue verdicts — that is the aggregator's job. Each tool is
deterministic given the same inputs, which is critical for audit
reproducibility.
"""

from __future__ import annotations

import hashlib
import random
import re
from datetime import datetime, timezone
from typing import Any


# =============================================================================
# Schema validation
# =============================================================================
def validate_schema(
    records: list[dict[str, Any]],
    schema: dict[str, Any],
) -> dict[str, Any]:
    """Validate records against a schema definition.

    Returns a structured result with per-record violations. The reasoner
    uses this output to construct findings; the tool itself emits no
    findings (it has no severity context).
    """
    if not records:
        return {
            "records_checked": 0,
            "violations": [],
            "violation_count": 0,
            "violation_rate": 0.0,
        }

    required = schema.get("required_fields", [])
    field_types = schema.get("field_types", {})
    constraints = schema.get("constraints", {})

    violations: list[dict[str, Any]] = []
    for idx, rec in enumerate(records):
        rec_violations = _validate_one(rec, required, field_types, constraints)
        if rec_violations:
            violations.append({
                "record_index": idx,
                "record_id": _get_record_id(rec),
                "violations": rec_violations,
            })

    return {
        "schema_version": schema.get("schema_version", "unknown"),
        "records_checked": len(records),
        "violations": violations,
        "violation_count": len(violations),
        "violation_rate": len(violations) / len(records),
    }


def _validate_one(
    rec: dict[str, Any],
    required: list[str],
    field_types: dict[str, str],
    constraints: dict[str, Any],
) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []

    # Required-field check
    for field in required:
        if field not in rec or rec[field] in (None, ""):
            out.append({"type": "missing_required", "field": field})

    # Type check
    type_map = {
        "string": str, "integer": int, "number": (int, float),
        "boolean": bool, "list": list, "dict": dict,
    }
    for field, expected_type in field_types.items():
        if field not in rec or rec[field] is None:
            continue
        py_type = type_map.get(expected_type)
        if py_type and not isinstance(rec[field], py_type):
            out.append({
                "type": "wrong_type",
                "field": field,
                "expected": expected_type,
                "got": type(rec[field]).__name__,
            })

    # Constraint check
    for field, c in constraints.items():
        if field not in rec or rec[field] is None:
            continue
        val = rec[field]
        if "min" in c and isinstance(val, (int, float)) and val < c["min"]:
            out.append({"type": "below_min", "field": field, "min": str(c["min"])})
        if "max" in c and isinstance(val, (int, float)) and val > c["max"]:
            out.append({"type": "above_max", "field": field, "max": str(c["max"])})
        if "enum" in c and val not in c["enum"]:
            out.append({"type": "not_in_enum", "field": field, "got": str(val)})
        if "pattern" in c and isinstance(val, str) and not re.match(c["pattern"], val):
            out.append({"type": "pattern_mismatch", "field": field})
        if "min_length" in c and isinstance(val, str) and len(val) < c["min_length"]:
            out.append({"type": "below_min_length", "field": field})
    return out


def _get_record_id(rec: dict[str, Any]) -> str:
    for key in ("alert_id", "case_id", "report_id", "filing_id", "id"):
        if key in rec:
            return str(rec[key])
    return "<no_id>"


# =============================================================================
# Stratified sampling
# =============================================================================
def sample_decisions(
    decisions: list[dict[str, Any]],
    sampling_policy: dict[str, int],
    high_risk_threshold: dict[str, Any],
    run_id: str,
) -> dict[str, Any]:
    """Stratified deterministic sampling.

    High-risk decisions get 100% (always). Medium and low get the
    project-defined percentages. Sampling is reproducible via run_id seed.
    """
    high_risk = [d for d in decisions if _matches_threshold(d, high_risk_threshold)]
    non_high = [d for d in decisions if d not in high_risk]

    medium_pct = sampling_policy.get("medium_risk_pct", 25)
    low_pct = sampling_policy.get("low_risk_pct", 10)

    # Borderline: within 20% of threshold (approximation; for numeric
    # thresholds only — categorical thresholds skip this stratification)
    medium_risk, low_risk = _split_medium_low(non_high, high_risk_threshold)

    rng = _seeded_rng(run_id)
    medium_sample = _take_pct(medium_risk, medium_pct, rng)
    low_sample = _take_pct(low_risk, low_pct, rng)

    sampled_ids = (
        [_get_record_id(d) for d in high_risk]
        + [_get_record_id(d) for d in medium_sample]
        + [_get_record_id(d) for d in low_sample]
    )

    return {
        "selection_method": "stratified_deterministic",
        "run_id": run_id,
        "total_decisions": len(decisions),
        "high_risk_count": len(high_risk),
        "high_risk_reviewed": len(high_risk),  # always 100%
        "medium_risk_count": len(medium_risk),
        "medium_risk_sampled": len(medium_sample),
        "low_risk_count": len(low_risk),
        "low_risk_sampled": len(low_sample),
        "total_sampled": len(sampled_ids),
        "sampled_ids": sampled_ids,
        "sample_records": {
            "high_risk": high_risk,
            "medium_risk": medium_sample,
            "low_risk": low_sample,
        },
    }


def _matches_threshold(record: dict[str, Any], threshold: dict[str, Any]) -> bool:
    field = threshold.get("field")
    op = threshold.get("operator")
    val = threshold.get("value")
    if field not in record:
        return False
    rec_val = record[field]
    if op == ">=":
        return isinstance(rec_val, (int, float)) and rec_val >= val
    if op == ">":
        return isinstance(rec_val, (int, float)) and rec_val > val
    if op == "<=":
        return isinstance(rec_val, (int, float)) and rec_val <= val
    if op == "<":
        return isinstance(rec_val, (int, float)) and rec_val < val
    if op == "==":
        return rec_val == val
    if op == "in":
        return rec_val in (val if isinstance(val, list) else [val])
    return False


def _split_medium_low(
    records: list[dict[str, Any]],
    threshold: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    field = threshold.get("field")
    op = threshold.get("operator")
    val = threshold.get("value")

    if op not in (">=", ">") or not isinstance(val, (int, float)):
        # Categorical thresholds — treat all non-high as low
        return [], records

    medium_cutoff = val * 0.8  # within 20% below high-risk
    medium = [r for r in records
              if isinstance(r.get(field), (int, float)) and r[field] >= medium_cutoff]
    low = [r for r in records if r not in medium]
    return medium, low


def _seeded_rng(run_id: str) -> random.Random:
    seed = int(hashlib.sha256(run_id.encode()).hexdigest()[:16], 16)
    return random.Random(seed)


def _take_pct(items: list[Any], pct: int, rng: random.Random) -> list[Any]:
    if not items:
        return []
    n = max(1, int(len(items) * pct / 100))
    n = min(n, len(items))
    return rng.sample(items, n)


# =============================================================================
# Cross-stage aggregation reconciliation
# =============================================================================
def cross_check_aggregations(
    expected_aggregates: dict[str, int],
    observed_aggregates: dict[str, int],
    tolerance: int = 0,
) -> dict[str, Any]:
    """Compare expected vs observed counts across pipeline stages.

    Used for example to verify SAR-eligible count in report stage matches
    classification stage's flagged count, or input row count vs output.
    """
    deltas: dict[str, dict[str, Any]] = {}
    out_of_tolerance: list[str] = []

    for key, expected in expected_aggregates.items():
        observed = observed_aggregates.get(key, 0)
        delta = observed - expected
        within = abs(delta) <= tolerance
        deltas[key] = {
            "expected": expected,
            "observed": observed,
            "delta": delta,
            "within_tolerance": within,
        }
        if not within:
            out_of_tolerance.append(key)

    return {
        "deltas": deltas,
        "all_within_tolerance": not out_of_tolerance,
        "out_of_tolerance_keys": out_of_tolerance,
        "tolerance": tolerance,
    }


# =============================================================================
# Drift comparison
# =============================================================================
def compare_to_baseline(
    current_score: float,
    baseline: dict[str, Any],
    sigma: float = 2.0,
) -> dict[str, Any]:
    """Compute drift z-score against baseline."""
    if not baseline.get("drift_detection_enabled"):
        return {
            "drift_detected": False,
            "drift_disabled": True,
            "reason": baseline.get("reason", "unknown"),
            "current_score": current_score,
        }

    mean = baseline["score_mean"]
    stddev = baseline["score_stddev"]
    if stddev == 0:
        z = 0.0 if current_score == mean else float("inf")
    else:
        z = (current_score - mean) / stddev

    return {
        "drift_detected": abs(z) > sigma,
        "drift_disabled": False,
        "current_score": current_score,
        "baseline_mean": mean,
        "baseline_stddev": stddev,
        "z_score": z,
        "sigma_threshold": sigma,
    }


# =============================================================================
# Rule lookup
# =============================================================================
def lookup_regulatory_rule(
    rule_id: str,
    rule_library: dict[str, Any],
) -> dict[str, Any]:
    """Verify a rule_id exists and is active in the loaded rule library."""
    rules = rule_library.get("rules", {})
    deprecated = rule_library.get("deprecated_rules", [])

    if rule_id in deprecated:
        return {
            "found": True,
            "active": False,
            "deprecated": True,
            "rule_id": rule_id,
        }
    if rule_id in rules:
        rule = rules[rule_id]
        return {
            "found": True,
            "active": rule.get("active", True),
            "deprecated": False,
            "rule_id": rule_id,
            "name": rule.get("name"),
        }
    return {
        "found": False,
        "active": False,
        "deprecated": False,
        "rule_id": rule_id,
    }
