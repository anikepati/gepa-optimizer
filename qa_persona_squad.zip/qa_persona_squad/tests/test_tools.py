"""Unit tests for QA squad tools.

These test the deterministic logic — schema validation, sampling,
aggregation scoring, drift detection — without requiring google-adk
or an LLM. They are the safety net for the "reasoning and aggregation"
layer that the agent depends on.

Run:
    pytest tests/ -v
"""

from __future__ import annotations

import pytest

from tools.aggregation_tools import (
    SEVERITY_WEIGHTS,
    compute_sla_metrics,
    render_audit_record,
    weight_findings,
)
from tools.evidence_tools import (
    fetch_baseline,
    fetch_regulatory_schema,
    hash_evidence_bundle,
    load_project_profile,
)
from tools.reasoning_tools import (
    compare_to_baseline,
    cross_check_aggregations,
    lookup_regulatory_rule,
    sample_decisions,
    validate_schema,
)


# =============================================================================
# Project profile loading
# =============================================================================
class TestProjectProfile:
    def test_load_edr_profile(self):
        profile = load_project_profile("edr")
        assert "error" not in profile
        assert profile["project_id"] == "edr"
        assert "stage_specific_rules" in profile

    def test_load_rro_profile(self):
        profile = load_project_profile("rro")
        assert "error" not in profile
        assert profile["project_id"] == "rro"

    def test_missing_profile_returns_error(self):
        profile = load_project_profile("nonexistent_project")
        assert profile.get("error") == "no_profile"


# =============================================================================
# Schema validation
# =============================================================================
class TestSchemaValidation:
    def test_clean_records_no_violations(self):
        schema = fetch_regulatory_schema("schemas/edr_alert_v2.yaml")
        clean = [{
            "alert_id": "A1", "customer_id": "C1", "alert_type": "WIRE",
            "created_at": "2026-04-30T10:00:00Z", "risk_score": 50,
            "account_number": "ACCT1", "status": "OPEN",
            "entity_name": "E", "transaction_amt": 100.0,
        }]
        result = validate_schema(clean, schema)
        assert result["violation_count"] == 0

    def test_missing_required_field_caught(self):
        schema = fetch_regulatory_schema("schemas/edr_alert_v2.yaml")
        bad = [{"alert_id": "A1"}]  # missing nearly everything
        result = validate_schema(bad, schema)
        assert result["violation_count"] == 1
        v_types = {v["type"] for v in result["violations"][0]["violations"]}
        assert "missing_required" in v_types

    def test_risk_score_above_max_caught(self):
        schema = fetch_regulatory_schema("schemas/edr_alert_v2.yaml")
        bad = [{
            "alert_id": "A1", "customer_id": "C1", "alert_type": "WIRE",
            "created_at": "2026-04-30T10:00:00Z", "risk_score": 150,  # over 100
            "account_number": "ACCT1", "status": "OPEN",
            "entity_name": "E", "transaction_amt": 100.0,
        }]
        result = validate_schema(bad, schema)
        v_types = {v["type"] for v in result["violations"][0]["violations"]}
        assert "above_max" in v_types

    def test_invalid_status_enum_caught(self):
        schema = fetch_regulatory_schema("schemas/edr_alert_v2.yaml")
        bad = [{
            "alert_id": "A1", "customer_id": "C1", "alert_type": "WIRE",
            "created_at": "2026-04-30T10:00:00Z", "risk_score": 50,
            "account_number": "ACCT1", "status": "INVALID_STATUS",
            "entity_name": "E", "transaction_amt": 100.0,
        }]
        result = validate_schema(bad, schema)
        v_types = {v["type"] for v in result["violations"][0]["violations"]}
        assert "not_in_enum" in v_types


# =============================================================================
# Stratified sampling
# =============================================================================
class TestSampling:
    def test_high_risk_always_100_pct(self):
        decisions = (
            [{"alert_id": f"H{i}", "risk_score": 90} for i in range(5)]
            + [{"alert_id": f"L{i}", "risk_score": 30} for i in range(50)]
        )
        result = sample_decisions(
            decisions=decisions,
            sampling_policy={"medium_risk_pct": 25, "low_risk_pct": 10},
            high_risk_threshold={"field": "risk_score", "operator": ">=", "value": 80},
            run_id="test-run-1",
        )
        assert result["high_risk_count"] == 5
        assert result["high_risk_reviewed"] == 5

    def test_sampling_reproducible_by_run_id(self):
        decisions = [{"alert_id": f"L{i}", "risk_score": 30} for i in range(100)]
        kwargs = dict(
            sampling_policy={"medium_risk_pct": 25, "low_risk_pct": 10},
            high_risk_threshold={"field": "risk_score", "operator": ">=", "value": 80},
            run_id="test-run-1",
        )
        r1 = sample_decisions(decisions=decisions, **kwargs)
        r2 = sample_decisions(decisions=decisions, **kwargs)
        assert r1["sampled_ids"] == r2["sampled_ids"]

    def test_different_run_ids_produce_different_samples(self):
        decisions = [{"alert_id": f"L{i}", "risk_score": 30} for i in range(100)]
        common = dict(
            sampling_policy={"medium_risk_pct": 25, "low_risk_pct": 10},
            high_risk_threshold={"field": "risk_score", "operator": ">=", "value": 80},
        )
        r1 = sample_decisions(decisions=decisions, run_id="run-A", **common)
        r2 = sample_decisions(decisions=decisions, run_id="run-B", **common)
        # Same total count, different selections (very high probability)
        assert r1["sampled_ids"] != r2["sampled_ids"]

    def test_categorical_high_risk_threshold(self):
        decisions = (
            [{"case_id": f"P0-{i}", "case_priority": "P0"} for i in range(3)]
            + [{"case_id": f"P3-{i}", "case_priority": "P3"} for i in range(20)]
        )
        result = sample_decisions(
            decisions=decisions,
            sampling_policy={"medium_risk_pct": 30, "low_risk_pct": 15},
            high_risk_threshold={"field": "case_priority", "operator": "in",
                                 "value": ["P0", "P1"]},
            run_id="test-run-cat",
        )
        assert result["high_risk_count"] == 3
        assert result["high_risk_reviewed"] == 3


# =============================================================================
# Cross-stage aggregation
# =============================================================================
class TestAggregationReconciliation:
    def test_matching_aggregates_pass(self):
        result = cross_check_aggregations(
            expected_aggregates={"sar_count": 3, "total": 50},
            observed_aggregates={"sar_count": 3, "total": 50},
        )
        assert result["all_within_tolerance"]

    def test_mismatching_aggregates_caught(self):
        result = cross_check_aggregations(
            expected_aggregates={"sar_count": 3},
            observed_aggregates={"sar_count": 5},
        )
        assert not result["all_within_tolerance"]
        assert "sar_count" in result["out_of_tolerance_keys"]

    def test_tolerance_respected(self):
        result = cross_check_aggregations(
            expected_aggregates={"total": 100},
            observed_aggregates={"total": 102},
            tolerance=5,
        )
        assert result["all_within_tolerance"]


# =============================================================================
# Drift detection
# =============================================================================
class TestDrift:
    def test_no_drift_within_2_sigma(self):
        baseline = {
            "drift_detection_enabled": True,
            "score_mean": 10.0, "score_stddev": 2.0,
        }
        result = compare_to_baseline(11.0, baseline)
        assert not result["drift_detected"]
        assert abs(result["z_score"]) < 2.0

    def test_drift_detected_beyond_2_sigma(self):
        baseline = {
            "drift_detection_enabled": True,
            "score_mean": 10.0, "score_stddev": 2.0,
        }
        result = compare_to_baseline(20.0, baseline)
        assert result["drift_detected"]
        assert result["z_score"] > 2.0

    def test_drift_disabled_when_baseline_unavailable(self):
        baseline = {"drift_detection_enabled": False, "reason": "no_prior_runs"}
        result = compare_to_baseline(15.0, baseline)
        assert result["drift_disabled"]
        assert not result["drift_detected"]


# =============================================================================
# Rule lookup
# =============================================================================
class TestRuleLookup:
    @pytest.fixture
    def rule_lib(self):
        return {
            "rules": {"R-001": {"name": "Test", "active": True}},
            "deprecated_rules": ["R-OLD-001"],
        }

    def test_active_rule_found(self, rule_lib):
        result = lookup_regulatory_rule("R-001", rule_lib)
        assert result["found"] and result["active"]

    def test_deprecated_rule_flagged(self, rule_lib):
        result = lookup_regulatory_rule("R-OLD-001", rule_lib)
        assert result["found"] and result["deprecated"]
        assert not result["active"]

    def test_unknown_rule_not_found(self, rule_lib):
        result = lookup_regulatory_rule("R-DOES-NOT-EXIST", rule_lib)
        assert not result["found"]


# =============================================================================
# Severity weighting
# =============================================================================
class TestSeverityWeighting:
    def test_weights_match_rubric(self):
        assert SEVERITY_WEIGHTS == {"S1": 10, "S2": 5, "S3": 2, "S4": 1}

    def test_aggregate_score_computed_correctly(self):
        findings = {
            "per_stage_findings": [
                {"stage": "ingestion", "findings": [
                    {"severity": "S1"}, {"severity": "S2"},
                ]},
                {"stage": "classification", "findings": [
                    {"severity": "S3"}, {"severity": "S3"}, {"severity": "S4"},
                ]},
            ]
        }
        result = weight_findings(findings)
        # S1=10, S2=5, S3=2, S3=2, S4=1 = 20
        assert result["aggregate"] == 20
        assert result["severity_counts"]["S1"] == 1
        assert result["severity_counts"]["S3"] == 2


# =============================================================================
# Defensibility
# =============================================================================
class TestAuditRecord:
    def test_defensible_when_evidence_complete(self, tmp_path, monkeypatch):
        from tools import aggregation_tools
        monkeypatch.setattr(aggregation_tools, "AUDIT_DIR", tmp_path)

        per_stage = {"per_stage_findings": [
            {"stage": "ingestion", "findings": [
                {"severity": "S2", "rule_id": "R1",
                 "evidence_refs": ["alerts[0]"],
                 "reasoning": "Evidence shows X therefore Y"},
            ]},
        ]}
        result = aggregation_tools.render_audit_record(
            run_id="r-1", project_id="edr", verdict="PASS_WITH_FINDINGS",
            verdict_reasons=["one S2 finding"],
            severity_scores={"aggregate": 5,
                             "severity_counts": {"S1": 0, "S2": 1, "S3": 0, "S4": 0},
                             "per_stage": {}},
            baseline_comparison={"z_score": 0.5, "drift_detected": False},
            sla_metrics={"coverage_pct": 100.0, "high_risk_review_pct": 100.0},
            evidence_hash="abc123",
            per_stage_findings=per_stage,
        )
        assert result["regulator_defensible"]

    def test_not_defensible_when_evidence_missing(self, tmp_path, monkeypatch):
        from tools import aggregation_tools
        monkeypatch.setattr(aggregation_tools, "AUDIT_DIR", tmp_path)

        per_stage = {"per_stage_findings": [
            {"stage": "ingestion", "findings": [
                {"severity": "S1", "rule_id": "R1",
                 "evidence_refs": [],  # missing!
                 "reasoning": "X happened"},
            ]},
        ]}
        result = aggregation_tools.render_audit_record(
            run_id="r-2", project_id="edr", verdict="FAIL",
            verdict_reasons=["S1 finding"],
            severity_scores={"aggregate": 10,
                             "severity_counts": {"S1": 1, "S2": 0, "S3": 0, "S4": 0},
                             "per_stage": {}},
            baseline_comparison={"z_score": 0.0, "drift_detected": False},
            sla_metrics={"coverage_pct": 100.0, "high_risk_review_pct": 100.0},
            evidence_hash="abc",
            per_stage_findings=per_stage,
        )
        assert not result["regulator_defensible"]


# =============================================================================
# Evidence hashing
# =============================================================================
class TestEvidenceHashing:
    def test_hash_is_deterministic(self):
        bundle = {"a": 1, "b": [2, 3], "c": {"d": "e"}}
        h1 = hash_evidence_bundle(bundle)
        h2 = hash_evidence_bundle(bundle)
        assert h1["hash"] == h2["hash"]
        assert h1["algorithm"] == "sha256"

    def test_hash_changes_on_content_change(self):
        h1 = hash_evidence_bundle({"a": 1})
        h2 = hash_evidence_bundle({"a": 2})
        assert h1["hash"] != h2["hash"]

    def test_hash_independent_of_key_order(self):
        h1 = hash_evidence_bundle({"a": 1, "b": 2})
        h2 = hash_evidence_bundle({"b": 2, "a": 1})
        assert h1["hash"] == h2["hash"]
