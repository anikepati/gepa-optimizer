"""QA Squad Factory.

Builds the QAReviewSquad SequentialAgent (EvidenceCollector ->
StageReasoner -> VerdictAggregator) from the YAML persona config.

The persona file (config/agents/qa_persona.yaml) defines all three
modes. Each mode becomes a sub-agent with a scoped instruction and a
scoped toolset. Adding a new project requires no changes here — just
drop a profile in config/projects/.
"""

from __future__ import annotations

import pathlib
from typing import Any

import yaml

# ADK imports — graceful fallback so the module imports cleanly even
# when google-adk isn't installed yet (e.g. during unit tests of the
# tool layer). The factory itself requires ADK to actually run.
try:
    from google.adk.agents import LlmAgent
    from google.adk.agents.sequential_agent import SequentialAgent
    from google.adk.tools import FunctionTool

    ADK_AVAILABLE = True
except ImportError:  # pragma: no cover
    LlmAgent = None  # type: ignore
    SequentialAgent = None  # type: ignore
    FunctionTool = None  # type: ignore
    ADK_AVAILABLE = False

import tools as qa_tools

ROOT = pathlib.Path(__file__).resolve().parent
PERSONA_CFG = ROOT / "config" / "agents" / "qa_persona.yaml"


# =============================================================================
# Mode -> tool wiring. This is the only place modes know about tools.
# Adding a new tool to a mode is one line here; the persona instruction
# automatically picks it up via the tool name when the agent calls it.
# =============================================================================
MODE_TOOLS: dict[str, list[Any]] = {
    "evidence_collector": [
        qa_tools.load_project_profile,
        qa_tools.fetch_pipeline_outputs,
        qa_tools.fetch_source_file,
        qa_tools.fetch_regulatory_schema,
        qa_tools.fetch_rule_library,
        qa_tools.fetch_baseline,
        qa_tools.hash_evidence_bundle,
    ],
    "stage_reasoner": [
        qa_tools.validate_schema,
        qa_tools.sample_decisions,
        qa_tools.cross_check_aggregations,
        qa_tools.compare_to_baseline,
        qa_tools.lookup_regulatory_rule,
    ],
    "verdict_aggregator": [
        qa_tools.weight_findings,
        qa_tools.compute_sla_metrics,
        qa_tools.render_audit_record,
    ],
}


# =============================================================================
# Persona instruction builder
# =============================================================================
def _build_mode_instruction(persona: dict[str, Any], mode_key: str) -> str:
    """Compose a complete instruction string for one persona mode."""
    mode = persona["modes"][mode_key]
    identity = persona["identity"]

    parts: list[str] = [
        f"You are a {identity['role']}.",
        f"Experience: {identity['experience']}",
        "",
        "## Core Mindset (applies in every mode)",
        *[f"- {m}" for m in persona["mindset"]],
        "",
        f"## Your Mode: {mode_key}",
        "",
        "### Objective",
        mode["objective"].strip(),
    ]

    if "required_evidence" in mode:
        parts += ["", "### Required Evidence to Collect",
                  *[f"- {e}" for e in mode["required_evidence"]]]

    if "reasoning_protocol" in mode:
        parts += ["", "### Reasoning Protocol",
                  *[f"- {r}" for r in mode["reasoning_protocol"]]]

    if "aggregation_protocol" in mode:
        parts += ["", "### Aggregation Protocol",
                  *[f"- {a}" for a in mode["aggregation_protocol"]]]

    parts += [
        "",
        f"### Output (write to session.state['{mode['output_key']}'])",
        "Return JSON matching this schema:",
        "```yaml",
        yaml.safe_dump(mode["output_schema"], sort_keys=False).strip(),
        "```",
        "",
        "### Hard Constraints",
        *[f"- {c}" for c in mode["constraints"]],
        "",
        "### Workflow",
        "1. Read session.state['qa_project'] to identify the active project",
        "2. Read prior stage outputs from session.state",
        "3. Use your tools to fulfill the protocol above",
        "4. Emit the structured output — no prose, no preamble",
        "",
        "## Project Adaptation",
        "Your persona is constant. Project-specific rules, schemas,",
        "thresholds, and state keys come from the project profile loaded",
        "at runtime via load_project_profile. Apply BOTH the universal",
        "responsibilities encoded in this instruction AND every rule in",
        "the loaded profile's stage_specific_rules.",
    ]

    return "\n".join(parts)


# =============================================================================
# Single-mode agent factory
# =============================================================================
def build_mode_agent(mode_key: str, persona: dict[str, Any] | None = None):
    """Build a single LlmAgent for one persona mode.

    Useful for testing one mode in isolation, or if you want to swap
    modes in/out (e.g., an aggregator-only run on archived findings).
    """
    if not ADK_AVAILABLE:
        raise RuntimeError(
            "google-adk is not installed. `pip install google-adk` first."
        )

    if persona is None:
        persona = yaml.safe_load(PERSONA_CFG.read_text())["persona"]

    if mode_key not in persona["modes"]:
        raise KeyError(f"Mode '{mode_key}' not defined in persona config")
    if mode_key not in MODE_TOOLS:
        raise KeyError(f"No tools wired for mode '{mode_key}'")

    mode = persona["modes"][mode_key]
    instruction = _build_mode_instruction(persona, mode_key)

    tools = [FunctionTool(t) for t in MODE_TOOLS[mode_key]]

    return LlmAgent(
        name=f"QA_{mode_key}",
        model=yaml.safe_load(PERSONA_CFG.read_text()).get("model", "gemini-2.5-flash"),
        description=mode["objective"].strip().split("\n")[0],
        instruction=instruction,
        tools=tools,
        output_key=mode["output_key"],
    )


# =============================================================================
# Full QA squad factory
# =============================================================================
def build_qa_squad():
    """Build the full QAReviewSquad SequentialAgent.

    Order: evidence_collector -> stage_reasoner -> verdict_aggregator.
    Each writes to session.state via output_key, which the next agent
    reads. The aggregator's output (qa_verdict) is the durable result.
    """
    if not ADK_AVAILABLE:
        raise RuntimeError(
            "google-adk is not installed. `pip install google-adk` first."
        )

    cfg = yaml.safe_load(PERSONA_CFG.read_text())
    persona = cfg["persona"]

    sub_agents = [
        build_mode_agent("evidence_collector", persona),
        build_mode_agent("stage_reasoner", persona),
        build_mode_agent("verdict_aggregator", persona),
    ]

    return SequentialAgent(
        name="QAReviewSquad",
        description=cfg["description"],
        sub_agents=sub_agents,
    )
