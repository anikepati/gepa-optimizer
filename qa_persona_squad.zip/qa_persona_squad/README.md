# QA Persona Squad

A project-agnostic, config-driven QA review system for compliance
pipelines built on Google ADK. One persona, three modes, runs against
EDR, RRO, and any future pipeline by dropping a YAML profile.

## Architecture

```
QAReviewSquad (SequentialAgent)
├── EvidenceCollector  → output_key: qa_evidence
│   Tools: load_project_profile, fetch_pipeline_outputs,
│          fetch_source_file, fetch_regulatory_schema,
│          fetch_rule_library, fetch_baseline, hash_evidence_bundle
│
├── StageReasoner      → output_key: qa_findings
│   Tools: validate_schema, sample_decisions,
│          cross_check_aggregations, compare_to_baseline,
│          lookup_regulatory_rule
│
└── VerdictAggregator  → output_key: qa_verdict
    Tools: weight_findings, compute_sla_metrics, render_audit_record
```

The persona is one YAML file. Each mode is one section of that file.
Tool wiring is one dict. Project rules are one YAML per project.

## Repository Layout

```
qa_persona_squad/
├── config/
│   ├── agents/
│   │   └── qa_persona.yaml        # The persona (3 modes)
│   ├── projects/
│   │   ├── edr.yaml               # EDR project profile
│   │   └── rro.yaml               # RRO project profile
│   └── schemas/                   # Per-stage validation schemas
│       ├── edr_alert_v2.yaml
│       ├── edr_classification.yaml
│       ├── edr_rro_report.yaml
│       ├── rro_case_v1.yaml
│       ├── rro_disposition.yaml
│       └── rro_filing.yaml
├── skills/
│   └── qa-reviewer-core/          # agentskills.io progressive disclosure
│       ├── SKILL.md
│       ├── references/
│       │   ├── severity_rubric.md
│       │   ├── sampling_method.md
│       │   └── drift_detection.md
│       └── assets/
│           ├── audit_record_schema.yaml
│           └── finding_template.yaml
├── tools/
│   ├── __init__.py
│   ├── evidence_tools.py          # Mode 1 tools
│   ├── reasoning_tools.py         # Mode 2 tools
│   └── aggregation_tools.py       # Mode 3 tools
├── tests/
│   └── test_tools.py              # Unit tests for the tool layer
├── storage/
│   └── audit/                     # Audit records persisted here
├── qa_squad_factory.py            # Builds the SequentialAgent from config
├── main.py                        # CLI entrypoint with EDR/RRO demos
├── requirements.txt
└── README.md
```

## Setup

```bash
pip install -r requirements.txt
export GOOGLE_API_KEY=your_key_here
```

## Running

Run the QA squad against a synthetic EDR pipeline:

```bash
python main.py --project edr
```

Same squad, RRO project:

```bash
python main.py --project rro
```

Inspect the synthetic state without invoking the LLM:

```bash
python main.py --project edr --dry-run
```

## Testing the Tool Layer

The reasoning and aggregation logic is fully testable without ADK or
an LLM. Schema validation, sampling determinism, drift detection,
severity weighting, and defensibility checks all have unit tests:

```bash
pytest tests/ -v
```

## Adding a New Project

Adding (e.g.) a KYC refresh pipeline:

1. Create `config/projects/kyc_refresh.yaml` with `state_keys`,
   `stage_specific_rules`, `sampling_policy`, `high_risk_threshold`,
   `fail_threshold`, and (optionally) drift settings.
2. Create the per-stage schemas under `config/schemas/`.
3. Set `session.state["qa_project"] = "kyc_refresh"` before running.

No agent code, no persona changes.

## Why Three Modes Instead of One Agent

A single agent doing fetch + reason + aggregate has nowhere to fail
gracefully. It hallucinates counts, asserts rules without lookup, and
issues PASS to seem agreeable. Splitting forces:

- The collector cannot judge — it can only fetch and log gaps.
- The reasoner cannot verdict — it can only produce findings with
  cited evidence.
- The aggregator cannot invent findings — it can only roll up what
  the reasoner wrote, with deterministic math.

This also gives you a clean resume story (ResumabilityConfig pattern):
if the reasoner fails mid-run, evidence is intact in session.state and
re-running starts from there — no re-fetch, no re-paying the data
acquisition cost.

## Audit Records

Every run produces a YAML audit record at
`storage/audit/<project_id>/<run_id>.yaml` containing the verdict,
severity counts, evidence hash, drift metrics, and SLA metrics.
Records are also the source of the historical baseline for future
runs' drift detection.

`regulator_defensible: true` is set ONLY if every S1 and S2 finding
has non-empty `evidence_refs` and non-empty `reasoning`.
