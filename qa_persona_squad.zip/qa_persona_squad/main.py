"""QA Persona Squad — entry point and usage examples.

Demonstrates two scenarios:
  1. EDR pipeline with QA squad appended
  2. RRO pipeline with the same QA squad — config-only difference

The squad itself is project-agnostic. The runtime difference is just
session.state["qa_project"] = "edr" vs "rro".

Run:
    python main.py --project edr
    python main.py --project rro
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
import uuid
from datetime import datetime, timezone
from typing import Any

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")
log = logging.getLogger("qa_squad.main")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


# =============================================================================
# Synthetic pipeline outputs (so the demo runs without real EDR/RRO data)
# Replace with your actual pipeline session.state in production.
# =============================================================================
def synthetic_edr_state() -> dict[str, Any]:
    return {
        "qa_project": "edr",
        "pipeline_run_id": f"edr-{uuid.uuid4().hex[:8]}",
        "review_started_at": _utc_now(),
        "normalized_alerts": [
            {
                "alert_id": f"ALERT-{i:04d}",
                "customer_id": f"CUST-{i % 50:04d}",
                "alert_type": "WIRE",
                "created_at": "2026-04-30T10:00:00Z",
                "risk_score": 90 if i < 3 else 45,
                "account_number": f"ACCT-{i:06d}",
                "status": "OPEN",
                "entity_name": f"Entity {i}",
                "transaction_amt": 12500.0 + i * 100,
            }
            for i in range(50)
        ],
        "classified_exceptions": [
            {
                "alert_id": f"ALERT-{i:04d}",
                "classification": "TRUE_POSITIVE" if i < 3 else "FALSE_POSITIVE",
                "rule_id": "EDR-CLS-RULE-001" if i < 3 else "EDR-CLS-RULE-002",
                "rationale": "Pattern matches structuring threshold per rule library",
                "classified_at": "2026-04-30T10:15:00Z",
                "sar_eligible": i < 3,
                "confidence": 0.92 if i < 3 else 0.71,
            }
            for i in range(50)
        ],
        "regulatory_report": {
            "report_id": f"RRO-{uuid.uuid4().hex[:8]}",
            "filing_entity": "ExampleBank NA",
            "period_start": "2026-04-01",
            "period_end": "2026-04-30",
            "jurisdiction": "US",
            "sar_eligible_count": 3,
            "total_alerts_reviewed": 50,
            "generated_at": _utc_now(),
            "filing_deadline": "2026-05-30",
        },
    }


def synthetic_rro_state() -> dict[str, Any]:
    return {
        "qa_project": "rro",
        "pipeline_run_id": f"rro-{uuid.uuid4().hex[:8]}",
        "review_started_at": _utc_now(),
        "normalized_cases": [
            {
                "case_id": f"CASE-{i:04d}",
                "customer_id": f"CUST-{i:04d}",
                "case_type": "CASH",
                "case_priority": "P0" if i < 2 else "P3",
                "currency": "USD",
                "amount_usd": 11000.0 + i * 50,
                "opened_at": "2026-04-30T08:00:00Z",
            }
            for i in range(30)
        ],
        "case_dispositions": [
            {
                "case_id": f"CASE-{i:04d}",
                "disposition": "FILE_CTR" if i < 2 else "NO_FILING",
                "rationale": "Aggregated cash deposits exceed CTR threshold",
                "dispositioned_at": "2026-04-30T08:30:00Z",
                "ofac_screened": True,
                "screening_timestamp": "2026-04-30T08:25:00Z",
                "ctr_eligible": i < 2,
                "aggregation_window": "24h",
            }
            for i in range(30)
        ],
        "rro_filing": {
            "filing_id": f"FILING-{uuid.uuid4().hex[:8]}",
            "filing_entity": "ExampleBank NA",
            "period_start": "2026-04-01",
            "period_end": "2026-04-30",
            "ctr_count": 2,
            "sar_count": 0,
            "filing_deadline": "2026-05-15",
            "generated_at": _utc_now(),
            "jurisdiction": "US",
        },
    }


# =============================================================================
# Run the QA squad
# =============================================================================
async def run_qa_squad(initial_state: dict[str, Any]) -> dict[str, Any]:
    """Run the QA squad against pre-populated session state.

    Requires google-adk installed. Returns the final session state which
    includes qa_evidence, qa_findings, and qa_verdict.
    """
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService

    from qa_squad_factory import build_qa_squad

    squad = build_qa_squad()
    session_service = InMemorySessionService()

    session = await session_service.create_session(
        app_name="qa_persona_squad",
        user_id="qa_runner",
        state=initial_state,
    )

    runner = Runner(
        agent=squad,
        app_name="qa_persona_squad",
        session_service=session_service,
    )

    log.info("Starting QA review for project=%s run_id=%s",
             initial_state["qa_project"], initial_state["pipeline_run_id"])

    # The squad runs sequentially; we drive it with a kickoff message
    # that points it at the session state.
    from google.genai import types
    kickoff = types.Content(
        role="user",
        parts=[types.Part(text=(
            f"Review the {initial_state['qa_project']} pipeline run "
            f"{initial_state['pipeline_run_id']}. Pipeline outputs are "
            "in session state. Produce a complete QA verdict."
        ))],
    )

    async for event in runner.run_async(
        user_id="qa_runner",
        session_id=session.id,
        new_message=kickoff,
    ):
        log.debug("event: agent=%s final=%s", event.author, event.is_final_response())

    session_after = await session_service.get_session(
        app_name="qa_persona_squad",
        user_id="qa_runner",
        session_id=session.id,
    )
    return dict(session_after.state)


# =============================================================================
# CLI
# =============================================================================
def main() -> int:
    parser = argparse.ArgumentParser(description="Run QA Persona Squad")
    parser.add_argument(
        "--project",
        choices=["edr", "rro"],
        default="edr",
        help="Project to review (matches config/projects/<id>.yaml)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print synthetic state without invoking the LLM agents",
    )
    args = parser.parse_args()

    state = synthetic_edr_state() if args.project == "edr" else synthetic_rro_state()

    if args.dry_run:
        import json
        print(json.dumps(state, indent=2, default=str))
        return 0

    try:
        final_state = asyncio.run(run_qa_squad(state))
    except RuntimeError as e:
        log.error("Run failed: %s", e)
        log.error("Tip: install google-adk and set GOOGLE_API_KEY before running")
        return 1

    verdict = final_state.get("qa_verdict")
    if verdict:
        log.info("=" * 60)
        log.info("VERDICT: %s", verdict.get("verdict"))
        log.info("Aggregate score: %s",
                 verdict.get("severity_scores", {}).get("aggregate"))
        log.info("Defensible: %s",
                 verdict.get("audit_record", {}).get("regulator_defensible"))
        log.info("=" * 60)
    else:
        log.warning("No qa_verdict produced — check agent logs")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
