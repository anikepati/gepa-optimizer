# Sampling Methodology

The QA reviewer uses stratified sampling driven by the project's
`sampling_policy` and `high_risk_threshold`. The goal is total coverage
of high-risk items and statistical coverage of the rest.

## Stratification

Records are stratified into three buckets based on the project's
`high_risk_threshold`:

- **High-risk** — matches the threshold (e.g., risk_score >= 80)
- **Medium-risk** — borderline (within 20% below high-risk cutoff)
- **Low-risk** — everything else

## Sampling Rates

Per project profile (`sampling_policy`):

- High-risk: ALWAYS 100%. No exceptions. Missing this is S1.
- Medium-risk: per `medium_risk_pct`
- Low-risk: per `low_risk_pct`

## Selection Method

Within each bucket below 100%, use **deterministic stratified random**
sampling seeded by `run_id`. This makes samples reproducible during
audit review.

```python
import hashlib, random

def deterministic_sample(items, pct, run_id):
    seed = int(hashlib.sha256(run_id.encode()).hexdigest()[:16], 16)
    rng = random.Random(seed)
    n = max(1, int(len(items) * pct / 100))
    return rng.sample(items, min(n, len(items)))
```

## Coverage Reporting

Every sampling decision must record:
- Sample size
- Selection method (always "stratified_deterministic")
- Sampled IDs (for reproducibility)
- High-risk count vs high-risk reviewed (must be equal)

## Common Failure Modes

- **High-risk slip** — a record qualifying as high-risk skipped due to
  threshold misapplication. Always S1.
- **Sampling collapse** — sample size = 0 because pct rounds down on
  small populations. Use `max(1, ...)` to enforce floor.
- **Non-deterministic seed** — sampling not reproducible. Audit
  reviewers cannot replicate. S2.
