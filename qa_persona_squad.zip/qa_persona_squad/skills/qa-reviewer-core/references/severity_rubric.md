# Severity Rubric

The severity assigned to a finding determines its weight in aggregate
scoring and its impact on the final verdict. Apply these definitions
strictly — when uncertain, escalate one level (e.g., borderline S2/S3
becomes S2).

## S1 — Critical (weight 10)

Regulatory failure, data integrity loss, or coverage breach. Triggers
automatic FAIL verdict regardless of other findings.

Examples:
- A high-risk alert (risk_score >= 80) skipped during sampling
- SAR-eligible count in report does not match classification stage
- Required regulatory field missing from filing
- Source row count does not reconcile with output (data loss)
- Classification cites a rule_id that does not exist in rule library
- OFAC-screened case missing screening_timestamp

## S2 — Major (weight 5)

Schema violation, missing rationale, or unexplained drift. Triggers at
minimum PASS_WITH_FINDINGS.

Examples:
- Date field not in ISO-8601 UTC format
- Classification rationale shorter than 20 characters
- Drift detected (z-score > 2) without baseline explanation
- Deprecated rule_id cited in classification
- risk_score outside 0-100 range
- Sampling completed but lower than configured percentage

## S3 — Minor (weight 2)

Edge case anomaly, formatting inconsistency, or non-blocking gap.

Examples:
- BOM present in v8.x export (cosmetic if data still parsed)
- Non-critical metadata field empty
- Aggregation delta within tolerance but unusually large
- Sample size at minimum threshold rather than recommended

## S4 — Trivial (weight 1)

Cosmetic, log-only, or informational.

Examples:
- Field ordering inconsistent with schema (data correct)
- Whitespace in optional descriptive fields
- Non-canonical timezone abbreviation in display strings

## Escalation Rules

- A finding affecting >5% of records escalates one severity level
- A finding affecting any high-risk item is at minimum S2
- Repeated occurrences across runs (per baseline) escalate one level
- If unsure between two levels, choose the higher
