# Drift Detection

The aggregator compares current run severity scores against a rolling
baseline of the last N runs (per `baseline_lookback_runs` in project
profile). Drift indicates the pipeline is producing different patterns
than recent history — could be input shift, code regression, or
genuine business change.

## Baseline Computation

For each project, baseline is computed as:

```
baseline_mean   = mean(aggregate_score for run in last N runs)
baseline_stddev = stddev(aggregate_score for run in last N runs)
```

Minimum N for stable baseline: 5 runs. Below that, drift detection is
disabled and noted in audit record.

## Drift Test

Z-score for current run:

```
z = (current_score - baseline_mean) / baseline_stddev
```

Drift triggers when `abs(z) > drift_sensitivity_sigma` (default 2.0).

## Interpretation

- **z > 2** — Score significantly higher than recent norm. More
  findings than usual. Investigate before issuing PASS.
- **z < -2** — Score significantly lower. Could indicate the QA
  process itself missed findings (e.g., fewer rules evaluated).
  Equally suspicious — verify rules_evaluated == rules_total.
- **|z| <= 2** — Within normal variance. No drift flag.

## When to Override Drift

Drift can be overridden ONLY with explicit reasoning in the verdict's
`verdict_reasons` field, e.g.:

- "Drift attributed to known schema change in EDR v9.2 release"
- "Increased findings due to new rule EDR-CLS-005 added this run"

Without explicit reasoning, drift_detected = true forces verdict to
PASS_WITH_FINDINGS at minimum.

## New Findings vs Recurring

The aggregator also tracks which findings are new vs recurring relative
to baseline. New high-severity findings are weighted more heavily than
recurring ones (which may indicate accepted risk).
