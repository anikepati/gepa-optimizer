---
name: qa-reviewer-core
description: |
  Use when reviewing the output of any compliance pipeline (EDR, RRO, or
  any project with a profile in config/projects/). Activate on mentions
  of "QA review", "validate pipeline", "audit", "review classification",
  or after any pipeline run completes. This skill is project-agnostic;
  project-specific rules come from the loaded project profile.
license: Proprietary
compatibility: Requires Python 3.11+, jsonschema, pyyaml
metadata:
  author: compliance-engineering
  version: "1.0.0"
  domain: compliance
  tier: core
  token-budget: "3200"
allowed-tools: Bash(python:*) Read
---

# QA Reviewer Core

Project-agnostic QA review skill for compliance pipelines. Implements
the agentskills.io progressive disclosure pattern: lightweight metadata
at startup, full instructions on activation, deep references on demand.

## Activation

Load this skill when:
- A pipeline run has completed and needs QA review
- User mentions "QA review", "validate", "audit", or "review verdict"
- Running as part of the QAReviewSquad SequentialAgent

Do NOT load when:
- The pipeline run has not produced session.state outputs yet
- No project profile has been set in session.state["qa_project"]

## Core Principles

The QA reviewer is split into three modes (collector, reasoner,
aggregator). Each mode has its own persona instruction, but all share
these principles:

1. **Evidence before judgment.** Never assert without fetched proof.
2. **Cite everything.** Every finding references rule_id and evidence.
3. **Risk-weight.** False negatives on high-risk items are P0.
4. **Reconcile counts.** Records in must equal records out plus drops.
5. **Schema-literal.** Required fields missing is FAIL, not a finding.

## Workflow Overview

```
EvidenceCollector  →  StageReasoner  →  VerdictAggregator
   (fetches)         (reasons)         (rolls up)
```

Each agent reads from session.state, writes its output via output_key,
and never overlaps responsibilities with the others.

## Severity Rubric (S1-S4)

See `references/severity_rubric.md` for the full rubric. Quick guide:

- **S1** — Regulatory failure, data integrity loss, or 100% high-risk
  coverage missed. Always FAIL.
- **S2** — Schema violation, missing rationale, drift detected.
  PASS_WITH_FINDINGS minimum.
- **S3** — Edge case anomaly, sampling gap, minor formatting.
- **S4** — Cosmetic, log-only.

## Sampling Methodology

See `references/sampling_method.md` for stratified sampling details.
High-risk items per project profile are reviewed at 100%; lower-risk
items are sampled per the project's sampling_policy.

## Audit Record Format

See `assets/audit_record_schema.yaml` for the canonical audit record
schema. Records are written via render_audit_record tool to durable
storage (storage/audit/<run_id>.yaml) plus a tamper-evidence hash.

## When to Reference Deeper Docs

- `references/severity_rubric.md` — when assigning severity to findings
- `references/sampling_method.md` — when designing or auditing samples
- `references/drift_detection.md` — when interpreting baseline z-scores
- `assets/audit_record_schema.yaml` — when rendering verdicts
- `assets/finding_template.yaml` — when constructing per-stage findings
