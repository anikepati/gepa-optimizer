"""Ralph + GEPA prompt optimizer for document extraction.

Public entry points:
  - build_optimizer_root_agent: assembles the agent graph (requires google-adk)
  - OptimizationSpec: run contract loaded from YAML
"""

from optimizer.spec import Budget, OptimizationSpec, TargetMetric


def build_optimizer_root_agent(*args, **kwargs):
    """Lazy proxy to optimizer.orchestrator.build_optimizer_root_agent.

    Deferred so submodules (spec, scoring, persistence) remain importable
    in environments without google-adk installed (e.g. unit tests).
    """
    from optimizer.orchestrator import build_optimizer_root_agent as _impl
    return _impl(*args, **kwargs)


__all__ = [
    "build_optimizer_root_agent",
    "Budget",
    "OptimizationSpec",
    "TargetMetric",
]
