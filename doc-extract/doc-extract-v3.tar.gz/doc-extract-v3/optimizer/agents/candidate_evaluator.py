"""Candidate evaluator agent.

For one candidate:
  1. For each dev doc: ingest → extract via candidate's schema → parse JSON
  2. F1 score per field
  3. LLM judge for incorrect fields
  4. Run custom validators on the extracted output
  5. Aggregate into objectives: mean_field_f1, mean_judge_score, validator_pass_rate

We use ParallelAgent at the outer level (one branch per candidate). Within
a candidate, the dev docs are evaluated in a thread pool because ADK's
ParallelAgent doesn't compose recursively well with shared state.

Each candidate writes results to its own state namespace keyed by candidate_id
to avoid races inside the parent ParallelAgent.

Failure isolation: each (candidate, doc) is wrapped in try/except. A failed
doc gets recorded as score=0 + error, but doesn't crash the candidate.
"""

from __future__ import annotations

import json
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
from typing import Any

import yaml

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types

from core.document_extractor import DocumentExtractor
from core.prompt_builder import PromptBuilder
from core.schema import ExtractionSchema
from optimizer import state_keys as K
from optimizer.llm_client import LLMCallable
from optimizer.persistence import repo
from optimizer.scoring import F1Scorer, JudgeScorer, pass_rate, run_validators

logger = logging.getLogger(__name__)


class CandidateEvaluatorAgent(BaseAgent):
    """Evaluates ONE candidate. Designed to be one branch of a ParallelAgent.

    Reads `gepa:candidates` and a candidate index passed via construction
    so each instance evaluates exactly one candidate slot.
    """

    def __init__(
        self,
        name: str,
        candidate_slot: int,
        extraction_llm: LLMCallable,
        judge_llm: LLMCallable,
        document_extractor: DocumentExtractor,
        prompt_template_path: str,
        max_parallel_docs: int = 4,
    ):
        super().__init__(name=name)
        self._slot = candidate_slot
        self._extraction_llm = extraction_llm
        self._judge_llm = judge_llm
        self._extractor = document_extractor
        self._template_path = prompt_template_path
        self._max_parallel = max_parallel_docs

    async def _run_async_impl(self, ctx: InvocationContext):
        state = ctx.session.state
        run_id = state.get(K.RUN_ID, "?")
        candidates = state.get(K.GEPA_CANDIDATES, []) or []
        if self._slot >= len(candidates):
            yield self._noop("slot out of range")
            return

        cand = candidates[self._slot]
        cand_id = cand["candidate_id"]
        schema_yaml = cand["schema_yaml"]

        # Load candidate schema
        try:
            schema = self._load_schema_from_yaml(schema_yaml)
        except Exception as e:
            logger.exception(f"[eval slot={self._slot}] bad schema: {e}")
            yield self._noop(f"schema load failed: {e}")
            return

        # Build PromptBuilder, allowing template_override from candidate metadata
        prompt_builder = self._build_prompt_builder(schema, cand)
        f1_scorer = F1Scorer(schema)
        judge = JudgeScorer(self._judge_llm)

        dev_set = state.get(K.RUN_DEV_SET, []) or []

        # Evaluate docs in parallel (thread pool - LLM calls are I/O bound)
        per_doc: dict[str, dict] = {}
        with ThreadPoolExecutor(max_workers=self._max_parallel) as pool:
            futures = {
                pool.submit(
                    self._eval_one_doc,
                    doc_record=d,
                    schema=schema,
                    schema_dict=yaml.safe_load(schema_yaml) or {},
                    prompt_builder=prompt_builder,
                    f1_scorer=f1_scorer,
                    judge=judge,
                    candidate_id=cand_id,
                    run_id=run_id,
                ): d for d in dev_set
            }
            for fut in as_completed(futures):
                doc = futures[fut]
                try:
                    per_doc[doc["name"]] = fut.result()
                except Exception as e:
                    logger.exception(f"[eval slot={self._slot}] doc={doc['name']}: {e}")
                    per_doc[doc["name"]] = {
                        "error": str(e),
                        "field_results": [],
                        "f1_mean": 0.0,
                        "judge_mean": 0.0,
                        "validator_pass_rate": 0.0,
                    }

        # Aggregate into objectives
        objectives = self._aggregate(per_doc)

        # Persist objectives on the candidate row
        repo.update_candidate_metrics(
            candidate_id=cand_id,
            objectives=objectives,
            field_scores=self._field_score_aggregate(per_doc),
        )
        repo.write_audit(run_id, "candidate_evaluated", {
            "candidate_id": cand_id, "objectives": objectives,
        })

        # Write to state under a slot-specific key. Aggregator merges later.
        slot_key = f"gepa:candidates:{self._slot}:results"
        state_delta = {
            slot_key: {
                "candidate_id": cand_id,
                "schema_yaml": schema_yaml,
                "objectives": objectives,
                "per_doc": per_doc,
            },
        }

        yield Event(
            author=self.name,
            content=types.Content(parts=[types.Part(
                text=f"Candidate {cand_id} F1={objectives.get('mean_field_f1', 0):.3f}"
            )]),
            actions=EventActions(state_delta=state_delta),
        )

    # ---------- per-doc work ----------

    def _eval_one_doc(
        self,
        doc_record: dict,
        schema: ExtractionSchema,
        schema_dict: dict,
        prompt_builder: PromptBuilder,
        f1_scorer: F1Scorer,
        judge: JudgeScorer,
        candidate_id: str,
        run_id: str,
    ) -> dict:
        doc_name = doc_record["name"]
        doc_path = Path(doc_record["path"])
        expected = doc_record["expected"]

        # Step 1: ingest doc
        try:
            content = doc_path.read_bytes()
            extracted_doc = self._extractor.extract(content, doc_path.name)
            doc_text = extracted_doc.text
        except Exception as e:
            repo.insert_evaluation(
                run_id=run_id, candidate_id=candidate_id,
                doc_name=doc_name, split="dev",
                f1_score=0.0, judge_score=0.0, validator_pass=False,
                field_results=None, raw_output=None, error=f"ingest: {e}",
            )
            return {"error": str(e), "field_results": [],
                    "f1_mean": 0.0, "judge_mean": 0.0, "validator_pass_rate": 0.0}

        # Step 2: extract via LLM
        try:
            sys_prompt = prompt_builder.build_system_prompt()
            user_prompt = prompt_builder.build_extraction_prompt(
                document_text=doc_text, use_chain_of_thought=True,
            )
            resp = self._extraction_llm(sys_prompt, user_prompt)
            actual = self._parse_json(resp.text)
        except Exception as e:
            repo.insert_evaluation(
                run_id=run_id, candidate_id=candidate_id,
                doc_name=doc_name, split="dev",
                f1_score=0.0, judge_score=0.0, validator_pass=False,
                field_results=None, raw_output=None, error=f"extract: {e}",
            )
            return {"error": str(e), "field_results": [],
                    "f1_mean": 0.0, "judge_mean": 0.0, "validator_pass_rate": 0.0}

        # Step 3: F1 score
        f1_doc = f1_scorer.score_doc(doc_name, actual, expected)
        field_results_dicts = [
            {
                "field_name": fr.field_name,
                "correct": fr.correct,
                "score": fr.score,
                "expected": fr.expected,
                "actual": fr.actual,
                "note": fr.note,
            }
            for fr in f1_doc.field_results
        ]
        f1_mean = (
            sum(fr.score for fr in f1_doc.field_results) / len(f1_doc.field_results)
            if f1_doc.field_results else 0.0
        )

        # Step 4: judge incorrect fields
        try:
            judge_results = judge.score_doc(doc_name, f1_doc.field_results, doc_text[:2000])
            judge_mean = (
                sum(j.score for j in judge_results.values()) / len(judge_results)
                if judge_results else 1.0
            )
        except Exception as e:
            logger.warning(f"judge error for {doc_name}: {e}")
            judge_results = {}
            judge_mean = f1_mean

        # Step 5: custom validators
        try:
            validator_results = run_validators(actual or {}, schema_dict)
            v_pass_rate = pass_rate(validator_results)
            v_pass = all(v.passed for v in validator_results)
        except Exception as e:
            logger.warning(f"validators error for {doc_name}: {e}")
            v_pass_rate = 1.0
            v_pass = True

        # Persist evaluation
        repo.insert_evaluation(
            run_id=run_id,
            candidate_id=candidate_id,
            doc_name=doc_name,
            split="dev",
            f1_score=f1_mean,
            judge_score=judge_mean,
            validator_pass=v_pass,
            field_results=field_results_dicts,
            raw_output=actual,
        )

        return {
            "field_results": field_results_dicts,
            "f1_mean": f1_mean,
            "judge_mean": judge_mean,
            "validator_pass_rate": v_pass_rate,
        }

    # ---------- helpers ----------

    @staticmethod
    def _load_schema_from_yaml(yaml_text: str) -> ExtractionSchema:
        # Write to a temp path because ExtractionSchema.from_yaml expects a file
        import tempfile, os
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_text)
            temp_path = f.name
        try:
            return ExtractionSchema.from_yaml(temp_path)
        finally:
            os.unlink(temp_path)

    def _build_prompt_builder(
        self, schema: ExtractionSchema, candidate: dict,
    ) -> PromptBuilder:
        """Build PromptBuilder, applying template_override if present in metadata."""
        template_override = (candidate.get("metadata") or {}).get("template_override")
        if not template_override:
            return PromptBuilder(schema=schema, template_path=self._template_path)

        # Write the override template to a temp file
        import tempfile
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.safe_dump(template_override, f, sort_keys=False)
            tmp = f.name
        return PromptBuilder(schema=schema, template_path=tmp)

    @staticmethod
    def _parse_json(text: str) -> dict | None:
        if not text:
            return None
        m_out = re.search(r"<output>(.*?)</output>", text, re.DOTALL)
        json_str = m_out.group(1).strip() if m_out else text
        json_str = re.sub(r"^```(?:json)?\s*", "", json_str.strip())
        json_str = re.sub(r"\s*```$", "", json_str)
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            pass
        m = re.search(r"\{.*\}", json_str, re.DOTALL)
        if not m:
            return None
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            return None

    @staticmethod
    def _aggregate(per_doc: dict) -> dict[str, float]:
        if not per_doc:
            return {"mean_field_f1": 0.0, "mean_judge_score": 0.0, "validator_pass_rate": 0.0}
        n = len(per_doc)
        f1_sum = sum(d.get("f1_mean", 0.0) for d in per_doc.values())
        judge_sum = sum(d.get("judge_mean", 0.0) for d in per_doc.values())
        v_sum = sum(d.get("validator_pass_rate", 0.0) for d in per_doc.values())
        return {
            "mean_field_f1": f1_sum / n,
            "mean_judge_score": judge_sum / n,
            "validator_pass_rate": v_sum / n,
        }

    @staticmethod
    def _field_score_aggregate(per_doc: dict) -> dict[str, float]:
        scores: dict[str, list[float]] = {}
        for d in per_doc.values():
            for fr in d.get("field_results", []) or []:
                scores.setdefault(fr["field_name"], []).append(float(fr.get("score", 0.0)))
        return {n: (sum(v) / len(v) if v else 0.0) for n, v in scores.items()}

    def _noop(self, msg: str) -> Event:
        return Event(
            author=self.name,
            content=types.Content(parts=[types.Part(text=f"noop: {msg}")]),
            actions=EventActions(state_delta={}),
        )
