"""Reflection agent.

Looks at the latest gepa:dev_results from the previous iteration's best
candidate (or the base schema, if iteration 0) and writes a one-paragraph
hypothesis about the dominant failure mode. This is fed to the proposal
agent's prompt context.

Why bother with a separate hypothesis step? Two reasons:
  1. It forces the system to articulate WHY it's making this mutation,
     which improves audit logs significantly.
  2. The hypothesis can be reused across multiple proposal candidates,
     reducing redundant LLM tokens.
"""

from __future__ import annotations

import json
import logging

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types

from optimizer import state_keys as K
from optimizer.llm_client import LLMCallable
from optimizer.persistence import repo

logger = logging.getLogger(__name__)


class ReflectionAgent(BaseAgent):
    def __init__(self, name: str, llm_fn: LLMCallable):
        super().__init__(name=name)
        self._llm = llm_fn

    async def _run_async_impl(self, ctx: InvocationContext):
        state = ctx.session.state
        run_id = state.get(K.RUN_ID, "?")

        # We summarize the best candidate's failures so far. If no candidates
        # yet (iter 0), we summarize against the base schema's dev evaluation
        # which is performed as part of the optimizer bootstrap.
        archive = state.get(K.GEPA_ARCHIVE, []) or []
        last_best = state.get(K.GEPA_LAST_BEST)
        target_candidate = last_best or (archive[-1] if archive else None)
        dev_results = state.get(K.GEPA_DEV_RESULTS, {}) or {}

        if not target_candidate or not dev_results:
            logger.info("[reflection] no prior eval - skipping")
            yield self._emit("(no prior dev results)", state_delta={
                K.GEPA_FAILURE_HYPOTHESIS: "No prior failures observed.",
            })
            return

        cand_id = target_candidate.get("candidate_id") if isinstance(target_candidate, dict) else None
        per_doc = dev_results.get(cand_id) or dev_results.get("base") or {}
        if not per_doc:
            yield self._emit("(no per-doc results for target candidate)", state_delta={
                K.GEPA_FAILURE_HYPOTHESIS: "No per-doc results to analyze.",
            })
            return

        failure_summary = self._summarize_failures(per_doc)
        if not failure_summary["has_failures"]:
            yield self._emit("(no failures - schema near ceiling)", state_delta={
                K.GEPA_FAILURE_HYPOTHESIS: "Schema appears near the dev-set ceiling.",
            })
            return

        try:
            hypothesis = self._call_llm(failure_summary)
        except Exception as e:
            logger.warning(f"[reflection] llm error: {e}")
            hypothesis = self._fallback_hypothesis(failure_summary)

        repo.write_audit(run_id, "reflection_hypothesis", {
            "hypothesis": hypothesis[:500],
        })

        yield self._emit(hypothesis[:500], state_delta={
            K.GEPA_FAILURE_HYPOTHESIS: hypothesis,
        })

    def _emit(self, text: str, state_delta: dict) -> Event:
        return Event(
            author=self.name,
            content=types.Content(parts=[types.Part(text=f"Hypothesis: {text}")]),
            actions=EventActions(state_delta=state_delta),
        )

    def _summarize_failures(self, per_doc: dict) -> dict:
        """Aggregate failures across docs into a per-field summary."""
        field_failures: dict[str, list] = {}
        for doc_name, doc_data in per_doc.items():
            for fr in doc_data.get("field_results", []) or []:
                if fr.get("correct", True):
                    continue
                field_failures.setdefault(fr["field_name"], []).append({
                    "doc": doc_name,
                    "expected": fr.get("expected"),
                    "actual": fr.get("actual"),
                    "note": fr.get("note", ""),
                })
        # rank worst first
        ranked = sorted(field_failures.items(), key=lambda kv: -len(kv[1]))
        return {
            "has_failures": bool(ranked),
            "by_field": ranked[:5],
        }

    def _call_llm(self, summary: dict) -> str:
        bundles = "\n\n".join(
            f"Field `{name}` ({len(fails)} failures):\n"
            + "\n".join(
                f"  - doc={f['doc']}: expected={f['expected']!r}, "
                f"got={f['actual']!r} ({f['note']})"
                for f in fails[:5]
            )
            for name, fails in summary["by_field"]
        )

        system = (
            "You are an expert at diagnosing structured-extraction errors. "
            "You write concise, evidence-based hypotheses about the root cause "
            "of observed failures."
        )
        user = f"""# Observed extraction failures (worst-failing fields first)
{bundles}

# Task
Write a single paragraph (3-5 sentences) describing the dominant failure
mode and its likely root cause. Be specific about which fields are
affected and why. Avoid generic prompt-engineering platitudes - point to
concrete evidence in the failures above.
"""
        resp = self._llm(system, user)
        return resp.text.strip()

    @staticmethod
    def _fallback_hypothesis(summary: dict) -> str:
        if not summary["by_field"]:
            return "No clear hypothesis - failures are sparse."
        worst = summary["by_field"][0]
        return (
            f"Field `{worst[0]}` accounts for the largest share of failures "
            f"({len(worst[1])} cases). Likely cause: under-specified extraction "
            f"rules or insufficient examples for this field."
        )
