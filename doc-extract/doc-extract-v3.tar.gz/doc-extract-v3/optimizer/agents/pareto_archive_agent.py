"""Pareto archive agent.

Runs after the parallel candidate evaluators. Reads each candidate's
slot-keyed result, merges them into the GEPA archive, persists the
snapshot, and updates the "current best" pointer (used as the parent
for next iteration's mutations).

Also writes the GEPA_DEV_RESULTS map (candidate_id -> per_doc) so the
reflection agent in the next iteration can use it.
"""

from __future__ import annotations

import logging

import yaml

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types

from optimizer import state_keys as K
from optimizer.pareto import pick_best, update_archive
from optimizer.persistence import repo

logger = logging.getLogger(__name__)


class ParetoArchiveAgent(BaseAgent):
    def __init__(self, name: str, n_slots: int):
        super().__init__(name=name)
        self._n_slots = n_slots

    async def _run_async_impl(self, ctx: InvocationContext):
        state = ctx.session.state
        run_id = state.get(K.RUN_ID, "?")
        spec = state.get(K.RUN_SPEC, {}) or {}
        objectives = spec.get("pareto_objectives", [
            "mean_field_f1", "mean_judge_score", "validator_pass_rate",
        ])

        # Collect slot results
        slot_results: list[dict] = []
        for i in range(self._n_slots):
            r = state.get(f"gepa:candidates:{i}:results")
            if r:
                slot_results.append(r)

        if not slot_results:
            yield self._noop("no slot results to merge")
            return

        # Merge into existing archive
        archive: list[dict] = list(state.get(K.GEPA_ARCHIVE, []) or [])
        dev_results: dict = dict(state.get(K.GEPA_DEV_RESULTS, {}) or {})

        any_added = False
        for sr in slot_results:
            entry = {
                "candidate_id": sr["candidate_id"],
                "schema_yaml": sr["schema_yaml"],
                "objectives": sr["objectives"],
            }
            archive, added = update_archive(archive, entry, objectives)
            if added:
                any_added = True
            dev_results[sr["candidate_id"]] = sr["per_doc"]

        # Snapshot to DB
        try:
            repo.snapshot_archive(
                run_id=run_id,
                iteration_id=state.get("gepa:iteration_db_id"),
                archive_entries=[
                    {"candidate_id": e["candidate_id"], "objectives": e["objectives"]}
                    for e in archive
                ],
            )
        except Exception as e:
            logger.warning(f"archive snapshot failed: {e}")

        # Pick current best for next iteration
        best = pick_best(archive, primary_objective="mean_field_f1",
                         tiebreakers=["mean_judge_score", "validator_pass_rate"])
        last_best = state.get(K.GEPA_LAST_BEST) or {}
        improved = False
        if best:
            prev_score = (last_best.get("objectives") or {}).get("mean_field_f1", 0)
            new_score = (best.get("objectives") or {}).get("mean_field_f1", 0)
            improved = new_score > prev_score + 1e-6

        # Stagnation counter
        stagnant = state.get(K.GEPA_STAGNANT_ROUNDS, 0)
        stagnant = 0 if improved else stagnant + 1

        # Update current_schema_yaml to the best candidate
        new_schema_yaml = (
            best["schema_yaml"] if best else state.get(K.GEPA_CURRENT_SCHEMA_YAML)
        )

        state_delta = {
            K.GEPA_ARCHIVE: archive,
            K.GEPA_DEV_RESULTS: dev_results,
            K.GEPA_LAST_BEST: best,
            K.GEPA_STAGNANT_ROUNDS: stagnant,
            K.GEPA_CURRENT_SCHEMA_YAML: new_schema_yaml,
        }
        # clear slot results to free state
        for i in range(self._n_slots):
            state_delta[f"gepa:candidates:{i}:results"] = None

        msg = (
            f"archive size={len(archive)} added={any_added} "
            f"best F1={best['objectives'].get('mean_field_f1', 0):.3f} "
            f"stagnant={stagnant}"
        ) if best else "no best found"
        logger.info(f"[archive] {msg}")
        repo.write_audit(run_id, "archive_updated", {
            "archive_size": len(archive),
            "any_added": any_added,
            "best_objectives": best["objectives"] if best else None,
            "stagnant_rounds": stagnant,
        })

        yield Event(
            author=self.name,
            content=types.Content(parts=[types.Part(text=msg)]),
            actions=EventActions(state_delta=state_delta),
        )

    def _noop(self, msg: str) -> Event:
        return Event(
            author=self.name,
            content=types.Content(parts=[types.Part(text=f"noop: {msg}")]),
            actions=EventActions(state_delta={}),
        )
