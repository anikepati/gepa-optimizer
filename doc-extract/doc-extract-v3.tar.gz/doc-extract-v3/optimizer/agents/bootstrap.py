"""Bootstrap agent.

Runs once at the very beginning of a run BEFORE any strategy iterations.
Evaluates the base schema on the dev set so:
  - we have a baseline to compare candidates against
  - gepa:dev_results has data for the first reflection_agent call
  - the archive is seeded with the base schema as a Pareto entry

Without this step, the first GEPA iteration would have no failures to
react to and would propose blindly.
"""

from __future__ import annotations

import logging
import yaml

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types

from optimizer import state_keys as K
from optimizer.persistence import repo

logger = logging.getLogger(__name__)


class BootstrapEvalAgent(BaseAgent):
    """Hooks into a single CandidateEvaluator with a special "base" candidate."""

    def __init__(self, name: str, evaluator):
        super().__init__(name=name)
        self._evaluator = evaluator     # CandidateEvaluatorAgent reused

    async def _run_async_impl(self, ctx: InvocationContext):
        state = ctx.session.state
        run_id = state.get(K.RUN_ID, "?")

        base_yaml = state.get(K.RUN_BASE_SCHEMA_YAML, "")
        if not base_yaml:
            logger.warning("[bootstrap] no base schema yaml in state")
            yield self._noop("no base schema")
            return

        # Insert a candidate row for the base schema
        base_cand_id = repo.insert_candidate(
            run_id=run_id,
            iteration_id=None,
            parent_id=None,
            strategy="bootstrap",
            schema_yaml=base_yaml,
            rationale="baseline (initial schema as provided)",
        )

        # Stage as a single-candidate slot for the evaluator
        candidates_state = [{
            "candidate_id": base_cand_id,
            "schema_yaml": base_yaml,
            "rationale": "baseline",
            "metadata": {},
            "strategy": "bootstrap",
        }]

        # We patch GEPA_CANDIDATES temporarily and run the evaluator at slot 0
        ctx.session.state[K.GEPA_CANDIDATES] = candidates_state

        # Bootstrap by running the evaluator (which writes to slot 0)
        async for ev in self._evaluator._run_async_impl(ctx):
            yield ev

        # Read back slot 0 result and seed archive + dev_results
        slot_result = ctx.session.state.get("gepa:candidates:0:results")
        if not slot_result:
            yield self._noop("evaluator produced no result")
            return

        archive = [{
            "candidate_id": slot_result["candidate_id"],
            "schema_yaml": slot_result["schema_yaml"],
            "objectives": slot_result["objectives"],
        }]
        dev_results = {slot_result["candidate_id"]: slot_result["per_doc"]}

        try:
            repo.snapshot_archive(
                run_id=run_id, iteration_id=None,
                archive_entries=[
                    {"candidate_id": e["candidate_id"], "objectives": e["objectives"]}
                    for e in archive
                ],
            )
        except Exception as e:
            logger.warning(f"bootstrap snapshot failed: {e}")

        repo.write_audit(run_id, "bootstrap_complete", {
            "base_candidate_id": base_cand_id,
            "objectives": slot_result["objectives"],
        })

        yield Event(
            author=self.name,
            content=types.Content(parts=[types.Part(
                text=f"Bootstrap complete: F1={slot_result['objectives'].get('mean_field_f1', 0):.3f}"
            )]),
            actions=EventActions(state_delta={
                K.GEPA_ARCHIVE: archive,
                K.GEPA_DEV_RESULTS: dev_results,
                K.GEPA_LAST_BEST: archive[0],
                K.GEPA_CURRENT_SCHEMA_YAML: base_yaml,
                K.GEPA_CANDIDATES: [],
                "gepa:candidates:0:results": None,
            }),
        )

    def _noop(self, msg: str) -> Event:
        return Event(
            author=self.name,
            content=types.Content(parts=[types.Part(text=f"noop: {msg}")]),
            actions=EventActions(state_delta={}),
        )
