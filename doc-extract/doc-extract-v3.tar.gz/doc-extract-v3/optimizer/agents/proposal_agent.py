"""Proposal agent.

Reads ralph:current_strategy and uses the strategy library to produce N
candidate schemas. Writes them to state under gepa:candidates AND
persists each candidate to the database with rationale.

Design note: the strategy itself does the LLM calls. The proposal agent
is the integration point that wires strategies into the ADK pipeline.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import yaml

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types

from optimizer import state_keys as K
from optimizer.llm_client import LLMCallable, make_text_callable
from optimizer.persistence import repo
from optimizer.strategies import (
    CandidateProposal, StrategyContext, load_strategy,
)

logger = logging.getLogger(__name__)


class ProposalAgent(BaseAgent):
    def __init__(
        self,
        name: str,
        strategy_descriptor_dir: str | Path,
        llm_fn: LLMCallable,
    ):
        super().__init__(name=name)
        self._descriptor_dir = Path(strategy_descriptor_dir)
        self._llm = llm_fn

    async def _run_async_impl(self, ctx: InvocationContext):
        state = ctx.session.state
        run_id = state.get(K.RUN_ID, "?")
        strategy_name = state.get(K.RALPH_CURRENT_STRATEGY, "reflection_mutation")
        spec = state.get(K.RUN_SPEC, {}) or {}
        n_candidates = int(spec.get("candidates_per_gepa_iteration", 4))

        strategy = load_strategy(strategy_name, self._descriptor_dir)
        ctx_for_strategy = self._build_strategy_context(state, n_candidates)

        try:
            proposals = strategy.propose(ctx_for_strategy)
        except Exception as e:
            logger.exception(f"[proposal] strategy {strategy_name} failed: {e}")
            proposals = []

        # Persist each candidate to DB
        iteration_id = state.get("gepa:iteration_db_id")
        parent_id = self._best_parent_id(state)

        candidate_records: list[dict] = []
        for prop in proposals:
            cand_id = repo.insert_candidate(
                run_id=run_id,
                iteration_id=iteration_id,
                parent_id=parent_id,
                strategy=strategy_name,
                schema_yaml=prop.schema_yaml,
                rationale=prop.rationale,
            )
            candidate_records.append({
                "candidate_id": cand_id,
                "schema_yaml": prop.schema_yaml,
                "rationale": prop.rationale,
                "metadata": prop.metadata,
                "strategy": strategy_name,
            })

        logger.info(
            f"[proposal] strategy={strategy_name} produced {len(proposals)} candidates"
        )

        yield Event(
            author=self.name,
            content=types.Content(parts=[types.Part(
                text=f"Proposed {len(proposals)} candidates via {strategy_name}"
            )]),
            actions=EventActions(state_delta={
                K.GEPA_CANDIDATES: candidate_records,
            }),
        )

    def _build_strategy_context(self, state: dict, n_candidates: int) -> StrategyContext:
        current_yaml = state.get(K.GEPA_CURRENT_SCHEMA_YAML)
        if not current_yaml:
            current_yaml = state.get(K.RUN_BASE_SCHEMA_YAML, "")

        # Field scores from latest dev results (best candidate or base)
        dev_results = state.get(K.GEPA_DEV_RESULTS, {}) or {}
        last_best = state.get(K.GEPA_LAST_BEST)
        target_id = last_best.get("candidate_id") if isinstance(last_best, dict) else "base"
        per_doc = dev_results.get(target_id) or dev_results.get("base") or {}

        field_scores, failures = self._aggregate(per_doc)

        # Train examples - just names + expected outputs
        train_examples = state.get(K.RUN_TRAIN_SET, []) or []

        # Wrap LLM as text callable for strategies
        text_llm = make_text_callable(self._llm)

        return StrategyContext(
            current_schema_yaml=current_yaml,
            field_scores=field_scores,
            failures_by_field=failures,
            archive=state.get(K.GEPA_ARCHIVE, []) or [],
            iteration=state.get(K.GEPA_ITERATION, 0),
            history=state.get(K.RALPH_HISTORY, []) or [],
            n_candidates=n_candidates,
            train_examples=train_examples,
            llm_fn=text_llm,
        )

    @staticmethod
    def _aggregate(per_doc: dict) -> tuple[dict[str, float], dict[str, list[dict]]]:
        scores: dict[str, list[float]] = {}
        failures: dict[str, list[dict]] = {}
        for doc_name, doc_data in per_doc.items():
            for fr in doc_data.get("field_results", []) or []:
                name = fr["field_name"]
                scores.setdefault(name, []).append(float(fr.get("score", 0.0)))
                if not fr.get("correct", True):
                    failures.setdefault(name, []).append({
                        "doc_name": doc_name,
                        "expected": fr.get("expected"),
                        "actual": fr.get("actual"),
                        "note": fr.get("note", ""),
                    })
        avg = {n: (sum(v) / len(v) if v else 0.0) for n, v in scores.items()}
        return avg, failures

    @staticmethod
    def _best_parent_id(state: dict) -> str | None:
        last_best = state.get(K.GEPA_LAST_BEST)
        if isinstance(last_best, dict):
            return last_best.get("candidate_id")
        return None
