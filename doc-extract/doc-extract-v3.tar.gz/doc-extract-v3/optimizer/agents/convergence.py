"""Convergence check + spec validator agents.

These two agents handle loop termination:
  - GEPAConvergenceCheck escalates the GEPA inner loop when no improvement
    has occurred for `convergence_patience` rounds OR archive size hit cap.
  - SpecValidator escalates the Ralph outer loop when the OptimizationSpec
    is satisfied (all targets met) OR budget exhausted.

ADK's LoopAgent terminates when an event with actions.escalate=True is
emitted by any sub-agent.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types

from optimizer import state_keys as K
from optimizer.persistence import repo
from optimizer.spec import OptimizationSpec

logger = logging.getLogger(__name__)


class GEPAConvergenceCheck(BaseAgent):
    def __init__(self, name: str, max_iterations: int, patience: int):
        super().__init__(name=name)
        self._max_iter = max_iterations
        self._patience = patience

    async def _run_async_impl(self, ctx: InvocationContext):
        state = ctx.session.state
        gepa_iter = state.get(K.GEPA_ITERATION, 0)
        stagnant = state.get(K.GEPA_STAGNANT_ROUNDS, 0)

        new_iter = gepa_iter + 1
        should_stop = (
            new_iter >= self._max_iter
            or stagnant >= self._patience
        )
        msg = f"gepa iter={new_iter} stagnant={stagnant} stop={should_stop}"
        logger.info(f"[gepa_convergence] {msg}")

        actions = EventActions(state_delta={
            K.GEPA_ITERATION: new_iter,
            K.GEPA_SHOULD_STOP: should_stop,
        })
        if should_stop:
            actions.escalate = True

        yield Event(
            author=self.name,
            content=types.Content(parts=[types.Part(text=msg)]),
            actions=actions,
        )


class SpecValidator(BaseAgent):
    """Checks OptimizationSpec satisfaction at the end of each Ralph iteration.

    Also performs the wall-clock budget check (cost budget is soft-warned by
    the LLM client wrapper but wall-clock is enforced here).
    """

    def __init__(self, name: str, run_started_at_unix: float):
        super().__init__(name=name)
        self._started_at = run_started_at_unix

    async def _run_async_impl(self, ctx: InvocationContext):
        state = ctx.session.state
        run_id = state.get(K.RUN_ID, "?")
        spec_dict = state.get(K.RUN_SPEC, {}) or {}
        spec = self._spec_from_dict(spec_dict)

        # Compute current best metrics on dev
        archive = state.get(K.GEPA_ARCHIVE, []) or []
        best_metrics: dict[str, float] = {}
        if archive:
            best = max(archive, key=lambda e: e["objectives"].get("mean_field_f1", 0))
            best_metrics = dict(best["objectives"])
            # Also expose per-field min for spec targets like min_field_f1
            # by reading the best candidate's per-doc results
            dev_results = state.get(K.GEPA_DEV_RESULTS, {}) or {}
            per_doc = dev_results.get(best["candidate_id"]) or {}
            field_scores: dict[str, list[float]] = {}
            for d in per_doc.values():
                for fr in d.get("field_results", []) or []:
                    field_scores.setdefault(fr["field_name"], []).append(
                        float(fr.get("score", 0.0))
                    )
            if field_scores:
                avg_per_field = {n: sum(v) / len(v) for n, v in field_scores.items()}
                best_metrics["min_field_f1"] = min(avg_per_field.values())

        satisfied, unmet = spec.evaluate_satisfaction(best_metrics)

        # Wall clock budget
        elapsed = time.time() - self._started_at
        wall_exhausted = elapsed >= spec.budget.max_wall_clock_seconds

        # Cost budget (read-only check; soft cap doesn't block here either)
        totals = repo.cost_totals(run_id)
        cost_exhausted = totals["estimated_dollars"] >= spec.budget.max_dollars

        ralph_iter = state.get(K.RALPH_ITERATION, 0) + 1

        should_stop = satisfied or wall_exhausted or ralph_iter >= spec.ralph_max_iterations
        if cost_exhausted:
            logger.warning(f"[spec] cost budget exceeded: {totals['estimated_dollars']:.2f}")
            # SOFT CAP per requirements: warn-and-continue. We DO NOT escalate on cost.

        msg_parts = [
            f"satisfied={satisfied}", f"unmet={unmet}",
            f"ralph_iter={ralph_iter}/{spec.ralph_max_iterations}",
            f"elapsed={elapsed:.0f}s/{spec.budget.max_wall_clock_seconds}s",
            f"cost=${totals['estimated_dollars']:.2f}/${spec.budget.max_dollars:.2f}",
        ]
        msg = " | ".join(msg_parts)
        logger.info(f"[spec_validator] {msg}")

        repo.write_audit(run_id, "spec_check", {
            "satisfied": satisfied,
            "unmet_targets": unmet,
            "ralph_iteration": ralph_iter,
            "metrics": best_metrics,
            "elapsed_seconds": elapsed,
            "cost_dollars": totals["estimated_dollars"],
            "should_stop": should_stop,
        })

        actions = EventActions(state_delta={
            K.RALPH_ITERATION: ralph_iter,
            K.RALPH_SHOULD_STOP: should_stop,
        })
        if should_stop:
            actions.escalate = True

        # Append to ralph history with iteration result
        history = list(state.get(K.RALPH_HISTORY, []) or [])
        history.append({
            "iteration": ralph_iter,
            "strategy": state.get(K.RALPH_CURRENT_STRATEGY),
            "metrics": best_metrics,
            "improved": bool(archive),
        })
        actions.state_delta[K.RALPH_HISTORY] = history
        actions.state_delta[K.COST_TOTALS] = totals

        yield Event(
            author=self.name,
            content=types.Content(parts=[types.Part(text=msg)]),
            actions=actions,
        )

    @staticmethod
    def _spec_from_dict(d: dict) -> OptimizationSpec:
        from optimizer.spec import Budget, TargetMetric
        return OptimizationSpec(
            name=d.get("name", ""),
            description=d.get("description", ""),
            targets=[TargetMetric(**t) for t in d.get("targets", [])],
            budget=Budget(**(d.get("budget") or {})),
            ralph_max_iterations=d.get("ralph_max_iterations", 5),
            gepa_max_iterations=d.get("gepa_max_iterations", 5),
            candidates_per_gepa_iteration=d.get("candidates_per_gepa_iteration", 4),
            convergence_patience=d.get("convergence_patience", 2),
            pareto_objectives=d.get("pareto_objectives") or [
                "mean_field_f1", "mean_judge_score", "validator_pass_rate",
            ],
        )
