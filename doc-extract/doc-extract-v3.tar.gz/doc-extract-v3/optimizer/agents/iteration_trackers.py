"""Iteration trackers.

Tiny agents that bracket Ralph and GEPA iterations. They write iteration_id
back into state so downstream agents can attribute their DB writes to the
right iteration row.

Without these, the candidate / archive rows would have NULL iteration_id
and the audit story would be hard to follow.
"""

from __future__ import annotations

import logging

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types

from optimizer import state_keys as K
from optimizer.persistence import repo

logger = logging.getLogger(__name__)


class GEPAIterationTracker(BaseAgent):
    """Writes a new iteration row at the start of each GEPA round."""

    async def _run_async_impl(self, ctx: InvocationContext):
        state = ctx.session.state
        run_id = state.get(K.RUN_ID, "?")
        iteration = state.get(K.GEPA_ITERATION, 0)
        strategy = state.get(K.RALPH_CURRENT_STRATEGY, "?")
        iteration_id = repo.start_iteration(
            run_id=run_id, loop="gepa",
            iteration=iteration, strategy=strategy,
        )
        yield Event(
            author=self.name,
            content=types.Content(parts=[types.Part(
                text=f"GEPA iter {iteration} started (id={iteration_id})"
            )]),
            actions=EventActions(state_delta={
                "gepa:iteration_db_id": iteration_id,
            }),
        )


class RalphIterationTracker(BaseAgent):
    """Writes a new iteration row at the start of each Ralph round."""

    async def _run_async_impl(self, ctx: InvocationContext):
        state = ctx.session.state
        run_id = state.get(K.RUN_ID, "?")
        iteration = state.get(K.RALPH_ITERATION, 0)
        iteration_id = repo.start_iteration(
            run_id=run_id, loop="ralph", iteration=iteration,
            strategy=state.get(K.RALPH_CURRENT_STRATEGY),
        )
        yield Event(
            author=self.name,
            content=types.Content(parts=[types.Part(
                text=f"Ralph iter {iteration} started (id={iteration_id})"
            )]),
            actions=EventActions(state_delta={
                "ralph:iteration_db_id": iteration_id,
            }),
        )
