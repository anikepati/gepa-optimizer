"""Strategy selector agent.

Picks the next mutation strategy for this Ralph iteration. This is the
auto-research piece: instead of always using one strategy, the selector
reads ralph:history and ralph:strategy_options and picks based on:

  - what's been tried recently (don't repeat)
  - whether we're stagnating (try template_restructure or schema_decomposition)
  - field_score floor (low floor -> schema_decomposition)
  - few_shot count (low -> demo_bootstrap)

Implementation: deterministic rules currently. The hook for swapping in
an LlmAgent-based selector exists - just replace pick_strategy() with an
LLM call. We default to rules because they're predictable and cheaper.
"""

from __future__ import annotations

import logging
from typing import Any

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types

from optimizer import state_keys as K
from optimizer.persistence import repo

logger = logging.getLogger(__name__)


class StrategySelectorAgent(BaseAgent):
    """Reads run + history state, writes ralph:current_strategy."""

    def __init__(self, name: str, available_strategies: list[str]):
        super().__init__(name=name)
        self._available = available_strategies

    async def _run_async_impl(self, ctx: InvocationContext):
        state = ctx.session.state
        history: list[dict] = state.get(K.RALPH_HISTORY, []) or []
        archive: list[dict] = state.get(K.GEPA_ARCHIVE, []) or []
        run_id = state.get(K.RUN_ID, "?")

        chosen = self.pick_strategy(history, archive)
        logger.info(f"[strategy_selector] run={run_id} picked: {chosen}")
        repo.write_audit(run_id, "strategy_selected", {
            "iteration": state.get(K.RALPH_ITERATION, 0),
            "strategy": chosen,
            "history_len": len(history),
        })

        yield Event(
            author=self.name,
            content=types.Content(parts=[types.Part(
                text=f"Selected strategy: {chosen}"
            )]),
            actions=EventActions(state_delta={K.RALPH_CURRENT_STRATEGY: chosen}),
        )

    # ---------- selection logic ----------

    def pick_strategy(self, history: list[dict], archive: list[dict]) -> str:
        """Default: round-robin with stagnation override and constraint checks."""
        # Stagnation override: if last 2 ralph rounds didn't produce
        # archive growth, try template_restructure (if available) or decomposition.
        if self._stagnating(history) and "template_restructure" in self._available:
            if not self._was_recently_tried("template_restructure", history, n=2):
                return "template_restructure"
            if "schema_decomposition" in self._available and \
               not self._was_recently_tried("schema_decomposition", history, n=2):
                return "schema_decomposition"

        # Default: rotate, prefer reflection_mutation as the workhorse
        order = [
            "reflection_mutation",
            "demo_bootstrap",
            "reflection_mutation",
            "schema_decomposition",
        ]
        round_idx = len(history) % len(order)
        candidate = order[round_idx]
        if candidate in self._available:
            return candidate
        return self._available[0] if self._available else "reflection_mutation"

    @staticmethod
    def _stagnating(history: list[dict]) -> bool:
        if len(history) < 2:
            return False
        last_two = history[-2:]
        return all(not h.get("improved", False) for h in last_two)

    @staticmethod
    def _was_recently_tried(name: str, history: list[dict], n: int) -> bool:
        return any(h.get("strategy") == name for h in history[-n:])
