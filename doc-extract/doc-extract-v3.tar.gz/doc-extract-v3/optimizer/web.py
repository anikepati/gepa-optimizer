"""ADK web UI entrypoint.

The `adk web` command (or `adk web --port 8080`) auto-discovers an agent
module exposing a `root_agent` variable at module level. We provide that
here so the developer UI gives observability into the optimizer.

Usage:
    adk web .

Or programmatically:
    python -m optimizer.web

The agent is built from config defaults at import time so that `adk web`
can pick it up without further setup. For a real RUN you should still use
the CLI (`python -m optimizer.cli start ...`); this module is for
inspecting agent topology and wiring in ADK's web UI.

Note that this module does NOT actually invoke the optimizer - it just
constructs the agent graph. Operators kick off real runs from the CLI
or via the web UI's "send message" panel after selecting this agent.
"""

from __future__ import annotations

import os
import time
from pathlib import Path

import yaml

from optimizer.orchestrator import build_optimizer_root_agent
from optimizer.persistence import init_engine
from optimizer.spec import OptimizationSpec


def _build_default_root_agent():
    """Build root_agent with config defaults so `adk web` can introspect it."""
    repo_root = Path(__file__).parent.parent
    opt_config_path = repo_root / "config" / "optimization.yaml"
    extraction_config_path = repo_root / "config" / "extraction_schema.yaml"
    pipeline_config_path = repo_root / "config" / "pipeline.yaml"
    strategy_dir = repo_root / "config" / "strategies"
    prompt_template = repo_root / "prompts" / "extraction_prompt.yaml"

    if not opt_config_path.exists():
        # When the package is installed elsewhere or paths aren't right, return a
        # placeholder agent so `adk web` doesn't crash. The ADK UI will surface
        # this clearly.
        from google.adk.agents import LlmAgent
        return LlmAgent(
            name="optimizer_placeholder",
            model="gemini-2.0-flash-exp",
            description="Optimizer config not found - run from project root",
            instruction="The optimizer config files were not found in the expected "
                        "location. Run `adk web` from the project root.",
        )

    with open(opt_config_path) as f:
        opt_config = yaml.safe_load(f) or {}
    spec = OptimizationSpec.from_yaml(opt_config_path, key="spec")

    pipeline_config: dict = {}
    if pipeline_config_path.exists():
        with open(pipeline_config_path) as f:
            pipeline_config = yaml.safe_load(f) or {}

    merged_config = {
        "llm": opt_config.get("llm") or pipeline_config.get("llm") or {},
        "ocr": opt_config.get("ocr") or pipeline_config.get("ocr") or {},
        "processing": opt_config.get("processing") or pipeline_config.get("processing") or {},
    }

    # Best-effort: only initialize DB if env is set; otherwise web UI works for
    # browsing the topology
    if os.environ.get("OPTIMIZER_DATABASE_URL"):
        try:
            init_engine()
        except Exception:
            pass

    placeholder_run_id = "web-preview-run"
    return build_optimizer_root_agent(
        run_id=placeholder_run_id,
        spec=spec,
        config=merged_config,
        strategy_descriptor_dir=strategy_dir,
        prompt_template_path=prompt_template,
        started_at_unix=time.time(),
    )


# Module-level export for `adk web` auto-discovery
root_agent = _build_default_root_agent()


def main():
    """Programmatic entry: launch the ADK web server pointing at this agent."""
    print("To start the ADK web UI, run from the project root:")
    print("    adk web .")
    print()
    print("The agent module is at: optimizer.web (root_agent)")
    print(f"Topology: {root_agent.name}")


if __name__ == "__main__":
    main()
