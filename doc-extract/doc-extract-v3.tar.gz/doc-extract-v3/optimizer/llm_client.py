"""LLM callable factory.

Returns a (system, user) -> response_text callable backed by Gemini or
Claude. Used by:
  - strategies (proposing schema mutations)
  - judge scorer (semantic correctness scoring)
  - direct extraction in evaluators (we call the LLM ourselves rather than
    going through a full ADK invocation per (candidate, doc) - that would
    be too slow for a real optimizer run)

Pricing tables for cost estimation are best-effort. Keep updated per
provider as model lineup changes. Update via env override if needed.
"""

from __future__ import annotations

import logging
import os
import threading
from dataclasses import dataclass
from typing import Callable

logger = logging.getLogger(__name__)


# Per-1M-tokens pricing in USD. Approximate, used for cost ledger only.
# Override via env: OPTIMIZER_PRICE_<MODEL>_INPUT, OPTIMIZER_PRICE_<MODEL>_OUTPUT
DEFAULT_PRICING: dict[str, tuple[float, float]] = {
    "gemini-2.0-flash-exp": (0.075, 0.30),
    "gemini-1.5-flash": (0.075, 0.30),
    "gemini-1.5-pro": (1.25, 5.00),
    "claude-haiku-4-5-20251001": (1.00, 5.00),
    "claude-opus-4-7": (15.00, 75.00),
    "claude-sonnet-4-6": (3.00, 15.00),
}


@dataclass
class LLMResponse:
    text: str
    input_tokens: int
    output_tokens: int
    estimated_dollars: float
    model: str


# A callable: (system, user) -> LLMResponse
LLMCallable = Callable[[str, str], LLMResponse]


def get_pricing(model: str) -> tuple[float, float]:
    in_env = os.environ.get(f"OPTIMIZER_PRICE_{model.upper().replace('-', '_')}_INPUT")
    out_env = os.environ.get(f"OPTIMIZER_PRICE_{model.upper().replace('-', '_')}_OUTPUT")
    if in_env and out_env:
        return float(in_env), float(out_env)
    return DEFAULT_PRICING.get(model, (1.0, 5.0))


def estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    in_price, out_price = get_pricing(model)
    return (input_tokens / 1_000_000) * in_price + (output_tokens / 1_000_000) * out_price


def make_gemini(model: str = "gemini-2.0-flash-exp", temperature: float = 0.0,
                max_tokens: int = 4096) -> LLMCallable:
    from google import genai
    from google.genai import types as gtypes
    client = genai.Client()

    def _call(system: str, user: str) -> LLMResponse:
        resp = client.models.generate_content(
            model=model,
            contents=[gtypes.Content(role="user", parts=[gtypes.Part(text=user)])],
            config=gtypes.GenerateContentConfig(
                system_instruction=system,
                temperature=temperature,
                max_output_tokens=max_tokens,
            ),
        )
        usage = getattr(resp, "usage_metadata", None)
        in_tok = getattr(usage, "prompt_token_count", 0) if usage else 0
        out_tok = getattr(usage, "candidates_token_count", 0) if usage else 0
        return LLMResponse(
            text=resp.text or "",
            input_tokens=int(in_tok or 0),
            output_tokens=int(out_tok or 0),
            estimated_dollars=estimate_cost(model, int(in_tok or 0), int(out_tok or 0)),
            model=model,
        )

    return _call


def make_claude(model: str = "claude-haiku-4-5-20251001", temperature: float = 0.0,
                max_tokens: int = 4096) -> LLMCallable:
    import anthropic
    client = anthropic.Anthropic()

    def _call(system: str, user: str) -> LLMResponse:
        resp = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        text = "".join(b.text for b in resp.content if hasattr(b, "text"))
        usage = resp.usage
        in_tok = getattr(usage, "input_tokens", 0) if usage else 0
        out_tok = getattr(usage, "output_tokens", 0) if usage else 0
        return LLMResponse(
            text=text,
            input_tokens=int(in_tok or 0),
            output_tokens=int(out_tok or 0),
            estimated_dollars=estimate_cost(model, int(in_tok or 0), int(out_tok or 0)),
            model=model,
        )

    return _call


def make_llm(provider: str, model: str, temperature: float = 0.0,
             max_tokens: int = 4096) -> LLMCallable:
    if provider == "gemini":
        return make_gemini(model=model, temperature=temperature, max_tokens=max_tokens)
    if provider == "claude":
        return make_claude(model=model, temperature=temperature, max_tokens=max_tokens)
    raise ValueError(f"Unknown LLM provider: {provider}")


# ---------- Cost-tracking wrapper ----------

class CostTrackingCallable:
    """Wraps an LLMCallable to write cost rows to the ledger.

    Soft-cap behavior: warns when over budget but does not block.
    Run-scoped: the run_id is passed at construction.
    """
    def __init__(
        self,
        inner: LLMCallable,
        run_id: str,
        agent_name: str,
        budget_dollars: float,
        budget_check_fn: Callable[[], dict[str, float]],
    ):
        self.inner = inner
        self.run_id = run_id
        self.agent_name = agent_name
        self.budget_dollars = budget_dollars
        self.budget_check_fn = budget_check_fn
        self._warned = threading.Event()

    def __call__(self, system: str, user: str) -> LLMResponse:
        # check budget *before* the call (soft cap)
        try:
            totals = self.budget_check_fn()
            if totals.get("estimated_dollars", 0) >= self.budget_dollars:
                if not self._warned.is_set():
                    logger.warning(
                        f"[budget] run={self.run_id} agent={self.agent_name} "
                        f"OVER soft cap: ${totals['estimated_dollars']:.2f} "
                        f">= ${self.budget_dollars:.2f}. Continuing (soft)."
                    )
                    self._warned.set()
        except Exception as e:
            logger.debug(f"budget check failed: {e}")

        resp = self.inner(system, user)

        # record cost
        try:
            from optimizer.persistence import repo
            repo.write_cost(
                run_id=self.run_id,
                agent_name=self.agent_name,
                model=resp.model,
                input_tokens=resp.input_tokens,
                output_tokens=resp.output_tokens,
                estimated_dollars=resp.estimated_dollars,
            )
        except Exception as e:
            logger.debug(f"cost write failed: {e}")

        return resp


def make_text_callable(llm: LLMCallable) -> Callable[[str, str], str]:
    """Adapt LLMCallable to the (system, user) -> text contract used by strategies."""
    def _t(system: str, user: str) -> str:
        return llm(system, user).text
    return _t
