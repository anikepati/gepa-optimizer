"""State key namespaces for the optimizer.

All ADK session_state writes use these prefixes. Following the namespacing
discipline, each agent only writes within its own prefix. Reads can cross
prefixes but writes are scoped.

This keeps ParallelAgent fan-out clean (each branch writes to its own
suffix under candidates:N:*) and makes resumability tractable.
"""

# Run-scoped, immutable
RUN_ID = "run:id"
RUN_SPEC = "run:spec"
RUN_BASE_SCHEMA_YAML = "run:base_schema_yaml"
RUN_DEV_SET = "run:dev_set"                  # list of {name, doc_path, expected}
RUN_TRAIN_SET = "run:train_set"
RUN_TEST_SET = "run:test_set"

# Ralph outer loop
RALPH_ITERATION = "ralph:iteration"
RALPH_HISTORY = "ralph:history"              # list of {iteration, strategy, summary}
RALPH_CURRENT_STRATEGY = "ralph:current_strategy"
RALPH_SHOULD_STOP = "ralph:should_stop"

# GEPA inner loop
GEPA_ITERATION = "gepa:iteration"
GEPA_CANDIDATES = "gepa:candidates"          # list of CandidateProposal as dicts
GEPA_DEV_RESULTS = "gepa:dev_results"        # candidate_id -> per-doc results
GEPA_FAILURE_HYPOTHESIS = "gepa:failure_hypothesis"
GEPA_ARCHIVE = "gepa:archive"                # list of {candidate_id, schema_yaml, objectives}
GEPA_LAST_BEST = "gepa:last_best"
GEPA_STAGNANT_ROUNDS = "gepa:stagnant_rounds"
GEPA_SHOULD_STOP = "gepa:should_stop"
GEPA_CURRENT_SCHEMA_YAML = "gepa:current_schema_yaml"

# Cost ledger snapshot
COST_TOTALS = "cost:totals"

# Audit
AUDIT_LATEST_EVENT = "audit:latest_event"
