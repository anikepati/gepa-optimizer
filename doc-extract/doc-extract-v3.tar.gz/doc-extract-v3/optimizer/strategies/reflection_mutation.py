"""Reflection mutation strategy.

Given the current schema and the set of observed failures, an LLM proposes
schema edits targeted at the dominant failure modes. This is the GEPA-core
mutation that earned it its name.

Diversity is achieved by prompting the LLM with different "lenses" per
candidate slot: tighten rules, add few-shots, clarify descriptions, propose
new validators.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

import yaml

from optimizer.strategies.base import (
    CandidateProposal, Strategy, StrategyContext, register,
)

logger = logging.getLogger(__name__)


@register
class ReflectionMutationStrategy(Strategy):
    name = "reflection_mutation"

    LENSES = [
        ("tighten_rules",
         "Focus on adding sharper extraction_rules to fields that failed. "
         "Each rule should explicitly address a specific failure observed."),
        ("add_few_shots",
         "Focus on adding new few_shot_examples drawn from failure cases. "
         "These should illustrate the tricky cases that the model got wrong."),
        ("clarify_descriptions",
         "Focus on rewriting field descriptions to disambiguate between "
         "similar fields and clarify edge cases."),
        ("propose_validators",
         "Focus on proposing new validation_rules that would catch the "
         "observed errors after the fact, even if extraction is imperfect."),
    ]

    def propose(self, ctx: StrategyContext) -> list[CandidateProposal]:
        if ctx.llm_fn is None:
            logger.error("reflection_mutation requires llm_fn in context")
            return []

        proposals: list[CandidateProposal] = []
        bundles = self._failure_bundles(ctx)
        if not bundles:
            logger.info("No failures observed - nothing for reflection to act on")
            return []

        for i in range(ctx.n_candidates):
            lens_name, lens_text = self.LENSES[i % len(self.LENSES)]
            try:
                proposal = self._propose_one(ctx, bundles, lens_name, lens_text)
                if proposal:
                    proposals.append(proposal)
            except Exception as e:
                logger.warning(f"reflection proposal {i} failed: {e}")

        return proposals

    # ---------- internals ----------

    def _failure_bundles(self, ctx: StrategyContext) -> list[dict]:
        bundles = []
        for field_name, failures in ctx.failures_by_field.items():
            if not failures:
                continue
            score = ctx.field_scores.get(field_name, 0.0)
            bundles.append({
                "field": field_name,
                "score": score,
                "failures": failures[:5],
            })
        bundles.sort(key=lambda b: b["score"])    # worst first
        return bundles[:5]

    def _propose_one(
        self,
        ctx: StrategyContext,
        bundles: list[dict],
        lens_name: str,
        lens_text: str,
    ) -> CandidateProposal | None:
        system = self.descriptor.get("system_prompt") or _DEFAULT_SYSTEM
        user = self._render_user_prompt(ctx, bundles, lens_text)
        response = ctx.llm_fn(system, user)
        edits = self._parse_edits(response)
        if not edits:
            return None

        new_yaml = self._apply_edits(ctx.current_schema_yaml, edits)
        rationale = edits.get("rationale", f"reflection lens={lens_name}")
        return CandidateProposal(
            schema_yaml=new_yaml,
            rationale=rationale,
            metadata={"lens": lens_name},
        )

    def _render_user_prompt(
        self, ctx: StrategyContext, bundles: list[dict], lens_text: str,
    ) -> str:
        bundle_text = "\n\n".join(
            f"### Field `{b['field']}` (current score: {b['score']:.2f})\n"
            + "\n".join(
                f"- doc={f.get('doc_name', '?')}: expected={f.get('expected')!r}, "
                f"got={f.get('actual')!r} ({f.get('note', '')})"
                for f in b["failures"]
            )
            for b in bundles
        )

        return f"""# Current schema (YAML)
```yaml
{ctx.current_schema_yaml}
```

# Observed failures (worst-scoring fields first)
{bundle_text}

# Mutation focus for this proposal
{lens_text}

# Your task
Propose targeted edits. Return ONLY a JSON object with this exact structure
(no markdown fences, no prose):

{{
  "rationale": "<one-sentence explanation of the change and why it should help>",
  "field_edits": [
    {{
      "field_name": "<existing field name>",
      "new_description": "<replacement description, or null to keep>",
      "add_extraction_rules": ["<new rule 1>", "<new rule 2>"]
    }}
  ],
  "new_few_shot_examples": [
    {{
      "input_excerpt": "<short snippet of doc text showing the case>",
      "output": {{<expected output JSON, only fields relevant to the case>}},
      "notes": "<what makes this case worth showing>"
    }}
  ],
  "new_validation_rules": [
    {{
      "name": "<short snake_case name>",
      "description": "<what is checked>",
      "severity": "warning",
      "tolerance": 0.0
    }}
  ]
}}

Constraints:
- Only edit existing fields (do not invent new field names).
- Add at most 4 new extraction_rules total across all fields.
- Add at most 2 new few_shot_examples.
- Add at most 1 new validation rule.
- Rules must be concrete and actionable, not vague.
- If a failure is just an LLM error that no rule could prevent, omit it.
"""

    @staticmethod
    def _parse_edits(text: str) -> dict[str, Any] | None:
        if not text:
            return None
        t = re.sub(r"^```(?:json)?\s*", "", text.strip())
        t = re.sub(r"\s*```$", "", t)
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            pass
        m = re.search(r"\{.*\}", t, re.DOTALL)
        if not m:
            return None
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            return None

    def _apply_edits(self, yaml_text: str, edits: dict) -> str:
        schema = yaml.safe_load(yaml_text) or {}
        fields_by_name = {f["name"]: f for f in schema.get("fields", [])}

        for edit in edits.get("field_edits", []) or []:
            f = fields_by_name.get(edit.get("field_name"))
            if not f:
                continue
            if edit.get("new_description"):
                f["description"] = edit["new_description"]
            new_rules = edit.get("add_extraction_rules") or []
            existing = {r.strip().lower() for r in f.get("extraction_rules", [])}
            for r in new_rules:
                if r and r.strip().lower() not in existing:
                    f.setdefault("extraction_rules", []).append(r.strip())
                    existing.add(r.strip().lower())

        new_examples = edits.get("new_few_shot_examples") or []
        if new_examples:
            schema.setdefault("few_shot_examples", []).extend([
                {
                    "input_excerpt": e.get("input_excerpt", ""),
                    "output": e.get("output", {}),
                    "notes": e.get("notes", ""),
                }
                for e in new_examples
            ])

        new_validators = edits.get("new_validation_rules") or []
        if new_validators:
            schema.setdefault("validation_rules", []).extend([
                {
                    "name": v.get("name", "unnamed"),
                    "description": v.get("description", ""),
                    "severity": v.get("severity", "warning"),
                    "tolerance": float(v.get("tolerance", 0.0) or 0.0),
                }
                for v in new_validators
            ])

        return yaml.safe_dump(schema, sort_keys=False, allow_unicode=True, width=100)


_DEFAULT_SYSTEM = (
    "You are an expert at structured data extraction prompt engineering. "
    "Your goal is to make targeted, evidence-based edits to an extraction "
    "schema based on observed failures."
)
