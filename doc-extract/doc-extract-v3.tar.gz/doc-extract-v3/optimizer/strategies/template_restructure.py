"""Template restructure strategy.

When schema-level edits stop helping, the bottleneck may be the prompt
template itself - the system prompt phrasing, the CoT structure, the order
of sections. This strategy proposes alternative prompt templates while
leaving the schema unchanged.

Each candidate is a tuple (schema_yaml, prompt_template_yaml). The
candidate evaluator handles the template via a side-channel in the
candidate's metadata.
"""

from __future__ import annotations

import json
import logging
import re

import yaml

from optimizer.strategies.base import (
    CandidateProposal, Strategy, StrategyContext, register,
)

logger = logging.getLogger(__name__)


@register
class TemplateRestructureStrategy(Strategy):
    name = "template_restructure"

    VARIATIONS = [
        ("stricter_cot",
         "Restructure the chain-of-thought to enforce stricter step-by-step "
         "verification. Each field check should be a numbered step."),
        ("output_first",
         "Reverse the order: produce a draft JSON output, then verify each "
         "field against the document. Catches sloppy initial extraction."),
        ("conservative_default",
         "Bias the system prompt strongly toward returning null for any "
         "field that is not explicitly stated. Reduces hallucination."),
        ("evidence_quoted",
         "For each field, require the model to quote the exact source "
         "phrase from the document before producing the value."),
    ]

    def propose(self, ctx: StrategyContext) -> list[CandidateProposal]:
        if ctx.llm_fn is None:
            return []
        proposals: list[CandidateProposal] = []
        for i in range(min(ctx.n_candidates, len(self.VARIATIONS))):
            var_name, var_text = self.VARIATIONS[i]
            try:
                p = self._propose_one(ctx, var_name, var_text)
                if p:
                    proposals.append(p)
            except Exception as e:
                logger.warning(f"template_restructure {var_name} failed: {e}")
        return proposals

    def _propose_one(
        self, ctx: StrategyContext, var_name: str, var_text: str,
    ) -> CandidateProposal | None:
        system = (
            "You are a prompt engineering expert. You produce alternative "
            "prompt templates that change the prompt's structure while "
            "preserving its variable contract."
        )
        user = f"""# Current schema fields (just for context, do not change)
{', '.join(self._field_names(ctx.current_schema_yaml))}

# Required template variables (these must remain wherever the template
# expects them; the template is rendered by Python str.format)
- {{document_type}}, {{document_description}}, {{field_definitions}},
  {{validation_rules}}, {{few_shot_examples}}, {{document_text}},
  {{reasoning_instructions}}

# Variation to apply
{var_text}

# Task
Return ONLY a JSON object with this structure:

{{
  "rationale": "<short explanation>",
  "system_prompt": "<full system prompt text, preserves placeholders>",
  "extraction_prompt": "<full extraction prompt text, preserves all variables above>",
  "reasoning_instructions_with_cot": "<reasoning section, references {{document_type}} only>",
  "reasoning_instructions_no_cot": "<short non-CoT version>"
}}

Rules:
- Every required variable must appear at least once.
- The output must be the JSON object only - no commentary.
- Keep the prompt's overall purpose: structured field extraction with rules.
"""
        response = ctx.llm_fn(system, user)
        edits = self._parse(response)
        if not edits:
            return None

        # Validate required vars present
        full_text = (
            edits.get("system_prompt", "")
            + edits.get("extraction_prompt", "")
            + edits.get("reasoning_instructions_with_cot", "")
            + edits.get("reasoning_instructions_no_cot", "")
        )
        required = ["{document_type}", "{field_definitions}",
                    "{validation_rules}", "{document_text}",
                    "{few_shot_examples}", "{reasoning_instructions}"]
        missing = [r for r in required if r not in full_text]
        if missing:
            logger.warning(f"template_restructure missing vars: {missing}")
            return None

        # Schema unchanged; mutation is in metadata.template_override
        return CandidateProposal(
            schema_yaml=ctx.current_schema_yaml,
            rationale=edits.get("rationale", f"template:{var_name}"),
            metadata={
                "template_override": {
                    "system_prompt": edits["system_prompt"],
                    "extraction_prompt": edits["extraction_prompt"],
                    "reasoning_instructions_with_cot":
                        edits["reasoning_instructions_with_cot"],
                    "reasoning_instructions_no_cot":
                        edits["reasoning_instructions_no_cot"],
                },
                "variation": var_name,
            },
        )

    @staticmethod
    def _field_names(yaml_text: str) -> list[str]:
        try:
            schema = yaml.safe_load(yaml_text) or {}
            return [f.get("name", "?") for f in schema.get("fields", [])]
        except Exception:
            return []

    @staticmethod
    def _parse(text: str) -> dict | None:
        t = re.sub(r"^```(?:json)?\s*", "", text.strip())
        t = re.sub(r"\s*```$", "", t)
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", t, re.DOTALL)
            if not m:
                return None
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                return None
