"""Schema decomposition strategy.

When a field plateaus at low score across multiple iterations, the issue is
often that the field is doing too much - e.g. "vendor" mixing legal name +
DBA + branch identifier. Decomposition splits it into multiple narrower
fields with their own rules.

Trigger criterion: at least one field has score < 0.7 AND has been below
0.7 for 2+ consecutive iterations (the strategy_selector checks this).
"""

from __future__ import annotations

import json
import logging
import re

import yaml

from optimizer.strategies.base import (
    CandidateProposal, Strategy, StrategyContext, register,
)

logger = logging.getLogger(__name__)


@register
class SchemaDecompositionStrategy(Strategy):
    name = "schema_decomposition"

    def propose(self, ctx: StrategyContext) -> list[CandidateProposal]:
        if ctx.llm_fn is None:
            return []
        weak_field = self._pick_target(ctx)
        if not weak_field:
            logger.info("No field weak enough for decomposition")
            return []

        proposals: list[CandidateProposal] = []
        for i in range(min(ctx.n_candidates, 2)):  # decomposition is heavyweight, fewer
            try:
                p = self._propose_one(ctx, weak_field, variant=i)
                if p:
                    proposals.append(p)
            except Exception as e:
                logger.warning(f"decomposition proposal {i} failed: {e}")
        return proposals

    def _pick_target(self, ctx: StrategyContext) -> str | None:
        candidates = [
            name for name, score in ctx.field_scores.items() if score < 0.7
        ]
        if not candidates:
            return None
        # weakest first
        candidates.sort(key=lambda n: ctx.field_scores.get(n, 1.0))
        return candidates[0]

    def _propose_one(
        self, ctx: StrategyContext, target_field: str, variant: int,
    ) -> CandidateProposal | None:
        system = (
            "You are an expert at structured data schema design. You decompose "
            "compound fields into well-typed components when a single field "
            "carries too much responsibility."
        )
        emphasis = [
            "Split into 2-3 sub-fields with distinct responsibilities.",
            "Add a single helper field that captures a confounder, "
            "leaving the main field but giving the LLM a place to put noise.",
        ][variant % 2]

        failures = ctx.failures_by_field.get(target_field, [])[:5]
        failures_text = "\n".join(
            f"- expected={f.get('expected')!r}, got={f.get('actual')!r}"
            for f in failures
        )

        user = f"""# Current schema (YAML)
```yaml
{ctx.current_schema_yaml}
```

# Target field for decomposition
`{target_field}` (current score: {ctx.field_scores.get(target_field, 0):.2f})

# Failures observed on this field
{failures_text}

# Task
{emphasis}

Return ONLY a JSON object:

{{
  "rationale": "<why decomposition will fix the failures>",
  "new_fields": [
    {{
      "name": "<new_field_name>",
      "type": "string|number|date|integer|boolean",
      "required": true|false,
      "description": "<what this captures>",
      "extraction_rules": ["<rule 1>", "<rule 2>"]
    }}
  ],
  "modifications_to_target": {{
    "new_description": "<narrowed description>",
    "add_extraction_rules": ["<rules emphasizing the narrower scope>"]
  }}
}}

Rules:
- Do not REMOVE the target field; downstream consumers may depend on it.
- New field names must be snake_case.
- Each new field must have at least one extraction rule.
"""
        response = ctx.llm_fn(system, user)
        edits = self._parse(response)
        if not edits:
            return None

        new_yaml = self._apply(ctx.current_schema_yaml, target_field, edits)
        return CandidateProposal(
            schema_yaml=new_yaml,
            rationale=edits.get("rationale", "schema_decomposition"),
            metadata={"target_field": target_field, "variant": variant},
        )

    @staticmethod
    def _parse(text: str) -> dict | None:
        t = re.sub(r"^```(?:json)?\s*", "", text.strip())
        t = re.sub(r"\s*```$", "", t)
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", t, re.DOTALL)
            if not m:
                return None
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                return None

    def _apply(self, yaml_text: str, target_field: str, edits: dict) -> str:
        schema = yaml.safe_load(yaml_text) or {}

        for nf in edits.get("new_fields", []) or []:
            if any(f["name"] == nf.get("name") for f in schema.get("fields", [])):
                continue
            schema.setdefault("fields", []).append({
                "name": nf.get("name"),
                "type": nf.get("type", "string"),
                "required": bool(nf.get("required", False)),
                "description": nf.get("description", ""),
                "extraction_rules": nf.get("extraction_rules", []),
            })

        mods = edits.get("modifications_to_target") or {}
        for f in schema.get("fields", []):
            if f["name"] != target_field:
                continue
            if mods.get("new_description"):
                f["description"] = mods["new_description"]
            existing = {r.strip().lower() for r in f.get("extraction_rules", [])}
            for r in mods.get("add_extraction_rules") or []:
                if r and r.strip().lower() not in existing:
                    f.setdefault("extraction_rules", []).append(r.strip())
                    existing.add(r.strip().lower())

        return yaml.safe_dump(schema, sort_keys=False, allow_unicode=True, width=100)
