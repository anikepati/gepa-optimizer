"""Strategy framework.

A strategy describes HOW to mutate the current schema into candidate
schemas. Each strategy is:
  - a YAML descriptor (config/strategies/<name>.yaml) with prompts and params
  - a Python class implementing Strategy.propose()

The strategy_selector agent picks one per Ralph iteration based on history.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import yaml


@dataclass
class StrategyContext:
    """Inputs available to every strategy when proposing candidates."""
    current_schema_yaml: str
    field_scores: dict[str, float]               # name -> 0..1
    failures_by_field: dict[str, list[dict]]     # name -> [{doc, expected, actual}]
    archive: list[dict]                          # current Pareto frontier
    iteration: int                               # current GEPA iteration
    history: list[dict]                          # past strategy results
    n_candidates: int                            # how many to propose
    train_examples: list[dict] = field(default_factory=list)
    # llm_fn: (system_prompt, user_prompt) -> response_text
    llm_fn: Callable[[str, str], str] | None = None


@dataclass
class CandidateProposal:
    """A single proposed schema with provenance for auditing."""
    schema_yaml: str
    rationale: str
    parent_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class Strategy(ABC):
    """Strategy interface. Concrete strategies live in optimizer/strategies/."""

    name: str = "base"

    def __init__(self, descriptor: dict[str, Any]):
        self.descriptor = descriptor

    @abstractmethod
    def propose(self, ctx: StrategyContext) -> list[CandidateProposal]:
        """Return up to ctx.n_candidates proposals."""
        ...


# ---------- Registry ----------

_REGISTRY: dict[str, type[Strategy]] = {}


def register(cls: type[Strategy]) -> type[Strategy]:
    """Decorator to register a Strategy subclass."""
    _REGISTRY[cls.name] = cls
    return cls


def load_strategy(name: str, descriptor_dir: str | Path) -> Strategy:
    """Load and instantiate a strategy by name. Reads descriptor YAML."""
    if name not in _REGISTRY:
        # try to import the module by convention to trigger registration
        import importlib
        try:
            importlib.import_module(f"optimizer.strategies.{name}")
        except ImportError:
            pass
    if name not in _REGISTRY:
        raise KeyError(f"Strategy not registered: {name}. Known: {list(_REGISTRY)}")
    descriptor_path = Path(descriptor_dir) / f"{name}.yaml"
    descriptor: dict[str, Any] = {}
    if descriptor_path.exists():
        with open(descriptor_path) as f:
            descriptor = yaml.safe_load(f) or {}
    return _REGISTRY[name](descriptor)


def list_strategies() -> list[str]:
    """Names of all registered strategies."""
    # ensure builtin modules are imported
    import optimizer.strategies.reflection_mutation  # noqa
    import optimizer.strategies.demo_bootstrap  # noqa
    import optimizer.strategies.schema_decomposition  # noqa
    import optimizer.strategies.template_restructure  # noqa
    return list(_REGISTRY.keys())
