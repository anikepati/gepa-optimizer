"""Demonstration bootstrapping strategy.

Inspired by DSPy's BootstrapFewShot: use the training set (which the optimizer
has access to but doesn't directly score against) to generate new few-shot
demonstrations. We don't have a stronger teacher model in the simple case;
instead we ask the LLM to *write* high-quality demonstrations from training
examples that target known weak fields.

This is most effective when the few_shot_examples list is empty or sparse.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

import yaml

from optimizer.strategies.base import (
    CandidateProposal, Strategy, StrategyContext, register,
)

logger = logging.getLogger(__name__)


@register
class DemoBootstrapStrategy(Strategy):
    name = "demo_bootstrap"

    def propose(self, ctx: StrategyContext) -> list[CandidateProposal]:
        if ctx.llm_fn is None:
            logger.error("demo_bootstrap requires llm_fn in context")
            return []
        if not ctx.train_examples:
            logger.info("demo_bootstrap requires train_examples in context")
            return []

        proposals: list[CandidateProposal] = []
        weak_fields = self._weak_fields(ctx)
        for i in range(ctx.n_candidates):
            try:
                proposal = self._propose_one(ctx, weak_fields, slot=i)
                if proposal:
                    proposals.append(proposal)
            except Exception as e:
                logger.warning(f"demo_bootstrap proposal {i} failed: {e}")
        return proposals

    def _weak_fields(self, ctx: StrategyContext) -> list[str]:
        ranked = sorted(ctx.field_scores.items(), key=lambda kv: kv[1])
        # focus on the weakest 3 fields
        return [name for name, _ in ranked[:3]]

    def _propose_one(
        self, ctx: StrategyContext, weak_fields: list[str], slot: int,
    ) -> CandidateProposal | None:
        # Vary which training example we anchor on for diversity
        anchor_idx = slot % max(1, len(ctx.train_examples))
        anchor = ctx.train_examples[anchor_idx]

        system = (
            "You are an expert at writing high-quality few-shot demonstrations "
            "for structured extraction. Demonstrations should illuminate edge "
            "cases and disambiguate similar fields."
        )
        user = self._render_user_prompt(ctx, weak_fields, anchor)
        response = ctx.llm_fn(system, user)
        edits = self._parse(response)
        if not edits:
            return None

        new_yaml = self._apply(ctx.current_schema_yaml, edits)
        return CandidateProposal(
            schema_yaml=new_yaml,
            rationale=edits.get("rationale", "demo_bootstrap"),
            metadata={"slot": slot, "anchor_doc": anchor.get("name", "?")},
        )

    def _render_user_prompt(
        self, ctx: StrategyContext, weak_fields: list[str], anchor: dict,
    ) -> str:
        return f"""# Current schema (YAML)
```yaml
{ctx.current_schema_yaml}
```

# Anchor training example (doc name: {anchor.get('name', '?')})
Expected output:
```json
{json.dumps(anchor.get('expected', {}), indent=2)[:2000]}
```

# Weak fields needing examples
{', '.join(weak_fields)}

# Task
Write 1-3 high-quality few-shot examples that would help the model handle
the weak fields. Anchor at least one in the training example above so the
demonstration matches the kind of documents we actually see.

Return ONLY a JSON object:

{{
  "rationale": "<short explanation>",
  "new_few_shot_examples": [
    {{
      "input_excerpt": "<plausible doc text snippet 100-300 chars>",
      "output": {{<expected JSON for the snippet>}},
      "notes": "<what tricky aspect this demonstrates>"
    }}
  ]
}}

Rules:
- Examples must be PLAUSIBLE - not contrived. They should look like real document excerpts.
- The output JSON must match the schema's field types and rules.
- Each example should target a specific weak field, not be generic.
"""

    @staticmethod
    def _parse(text: str) -> dict | None:
        t = re.sub(r"^```(?:json)?\s*", "", text.strip())
        t = re.sub(r"\s*```$", "", t)
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            pass
        m = re.search(r"\{.*\}", t, re.DOTALL)
        if not m:
            return None
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            return None

    def _apply(self, yaml_text: str, edits: dict) -> str:
        schema = yaml.safe_load(yaml_text) or {}
        new_examples = edits.get("new_few_shot_examples") or []
        if new_examples:
            schema.setdefault("few_shot_examples", []).extend([
                {
                    "input_excerpt": e.get("input_excerpt", ""),
                    "output": e.get("output", {}),
                    "notes": e.get("notes", ""),
                }
                for e in new_examples
            ])
        return yaml.safe_dump(schema, sort_keys=False, allow_unicode=True, width=100)
