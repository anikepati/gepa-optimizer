"""Field-level F1 scorer (signal 1 of 3).

Per-field scoring with type-aware comparison:
  string  -> normalized equality + char-bigram similarity for partial credit
  number  -> tolerance-based equality with graded penalty by relative error
  date    -> ISO format equality
  enum    -> exact match
  array   -> F1 over greedy item matching using item_schema
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from core.schema import ExtractionSchema, FieldDefinition


@dataclass
class FieldResult:
    field_name: str
    correct: bool
    score: float
    expected: Any
    actual: Any
    note: str = ""


@dataclass
class DocResult:
    doc_name: str
    field_results: list[FieldResult] = field(default_factory=list)
    extraction_succeeded: bool = True
    error: str = ""

    @property
    def all_correct(self) -> bool:
        return self.extraction_succeeded and all(f.correct for f in self.field_results)

    @property
    def doc_score(self) -> float:
        if not self.extraction_succeeded or not self.field_results:
            return 0.0
        return sum(f.score for f in self.field_results) / len(self.field_results)


class F1Scorer:
    def __init__(self, schema: ExtractionSchema, number_tolerance: float = 0.01):
        self.schema = schema
        self.number_tolerance = number_tolerance

    def score_doc(self, doc_name: str, actual: dict | None, expected: dict) -> DocResult:
        if actual is None:
            return DocResult(
                doc_name=doc_name,
                extraction_succeeded=False,
                error="No extraction output",
                field_results=[
                    FieldResult(f.name, False, 0.0, expected.get(f.name), None, "no extraction")
                    for f in self.schema.fields
                ],
            )
        results = []
        for fd in self.schema.fields:
            results.append(self._score_field(fd, expected.get(fd.name), actual.get(fd.name)))
        return DocResult(doc_name=doc_name, field_results=results)

    def _score_field(self, fd: FieldDefinition, expected, actual) -> FieldResult:
        if expected is None and actual is None:
            return FieldResult(fd.name, True, 1.0, expected, actual)
        if expected is None and actual is not None:
            return FieldResult(fd.name, False, 0.0, expected, actual,
                               "expected null but got value")
        if actual is None and expected is not None:
            return FieldResult(fd.name, False, 0.0, expected, actual, "missing")

        if fd.type == "array":
            return self._score_array(fd, expected, actual)
        if fd.type == "string":
            return self._score_string(fd, expected, actual)
        if fd.type in ("number", "integer"):
            return self._score_number(fd, expected, actual)
        if fd.type == "date":
            return self._score_date(fd, expected, actual)
        return FieldResult(
            fd.name,
            expected == actual, 1.0 if expected == actual else 0.0,
            expected, actual,
        )

    def _score_string(self, fd, expected, actual):
        e = self._norm(str(expected)); a = self._norm(str(actual))
        if e == a:
            return FieldResult(fd.name, True, 1.0, expected, actual)
        sim = self._bigram_jaccard(e, a)
        return FieldResult(fd.name, False, sim, expected, actual,
                           f"string mismatch (sim={sim:.2f})")

    def _score_number(self, fd, expected, actual):
        try:
            e = float(expected); a = float(actual)
        except (TypeError, ValueError):
            return FieldResult(fd.name, False, 0.0, expected, actual, "non-numeric")
        if abs(e - a) <= self.number_tolerance:
            return FieldResult(fd.name, True, 1.0, expected, actual)
        denom = max(abs(e), 1e-6)
        rel = abs(e - a) / denom
        score = max(0.0, 1.0 - min(rel, 1.0))
        return FieldResult(fd.name, False, score, expected, actual,
                           f"number mismatch (rel_err={rel:.3f})")

    def _score_date(self, fd, expected, actual):
        if str(expected).strip() == str(actual).strip():
            return FieldResult(fd.name, True, 1.0, expected, actual)
        return FieldResult(fd.name, False, 0.0, expected, actual, "date mismatch")

    def _score_array(self, fd, expected: list, actual) -> FieldResult:
        if not isinstance(actual, list):
            return FieldResult(fd.name, False, 0.0, expected, actual, "expected array")
        if not expected and not actual:
            return FieldResult(fd.name, True, 1.0, expected, actual)
        if not expected or not actual:
            return FieldResult(fd.name, False, 0.0, expected, actual,
                               f"length mismatch e={len(expected)} a={len(actual)}")

        used = set()
        pair_scores = []
        for ei in expected:
            best, best_idx = -1.0, -1
            for i, ai in enumerate(actual):
                if i in used:
                    continue
                s = self._score_array_item(fd, ei, ai)
                if s > best:
                    best, best_idx = s, i
            if best_idx >= 0:
                pair_scores.append(best)
                used.add(best_idx)

        correct_mass = sum(pair_scores)
        precision = correct_mass / len(actual) if actual else 0.0
        recall = correct_mass / len(expected) if expected else 0.0
        f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0
        is_correct = f1 >= 0.999
        note = "" if is_correct else f"array F1={f1:.3f}"
        return FieldResult(fd.name, is_correct, f1, expected, actual, note)

    def _score_array_item(self, fd, exp_item, act_item) -> float:
        if not fd.item_schema:
            return 1.0 if exp_item == act_item else 0.0
        if not isinstance(exp_item, dict) or not isinstance(act_item, dict):
            return 0.0
        scores = []
        for sub in fd.item_schema:
            sub_exp = exp_item.get(sub.name)
            sub_act = act_item.get(sub.name)
            scores.append(self._score_field(sub, sub_exp, sub_act).score)
        return sum(scores) / len(scores) if scores else 0.0

    @staticmethod
    def _norm(s: str) -> str:
        return re.sub(r"\s+", " ", s.lower().strip())

    @staticmethod
    def _bigram_jaccard(a: str, b: str) -> float:
        if not a and not b:
            return 1.0
        if not a or not b:
            return 0.0
        def bg(s):
            return {s[i:i + 2] for i in range(len(s) - 1)} if len(s) >= 2 else {s}
        ba, bb = bg(a), bg(b)
        if not ba or not bb:
            return 0.0
        return len(ba & bb) / len(ba | bb)
