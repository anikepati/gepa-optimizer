"""Custom validator runner (signal 3 of 3).

Custom validators are registered Python callables that enforce business
rules - cross-field arithmetic, regex shape, lookup-table membership.

Unlike F1 (graded score) and judge (graded score), validators are
PASS/FAIL. A candidate that fails a validator is treated as dominated on
the validator_pass_rate objective regardless of F1.

Validators are referenced by name from extraction_schema.yaml under
custom_validators. New validators are added by writing a function in
this file and decorating it with @register_validator("name").
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass
class ValidatorResult:
    name: str
    passed: bool
    message: str = ""


_VALIDATORS: dict[str, Callable[[dict, dict], ValidatorResult]] = {}


def register_validator(name: str):
    """Decorator to register a validator by name."""
    def deco(fn):
        _VALIDATORS[name] = fn
        return fn
    return deco


def list_validators() -> list[str]:
    return list(_VALIDATORS.keys())


def run_validators(
    extracted: dict,
    schema_dict: dict,
) -> list[ValidatorResult]:
    """Run all validators referenced in schema.custom_validators.

    Returns one ValidatorResult per validator. Unknown names produce a
    failed result with a clear message.
    """
    refs = schema_dict.get("custom_validators") or []
    results: list[ValidatorResult] = []
    for ref in refs:
        if isinstance(ref, str):
            name, params = ref, {}
        elif isinstance(ref, dict):
            name = ref.get("name")
            params = ref.get("params", {})
        else:
            continue
        fn = _VALIDATORS.get(name)
        if fn is None:
            results.append(ValidatorResult(name, False, f"unknown validator: {name}"))
            continue
        try:
            results.append(fn(extracted, params))
        except Exception as e:
            results.append(ValidatorResult(name, False, f"validator error: {e}"))
    return results


def pass_rate(results: list[ValidatorResult]) -> float:
    if not results:
        return 1.0
    return sum(1 for r in results if r.passed) / len(results)


# ---------- Built-in validators ----------

@register_validator("required_fields_present")
def _required_present(extracted: dict, params: dict) -> ValidatorResult:
    """Pass if all field names listed in params['fields'] are non-null in extracted."""
    fields = params.get("fields", [])
    missing = [f for f in fields if extracted.get(f) in (None, "", [])]
    if missing:
        return ValidatorResult(
            "required_fields_present", False, f"missing: {', '.join(missing)}",
        )
    return ValidatorResult("required_fields_present", True)


@register_validator("regex_match")
def _regex_match(extracted: dict, params: dict) -> ValidatorResult:
    """Pass if extracted[field] matches the regex pattern."""
    field = params.get("field")
    pattern = params.get("pattern", ".*")
    val = extracted.get(field)
    if val is None:
        return ValidatorResult("regex_match", True, f"{field} is null, skipped")
    if not isinstance(val, str):
        return ValidatorResult("regex_match", False, f"{field} not a string")
    if re.fullmatch(pattern, val):
        return ValidatorResult("regex_match", True)
    return ValidatorResult(
        "regex_match", False, f"{field}={val!r} did not match {pattern!r}",
    )


@register_validator("arithmetic_sum")
def _arithmetic_sum(extracted: dict, params: dict) -> ValidatorResult:
    """Pass if extracted[total_field] == sum(extracted[components_field]) within tolerance."""
    total_field = params.get("total")
    components_field = params.get("components")
    item_key = params.get("item_key", "total")
    tolerance = float(params.get("tolerance", 0.02))

    total = extracted.get(total_field)
    components = extracted.get(components_field) or []
    try:
        total_f = float(total) if total is not None else None
        comp_sum = sum(float(c.get(item_key, 0) or 0) for c in components if isinstance(c, dict))
    except (TypeError, ValueError) as e:
        return ValidatorResult("arithmetic_sum", False, f"non-numeric: {e}")

    if total_f is None or not components:
        return ValidatorResult("arithmetic_sum", True, "skipped (missing inputs)")
    if abs(total_f - comp_sum) <= tolerance:
        return ValidatorResult("arithmetic_sum", True)
    return ValidatorResult(
        "arithmetic_sum", False,
        f"sum({components_field})={comp_sum} vs {total_field}={total_f}",
    )


@register_validator("date_order")
def _date_order(extracted: dict, params: dict) -> ValidatorResult:
    """Pass if extracted[earlier_field] <= extracted[later_field] (ISO date strings)."""
    from datetime import datetime
    earlier = params.get("earlier")
    later = params.get("later")
    e_val = extracted.get(earlier)
    l_val = extracted.get(later)
    if not e_val or not l_val:
        return ValidatorResult("date_order", True, "skipped (missing date)")
    try:
        e_d = datetime.strptime(e_val, "%Y-%m-%d")
        l_d = datetime.strptime(l_val, "%Y-%m-%d")
    except ValueError as e:
        return ValidatorResult("date_order", False, f"date parse: {e}")
    if e_d <= l_d:
        return ValidatorResult("date_order", True)
    return ValidatorResult(
        "date_order", False, f"{earlier}={e_val} > {later}={l_val}",
    )
