"""LLM-as-judge scorer (signal 2 of 3).

For each (field, expected, actual) tuple where F1 reports a mismatch, ask a
judge LLM whether the actual value is semantically equivalent. Returns 0..1
score per field, averaged into mean_judge_score per doc.

Why we need this: F1 misses "Acme Corp" vs "Acme Corporation", "$1,000.00"
vs "1000", "Net 30" interpreted as a payment term not a literal date. The
judge gives the optimizer a signal that the model is "right in spirit"
even when exact match fails.

Cost control: we only call the judge for fields that F1 marked incorrect.
Correct fields get a free 1.0 from the judge.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import Callable

logger = logging.getLogger(__name__)


@dataclass
class JudgeResult:
    field_name: str
    score: float                 # 0..1
    rationale: str = ""


class JudgeScorer:
    def __init__(
        self,
        llm_fn: Callable[[str, str], str],
        max_concurrent: int = 4,
    ):
        self.llm_fn = llm_fn
        self.max_concurrent = max_concurrent

    def score_doc(
        self,
        doc_name: str,
        f1_results: list,                # list[FieldResult]
        document_excerpt: str = "",
    ) -> dict[str, JudgeResult]:
        """Judge incorrect fields. Returns field_name -> JudgeResult."""
        out: dict[str, JudgeResult] = {}
        to_judge = [r for r in f1_results if not r.correct]
        for r in f1_results:
            if r.correct:
                out[r.field_name] = JudgeResult(r.field_name, 1.0, "F1 correct")

        if not to_judge:
            return out

        # Batch all incorrect fields into one judge call to save round trips
        try:
            batch = self._batch_judge(doc_name, to_judge, document_excerpt)
            for r in to_judge:
                jr = batch.get(r.field_name)
                if jr is None:
                    out[r.field_name] = JudgeResult(r.field_name, r.score, "judge miss, fell back to F1")
                else:
                    out[r.field_name] = jr
        except Exception as e:
            logger.warning(f"judge batch failed for {doc_name}: {e}")
            for r in to_judge:
                out[r.field_name] = JudgeResult(r.field_name, r.score, "judge error, fell back to F1")
        return out

    def _batch_judge(
        self, doc_name: str, results: list, doc_excerpt: str,
    ) -> dict[str, JudgeResult]:
        items_text = "\n".join(
            f"- field: {r.field_name}\n"
            f"  expected: {json.dumps(r.expected, default=str)[:300]}\n"
            f"  actual: {json.dumps(r.actual, default=str)[:300]}"
            for r in results
        )

        system = (
            "You are an evaluator for document extraction. You decide whether "
            "an actual extracted value is semantically equivalent to the "
            "expected value, even if formatting differs."
        )
        user = f"""# Document name: {doc_name}

# Document excerpt (for grounding judgment)
{doc_excerpt[:2000]}

# Extraction comparisons to judge
{items_text}

# Task
For each field, give a score from 0.0 to 1.0:
  1.0 = semantically identical (e.g. "Acme Corp" vs "Acme Corporation")
  0.7 = mostly correct, minor inaccuracy (e.g. wrong by 1% on a number)
  0.3 = wrong but in the right ballpark
  0.0 = clearly wrong / hallucinated / missing

Return ONLY a JSON object:
{{
  "judgments": [
    {{"field": "<field_name>", "score": 0.0..1.0, "rationale": "<one short sentence>"}}
  ]
}}
"""
        response = self.llm_fn(system, user)
        return self._parse(response)

    @staticmethod
    def _parse(text: str) -> dict[str, JudgeResult]:
        if not text:
            return {}
        t = re.sub(r"^```(?:json)?\s*", "", text.strip())
        t = re.sub(r"\s*```$", "", t)
        try:
            parsed = json.loads(t)
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", t, re.DOTALL)
            if not m:
                return {}
            try:
                parsed = json.loads(m.group(0))
            except json.JSONDecodeError:
                return {}

        out: dict[str, JudgeResult] = {}
        for j in parsed.get("judgments", []) or []:
            name = j.get("field")
            if not name:
                continue
            try:
                score = float(j.get("score", 0.0))
                score = max(0.0, min(1.0, score))
            except (TypeError, ValueError):
                score = 0.0
            out[name] = JudgeResult(name, score, j.get("rationale", ""))
        return out
