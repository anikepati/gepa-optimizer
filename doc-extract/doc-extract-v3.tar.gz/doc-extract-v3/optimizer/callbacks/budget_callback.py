"""ADK callbacks for budget enforcement and audit trail.

These hook into ADK's LlmAgent lifecycle. Soft cap behavior: log a warning
when over budget, return None so ADK proceeds normally with the LLM call.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

logger = logging.getLogger(__name__)


def make_budget_warner(
    run_id: str,
    budget_dollars: float,
    cost_query_fn: Callable[[str], dict[str, float]],
):
    """Returns a `before_model_callback` for ADK LlmAgents.

    ADK callback contract: returning None lets the call proceed; returning a
    LlmResponse short-circuits with that response. We always return None
    (soft cap), but log a one-shot warning when threshold is crossed.

    Note: `cost_query_fn(run_id) -> {"estimated_dollars": ...}` indirection
    is so we don't import repo at module load (avoids circular import).
    """
    state = {"warned": False}

    def _cb(callback_context, llm_request):
        try:
            totals = cost_query_fn(run_id)
            if totals.get("estimated_dollars", 0) >= budget_dollars and not state["warned"]:
                logger.warning(
                    f"[budget-callback] run={run_id} OVER soft cap: "
                    f"${totals['estimated_dollars']:.2f} >= ${budget_dollars:.2f}. "
                    f"Soft mode - continuing."
                )
                state["warned"] = True
        except Exception as e:
            logger.debug(f"budget callback error: {e}")
        return None

    return _cb


def make_cost_recorder(run_id: str, agent_name: str):
    """Returns an `after_model_callback` that records actual usage.

    Note: most LLM calls in this optimizer go through CostTrackingCallable
    (see llm_client.py). This callback covers any LLM calls made by ADK's
    LlmAgents directly, so we still capture them in the cost ledger.
    """
    def _cb(callback_context, llm_response):
        try:
            from optimizer.persistence import repo
            from optimizer.llm_client import estimate_cost
            usage = getattr(llm_response, "usage_metadata", None)
            if usage is None:
                return None
            in_t = int(getattr(usage, "prompt_token_count", 0) or 0)
            out_t = int(getattr(usage, "candidates_token_count", 0) or 0)
            model = getattr(llm_response, "model", "unknown") or "unknown"
            repo.write_cost(
                run_id=run_id,
                agent_name=agent_name,
                model=model,
                input_tokens=in_t,
                output_tokens=out_t,
                estimated_dollars=estimate_cost(model, in_t, out_t),
            )
        except Exception as e:
            logger.debug(f"cost recorder error: {e}")
        return None

    return _cb
