"""Database connection and session management.

Uses a single engine + sessionmaker per process. ADK's DatabaseSessionService
uses its own engine internally; we share the URL but not the connection pool
to avoid contention between ADK's and our queries.
"""

from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from optimizer.persistence.models import create_all_tables

logger = logging.getLogger(__name__)

_engine: Engine | None = None
_SessionLocal: sessionmaker | None = None


def get_database_url() -> str:
    """Read DB URL from env or config. Sentinel for missing config."""
    url = os.environ.get("OPTIMIZER_DATABASE_URL")
    if not url:
        raise RuntimeError(
            "OPTIMIZER_DATABASE_URL not set. Example: "
            "postgresql+psycopg2://user:pass@host:5432/optimizer"
        )
    return url


def init_engine(url: str | None = None, echo: bool = False) -> Engine:
    """Initialize the engine and create tables. Idempotent."""
    global _engine, _SessionLocal
    if _engine is not None:
        return _engine
    url = url or get_database_url()
    _engine = create_engine(
        url,
        echo=echo,
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        future=True,
    )
    _SessionLocal = sessionmaker(bind=_engine, autoflush=False, autocommit=False)
    create_all_tables(_engine)
    logger.info(f"Optimizer DB initialized: {url.split('@')[-1] if '@' in url else url}")
    return _engine


def get_engine() -> Engine:
    if _engine is None:
        return init_engine()
    return _engine


@contextmanager
def db_session() -> Iterator[Session]:
    """Context manager wrapping a transaction. Auto-commit on success, rollback on error."""
    if _SessionLocal is None:
        init_engine()
    assert _SessionLocal is not None
    session = _SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
