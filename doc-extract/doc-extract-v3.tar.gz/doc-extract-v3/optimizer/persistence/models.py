"""SQLAlchemy models for optimization persistence.

These tables are independent of ADK's own session/event tables (which the
DatabaseSessionService creates). Together they give us:
  - durable run state (resume after pod restart)
  - queryable lineage (every mutation, who proposed it, what it scored)
  - cost ledger (token + dollar accounting)
  - Pareto archive snapshots over time

Tables are created by Base.metadata.create_all() on first run.
No migration files - this matches the requested setup.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    JSON, BigInteger, Boolean, Column, DateTime, Float, ForeignKey, Integer,
    String, Text, Index,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class OptRun(Base):
    """One end-to-end optimization run."""
    __tablename__ = "opt_runs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(256))
    spec_json: Mapped[dict] = mapped_column(JSON)
    base_schema_yaml: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(32), default="running")
    # running | satisfied | exhausted | failed | aborted
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    final_candidate_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")


class OptIteration(Base):
    """A Ralph or GEPA iteration within a run."""
    __tablename__ = "opt_iterations"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    run_id: Mapped[str] = mapped_column(String(64), ForeignKey("opt_runs.id"), index=True)
    loop: Mapped[str] = mapped_column(String(16))           # "ralph" | "gepa"
    iteration: Mapped[int] = mapped_column(Integer)
    strategy: Mapped[str | None] = mapped_column(String(64), nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    summary_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)


class OptCandidate(Base):
    """One schema variant that was proposed and (possibly) evaluated."""
    __tablename__ = "opt_candidates"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    run_id: Mapped[str] = mapped_column(String(64), ForeignKey("opt_runs.id"), index=True)
    parent_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    iteration_id: Mapped[int | None] = mapped_column(
        BigInteger, ForeignKey("opt_iterations.id"), nullable=True, index=True
    )
    strategy: Mapped[str] = mapped_column(String(64))
    schema_yaml: Mapped[str] = mapped_column(Text)
    proposal_rationale: Mapped[str] = mapped_column(Text, default="")
    objectives_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    field_scores_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class OptParetoArchive(Base):
    """Snapshot of the Pareto frontier at a point in time."""
    __tablename__ = "opt_pareto_archive"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    run_id: Mapped[str] = mapped_column(String(64), ForeignKey("opt_runs.id"), index=True)
    iteration_id: Mapped[int | None] = mapped_column(
        BigInteger, ForeignKey("opt_iterations.id"), nullable=True
    )
    candidate_id: Mapped[str] = mapped_column(String(64), ForeignKey("opt_candidates.id"))
    objectives_json: Mapped[dict] = mapped_column(JSON)
    snapshot_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class OptEvaluation(Base):
    """One (candidate, document) evaluation result."""
    __tablename__ = "opt_evaluations"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    run_id: Mapped[str] = mapped_column(String(64), ForeignKey("opt_runs.id"), index=True)
    candidate_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("opt_candidates.id"), index=True
    )
    doc_name: Mapped[str] = mapped_column(String(256))
    split: Mapped[str] = mapped_column(String(16))                # train | dev | test
    f1_score: Mapped[float] = mapped_column(Float, default=0.0)
    judge_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    validator_pass: Mapped[bool] = mapped_column(Boolean, default=True)
    field_results_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    raw_output_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    __table_args__ = (
        Index("ix_eval_run_cand_doc", "run_id", "candidate_id", "doc_name"),
    )


class OptAuditLog(Base):
    """Append-only audit log of every significant event in a run."""
    __tablename__ = "opt_audit_log"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    run_id: Mapped[str] = mapped_column(String(64), ForeignKey("opt_runs.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(64))
    # spec_loaded | strategy_selected | candidate_proposed | candidate_evaluated |
    # archive_updated | budget_warning | spec_satisfied | run_finished | error
    actor: Mapped[str] = mapped_column(String(64), default="system")
    details_json: Mapped[dict] = mapped_column(JSON, default=dict)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, index=True
    )


class OptCostLedger(Base):
    """Per-LLM-call cost accounting."""
    __tablename__ = "opt_cost_ledger"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    run_id: Mapped[str] = mapped_column(String(64), ForeignKey("opt_runs.id"), index=True)
    agent_name: Mapped[str] = mapped_column(String(128))
    model: Mapped[str] = mapped_column(String(128))
    input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, default=0)
    estimated_dollars: Mapped[float] = mapped_column(Float, default=0.0)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, index=True
    )


def create_all_tables(engine):
    """Create tables if they do not exist. Idempotent."""
    Base.metadata.create_all(engine)
