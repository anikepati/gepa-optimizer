"""Repository pattern for optimization tables.

All persistence operations live here. Agents call repo functions, never
write raw SQL or ORM elsewhere. This keeps the agent code testable and
the data model centrally controlled.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import desc, select

from optimizer.persistence.db import db_session
from optimizer.persistence.models import (
    OptAuditLog, OptCandidate, OptCostLedger, OptEvaluation,
    OptIteration, OptParetoArchive, OptRun,
)

logger = logging.getLogger(__name__)


# ---------- Run lifecycle ----------

def create_run(
    name: str,
    spec_dict: dict,
    base_schema_yaml: str,
) -> str:
    run_id = f"run-{uuid.uuid4().hex[:16]}"
    with db_session() as s:
        s.add(OptRun(
            id=run_id,
            name=name,
            spec_json=spec_dict,
            base_schema_yaml=base_schema_yaml,
            status="running",
        ))
    write_audit(run_id, "run_started", {"name": name})
    return run_id


def finish_run(
    run_id: str,
    status: str,
    final_candidate_id: str | None = None,
    notes: str = "",
) -> None:
    with db_session() as s:
        run = s.get(OptRun, run_id)
        if run is None:
            return
        run.status = status
        run.finished_at = datetime.now(timezone.utc)
        run.final_candidate_id = final_candidate_id
        if notes:
            run.notes = notes
    write_audit(run_id, "run_finished", {"status": status, "final": final_candidate_id})


def get_run(run_id: str) -> dict | None:
    with db_session() as s:
        run = s.get(OptRun, run_id)
        if run is None:
            return None
        return _run_to_dict(run)


def _run_to_dict(run: OptRun) -> dict:
    return {
        "id": run.id,
        "name": run.name,
        "spec": run.spec_json,
        "status": run.status,
        "started_at": run.started_at.isoformat() if run.started_at else None,
        "finished_at": run.finished_at.isoformat() if run.finished_at else None,
        "final_candidate_id": run.final_candidate_id,
    }


# ---------- Iterations ----------

def start_iteration(
    run_id: str,
    loop: str,
    iteration: int,
    strategy: str | None = None,
) -> int:
    with db_session() as s:
        it = OptIteration(
            run_id=run_id,
            loop=loop,
            iteration=iteration,
            strategy=strategy,
        )
        s.add(it)
        s.flush()
        iteration_id = it.id
    write_audit(run_id, "iteration_started", {
        "loop": loop, "iteration": iteration, "strategy": strategy,
        "iteration_id": iteration_id,
    })
    return iteration_id


def finish_iteration(iteration_id: int, summary: dict) -> None:
    with db_session() as s:
        it = s.get(OptIteration, iteration_id)
        if it is None:
            return
        it.finished_at = datetime.now(timezone.utc)
        it.summary_json = summary


# ---------- Candidates ----------

def insert_candidate(
    run_id: str,
    iteration_id: int | None,
    parent_id: str | None,
    strategy: str,
    schema_yaml: str,
    rationale: str = "",
) -> str:
    cand_id = f"cand-{uuid.uuid4().hex[:16]}"
    with db_session() as s:
        s.add(OptCandidate(
            id=cand_id,
            run_id=run_id,
            iteration_id=iteration_id,
            parent_id=parent_id,
            strategy=strategy,
            schema_yaml=schema_yaml,
            proposal_rationale=rationale,
        ))
    write_audit(run_id, "candidate_proposed", {
        "candidate_id": cand_id, "parent_id": parent_id, "strategy": strategy,
    })
    return cand_id


def update_candidate_metrics(
    candidate_id: str,
    objectives: dict[str, float],
    field_scores: dict[str, float],
) -> None:
    with db_session() as s:
        cand = s.get(OptCandidate, candidate_id)
        if cand is None:
            return
        cand.objectives_json = objectives
        cand.field_scores_json = field_scores
    # audit emitted by caller with broader context


def get_candidate(candidate_id: str) -> dict | None:
    with db_session() as s:
        c = s.get(OptCandidate, candidate_id)
        if c is None:
            return None
        return {
            "id": c.id,
            "run_id": c.run_id,
            "parent_id": c.parent_id,
            "strategy": c.strategy,
            "schema_yaml": c.schema_yaml,
            "rationale": c.proposal_rationale,
            "objectives": c.objectives_json,
            "field_scores": c.field_scores_json,
        }


# ---------- Evaluations ----------

def insert_evaluation(
    run_id: str,
    candidate_id: str,
    doc_name: str,
    split: str,
    f1_score: float,
    judge_score: float | None,
    validator_pass: bool,
    field_results: dict | None,
    raw_output: dict | None,
    error: str | None = None,
) -> None:
    with db_session() as s:
        s.add(OptEvaluation(
            run_id=run_id,
            candidate_id=candidate_id,
            doc_name=doc_name,
            split=split,
            f1_score=f1_score,
            judge_score=judge_score,
            validator_pass=validator_pass,
            field_results_json=field_results,
            raw_output_json=raw_output,
            error=error,
        ))


# ---------- Pareto archive ----------

def snapshot_archive(
    run_id: str,
    iteration_id: int | None,
    archive_entries: list[dict],
) -> None:
    """Snapshot the current Pareto archive. archive_entries: [{candidate_id, objectives}]"""
    with db_session() as s:
        for entry in archive_entries:
            s.add(OptParetoArchive(
                run_id=run_id,
                iteration_id=iteration_id,
                candidate_id=entry["candidate_id"],
                objectives_json=entry["objectives"],
            ))
    write_audit(run_id, "archive_snapshotted", {"size": len(archive_entries)})


def latest_archive(run_id: str) -> list[dict]:
    """Latest archive snapshot from a run, grouped by snapshot_at timestamp."""
    with db_session() as s:
        # Find max snapshot_at, then return all rows at that time
        latest_time_q = select(OptParetoArchive.snapshot_at).where(
            OptParetoArchive.run_id == run_id
        ).order_by(desc(OptParetoArchive.snapshot_at)).limit(1)
        latest_time = s.execute(latest_time_q).scalar_one_or_none()
        if latest_time is None:
            return []
        rows = s.execute(
            select(OptParetoArchive).where(
                OptParetoArchive.run_id == run_id,
                OptParetoArchive.snapshot_at == latest_time,
            )
        ).scalars().all()
        return [
            {"candidate_id": r.candidate_id, "objectives": r.objectives_json}
            for r in rows
        ]


# ---------- Audit log ----------

def write_audit(
    run_id: str,
    event_type: str,
    details: dict[str, Any] | None = None,
    actor: str = "system",
) -> None:
    try:
        with db_session() as s:
            s.add(OptAuditLog(
                run_id=run_id,
                event_type=event_type,
                actor=actor,
                details_json=details or {},
            ))
    except Exception as e:
        # Audit must never crash the optimizer
        logger.exception(f"Failed to write audit entry: {e}")


# ---------- Cost ledger ----------

def write_cost(
    run_id: str,
    agent_name: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
    estimated_dollars: float,
) -> None:
    try:
        with db_session() as s:
            s.add(OptCostLedger(
                run_id=run_id,
                agent_name=agent_name,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                estimated_dollars=estimated_dollars,
            ))
    except Exception as e:
        logger.exception(f"Failed to write cost entry: {e}")


def cost_totals(run_id: str) -> dict[str, float]:
    """Aggregate cost so far for a run."""
    from sqlalchemy import func
    with db_session() as s:
        q = select(
            func.coalesce(func.sum(OptCostLedger.input_tokens), 0),
            func.coalesce(func.sum(OptCostLedger.output_tokens), 0),
            func.coalesce(func.sum(OptCostLedger.estimated_dollars), 0.0),
        ).where(OptCostLedger.run_id == run_id)
        in_t, out_t, dollars = s.execute(q).one()
        return {
            "input_tokens": int(in_t or 0),
            "output_tokens": int(out_t or 0),
            "total_tokens": int((in_t or 0) + (out_t or 0)),
            "estimated_dollars": float(dollars or 0.0),
        }
