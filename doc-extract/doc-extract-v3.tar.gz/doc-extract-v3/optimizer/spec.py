"""Optimization specification.

The spec is the formal contract for a Ralph optimization run. It states
what "done" looks like - target metrics, budget ceilings, iteration limits.
Ralph's outer loop terminates when the spec is satisfied OR exhausted.

Specs are loaded from config/optimization.yaml under `spec:` and immutable
for the duration of a run. Audit log captures the spec text at run start.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class TargetMetric:
    """A single metric the spec requires to be satisfied."""
    name: str                              # e.g. "mean_field_f1", "min_field_f1"
    threshold: float
    direction: str = "maximize"            # "maximize" or "minimize"
    on: str = "dev"                        # "dev" or "test"

    def is_satisfied(self, value: float) -> bool:
        if self.direction == "maximize":
            return value >= self.threshold
        return value <= self.threshold


@dataclass
class Budget:
    """Soft budget caps. Enforcement is warn-and-continue (configured)."""
    max_dollars: float = 50.0
    max_total_tokens: int = 5_000_000
    max_wall_clock_seconds: int = 14400    # 4 hours


@dataclass
class OptimizationSpec:
    """Top-level run specification."""
    name: str
    description: str
    targets: list[TargetMetric]            # ALL must be satisfied to terminate
    budget: Budget
    ralph_max_iterations: int = 5
    gepa_max_iterations: int = 5
    candidates_per_gepa_iteration: int = 4
    convergence_patience: int = 2          # GEPA stops after N rounds without improvement
    pareto_objectives: list[str] = field(default_factory=lambda: [
        "mean_field_f1", "mean_judge_score", "validator_pass_rate",
    ])

    @classmethod
    def from_yaml(cls, path: str | Path, key: str = "spec") -> "OptimizationSpec":
        with open(path) as f:
            raw = yaml.safe_load(f)
        data = raw[key] if key in raw else raw
        return cls(
            name=data["name"],
            description=data.get("description", ""),
            targets=[
                TargetMetric(
                    name=t["name"],
                    threshold=t["threshold"],
                    direction=t.get("direction", "maximize"),
                    on=t.get("on", "dev"),
                )
                for t in data.get("targets", [])
            ],
            budget=Budget(**(data.get("budget") or {})),
            ralph_max_iterations=data.get("ralph_max_iterations", 5),
            gepa_max_iterations=data.get("gepa_max_iterations", 5),
            candidates_per_gepa_iteration=data.get("candidates_per_gepa_iteration", 4),
            convergence_patience=data.get("convergence_patience", 2),
            pareto_objectives=data.get("pareto_objectives") or [
                "mean_field_f1", "mean_judge_score", "validator_pass_rate",
            ],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "targets": [
                {"name": t.name, "threshold": t.threshold,
                 "direction": t.direction, "on": t.on}
                for t in self.targets
            ],
            "budget": {
                "max_dollars": self.budget.max_dollars,
                "max_total_tokens": self.budget.max_total_tokens,
                "max_wall_clock_seconds": self.budget.max_wall_clock_seconds,
            },
            "ralph_max_iterations": self.ralph_max_iterations,
            "gepa_max_iterations": self.gepa_max_iterations,
            "candidates_per_gepa_iteration": self.candidates_per_gepa_iteration,
            "convergence_patience": self.convergence_patience,
            "pareto_objectives": list(self.pareto_objectives),
        }

    def evaluate_satisfaction(self, metrics: dict[str, float]) -> tuple[bool, list[str]]:
        """Returns (all_satisfied, list_of_unmet_target_names)."""
        unmet: list[str] = []
        for target in self.targets:
            value = metrics.get(target.name)
            if value is None or not target.is_satisfied(value):
                unmet.append(target.name)
        return (len(unmet) == 0), unmet
