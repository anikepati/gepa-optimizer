"""Pareto domination logic.

A candidate dominates another if it is at least as good on all objectives
and strictly better on at least one. The Pareto archive contains only
non-dominated candidates - the trade-off frontier.
"""

from __future__ import annotations

from dataclasses import dataclass


# Objectives we know about. Add new ones here when adding new metrics.
MAXIMIZE_OBJECTIVES = {
    "mean_field_f1",
    "min_field_f1",
    "mean_judge_score",
    "validator_pass_rate",
    "doc_pass_rate",
}
MINIMIZE_OBJECTIVES = {
    "prompt_token_count",
    "extraction_latency_ms",
    "estimated_cost_per_doc",
}


def dominates(a: dict[str, float], b: dict[str, float], objectives: list[str]) -> bool:
    """True if a dominates b across the given objectives.

    Domination: at least as good on every objective, strictly better on at
    least one. Missing values are treated as worst-possible.
    """
    better_on_some = False
    for obj in objectives:
        a_val = a.get(obj)
        b_val = b.get(obj)
        if a_val is None and b_val is None:
            continue
        if a_val is None:
            return False
        if b_val is None:
            better_on_some = True
            continue

        if obj in MAXIMIZE_OBJECTIVES:
            if a_val < b_val:
                return False
            if a_val > b_val:
                better_on_some = True
        elif obj in MINIMIZE_OBJECTIVES:
            if a_val > b_val:
                return False
            if a_val < b_val:
                better_on_some = True
        else:
            # default: maximize unknown objectives
            if a_val < b_val:
                return False
            if a_val > b_val:
                better_on_some = True

    return better_on_some


def update_archive(
    archive: list[dict],
    new_candidate: dict,
    objectives: list[str],
) -> tuple[list[dict], bool]:
    """Add new_candidate to archive if non-dominated. Remove any candidates
    in archive that are now dominated by new_candidate.

    Each candidate dict must have an "objectives" key with the metrics dict.

    Returns (updated_archive, was_added).
    """
    new_obj = new_candidate["objectives"]

    # If any existing dominates new, reject
    for existing in archive:
        if dominates(existing["objectives"], new_obj, objectives):
            return archive, False

    # Remove existing entries dominated by new
    survivors = [
        existing for existing in archive
        if not dominates(new_obj, existing["objectives"], objectives)
    ]

    survivors.append(new_candidate)
    return survivors, True


def pick_best(
    archive: list[dict],
    primary_objective: str,
    tiebreakers: list[str] | None = None,
) -> dict | None:
    """Pick the single 'best' candidate from the archive by primary objective,
    with tiebreakers. For autonomous mode where we must commit to one schema."""
    if not archive:
        return None
    direction = -1 if primary_objective in MAXIMIZE_OBJECTIVES else 1

    def key(cand):
        primary = cand["objectives"].get(primary_objective, 0.0)
        secondaries = tuple(
            cand["objectives"].get(t, 0.0) * (-1 if t in MAXIMIZE_OBJECTIVES else 1)
            for t in (tiebreakers or [])
        )
        return (direction * primary,) + secondaries

    return min(archive, key=key)
