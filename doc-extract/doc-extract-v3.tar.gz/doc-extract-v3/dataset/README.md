# Dataset folder

Place your labeled examples here so the optimizer can use them.

## Structure

```
dataset/
├── documents/           # input docs - any of: .pdf, .docx, .png, .jpg, .tiff, .txt
│   ├── invoice_001.pdf
│   ├── invoice_002.pdf
│   └── ...
└── expected/            # ground-truth JSON, matched by filename stem
    ├── invoice_001.json
    ├── invoice_002.json
    └── ...
```

The optimizer pairs `documents/<name>.<ext>` with `expected/<name>.json`.
Files without a matching expected JSON are skipped (with a warning).

## What goes in expected/<name>.json

The exact JSON output you want the model to produce for that document.
The keys must match field names in `config/extraction_schema.yaml`.

See `expected/sample_invoice.json` for the format.

## How splits work

By default the optimizer uses 60/20/20 train/dev/test split, deterministic
by seed (42). Adjust in `config/pipeline.yaml` under `optimization:`.

The held-out test set is only evaluated at the very end - the optimizer
never sees it during iteration. This is what gives you a real estimate of
how the optimized prompt will perform on unseen documents.

## Running

```bash
python optimizer/optimize.py \
  --schema config/extraction_schema.yaml \
  --output-schema config/extraction_schema.optimized.yaml
```

Then use the optimized schema in production:

```bash
python main.py --schema config/extraction_schema.optimized.yaml
```
