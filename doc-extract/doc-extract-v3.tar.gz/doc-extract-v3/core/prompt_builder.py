"""Prompt construction from schema + template.

This module is the single place where extraction prompts are assembled.
Optimization (GEPA / DSPy / manual) should target the YAML inputs to this
module, not the rendering logic.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml

from core.schema import ExtractionSchema, FieldDefinition, FewShotExample


class PromptBuilder:
    def __init__(self, schema: ExtractionSchema, template_path: str | Path):
        self.schema = schema
        with open(template_path) as f:
            self.template = yaml.safe_load(f)

    # ----- Public API -----

    def build_system_prompt(self) -> str:
        return self.template["system_prompt"].format(
            document_type=self.schema.document_type
        )

    def build_extraction_prompt(
        self,
        document_text: str,
        use_chain_of_thought: bool = True,
    ) -> str:
        reasoning_key = (
            "reasoning_instructions_with_cot"
            if use_chain_of_thought
            else "reasoning_instructions_no_cot"
        )
        reasoning = self.template[reasoning_key].format(
            document_type=self.schema.document_type
        )

        return self.template["extraction_prompt"].format(
            document_type=self.schema.document_type,
            document_description=self.schema.description,
            field_definitions=self._render_field_definitions(),
            validation_rules=self._render_validation_rules(),
            few_shot_examples=self._render_few_shot_examples(),
            document_text=document_text,
            reasoning_instructions=reasoning,
        )

    # ----- Field rendering -----

    def _render_field_definitions(self) -> str:
        """Render fields in a structured, prompt-friendly format.

        We use markdown-like structure because LLMs parse it reliably,
        while keeping each field's rules clearly scoped.
        """
        lines: list[str] = []
        for fd in self.schema.fields:
            lines.append(self._render_one_field(fd, indent=0))
            lines.append("")
        return "\n".join(lines)

    def _render_one_field(self, fd: FieldDefinition, indent: int) -> str:
        prefix = "  " * indent
        parts: list[str] = []
        req = "REQUIRED" if fd.required else "optional"
        type_str = fd.type
        if fd.format:
            type_str = f"{fd.type} ({fd.format})"
        parts.append(f"{prefix}## `{fd.name}` [{type_str}, {req}]")
        parts.append(f"{prefix}{fd.description}")

        if fd.enum:
            parts.append(f"{prefix}Allowed values: {', '.join(fd.enum)}")

        if fd.extraction_rules:
            parts.append(f"{prefix}Rules:")
            for rule in fd.extraction_rules:
                parts.append(f"{prefix}- {rule}")

        if fd.examples:
            parts.append(f"{prefix}Examples: {', '.join(repr(e) for e in fd.examples)}")

        if fd.item_schema:
            parts.append(f"{prefix}Each array item has these sub-fields:")
            for sub in fd.item_schema:
                parts.append(self._render_one_field(sub, indent + 1))

        return "\n".join(parts)

    # ----- Validation rules rendering -----

    def _render_validation_rules(self) -> str:
        if not self.schema.validation_rules:
            return "(no additional validation constraints)"
        lines = []
        for vr in self.schema.validation_rules:
            sev = vr.severity.upper()
            tol = f" (tolerance: {vr.tolerance})" if vr.tolerance else ""
            lines.append(f"- [{sev}] {vr.name}: {vr.description}{tol}")
        return "\n".join(lines)

    # ----- Few-shot rendering -----

    def _render_few_shot_examples(self) -> str:
        if not self.schema.few_shot_examples:
            return "(no examples provided - rely on field definitions and rules)"
        blocks: list[str] = []
        for i, ex in enumerate(self.schema.few_shot_examples, 1):
            note = f"\nNotes: {ex.notes}" if ex.notes else ""
            output_json = json.dumps(ex.output, indent=2)
            blocks.append(
                f"### Example {i}{note}\n"
                f"Document excerpt:\n```\n{ex.input_excerpt}\n```\n"
                f"Expected output:\n```json\n{output_json}\n```"
            )
        return "\n\n".join(blocks)

    # ----- JSON schema export (for tool/structured output APIs) -----

    def get_output_schema(self) -> dict[str, Any]:
        return self.schema.to_json_schema()
