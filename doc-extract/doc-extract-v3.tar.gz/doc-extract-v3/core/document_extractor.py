"""Document text extraction with OCR fallback.

Strategy:
1. Try native text extraction (fast, free, lossless)
2. If extracted text is too sparse, fall back to Docling OCR
3. Return text + metadata (page count, OCR used, etc.)

Docling is imported lazily so the module loads even if docling isn't installed.
"""

from __future__ import annotations

import io
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ExtractedDocument:
    text: str
    page_count: int = 0
    ocr_used: bool = False
    extraction_method: str = ""
    tables: list[Any] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class DocumentExtractor:
    def __init__(
        self,
        strategy: str = "native_first",
        text_threshold_chars_per_page: int = 50,
        ocr_engine: str = "docling",
        ocr_config: dict | None = None,
    ):
        self.strategy = strategy
        self.text_threshold = text_threshold_chars_per_page
        self.ocr_engine = ocr_engine
        self.ocr_config = ocr_config or {}
        self._docling_converter = None  # lazy

    def extract(self, content: bytes, filename: str) -> ExtractedDocument:
        """Extract text from document bytes. Filename used for type detection."""
        ext = Path(filename).suffix.lower()

        if ext == ".txt":
            return ExtractedDocument(
                text=content.decode("utf-8", errors="replace"),
                page_count=1,
                extraction_method="text",
            )

        if ext == ".docx":
            return self._extract_docx(content)

        if ext == ".pdf":
            return self._extract_pdf(content)

        if ext in {".png", ".jpg", ".jpeg", ".tiff", ".tif"}:
            # Images always need OCR
            return self._ocr_extract(content, filename)

        raise ValueError(f"Unsupported file extension: {ext}")

    # ----- DOCX -----

    def _extract_docx(self, content: bytes) -> ExtractedDocument:
        from docx import Document  # python-docx

        doc = Document(io.BytesIO(content))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]

        # Tables - flatten with separators so structure is preserved for the LLM
        tables_text = []
        for table in doc.tables:
            rows = []
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                rows.append(" | ".join(cells))
            tables_text.append("\n".join(rows))

        full_text = "\n\n".join(paragraphs)
        if tables_text:
            full_text += "\n\n=== TABLES ===\n\n" + "\n\n---\n\n".join(tables_text)

        return ExtractedDocument(
            text=full_text,
            page_count=1,  # docx has no real page concept without rendering
            extraction_method="python-docx",
        )

    # ----- PDF -----

    def _extract_pdf(self, content: bytes) -> ExtractedDocument:
        if self.strategy == "ocr_always":
            return self._ocr_extract(content, "document.pdf")

        # Try native first
        native = self._extract_pdf_native(content)

        if self.strategy == "native_only":
            return native

        # native_first: check if we got enough text
        chars_per_page = (
            len(native.text) / native.page_count if native.page_count > 0 else 0
        )
        if chars_per_page >= self.text_threshold:
            return native

        logger.info(
            f"Native extraction yielded only {chars_per_page:.0f} chars/page, "
            f"falling back to OCR"
        )
        return self._ocr_extract(content, "document.pdf")

    def _extract_pdf_native(self, content: bytes) -> ExtractedDocument:
        """Native PDF text extraction using pypdf."""
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(content))
        pages_text = []
        for page in reader.pages:
            try:
                pages_text.append(page.extract_text() or "")
            except Exception as e:
                logger.warning(f"pypdf page extract failed: {e}")
                pages_text.append("")

        return ExtractedDocument(
            text="\n\n--- PAGE BREAK ---\n\n".join(pages_text),
            page_count=len(reader.pages),
            extraction_method="pypdf",
        )

    # ----- OCR -----

    def _ocr_extract(self, content: bytes, filename: str) -> ExtractedDocument:
        if self.ocr_engine == "docling":
            return self._ocr_docling(content, filename)
        raise ValueError(f"Unknown OCR engine: {self.ocr_engine}")

    def _ocr_docling(self, content: bytes, filename: str) -> ExtractedDocument:
        """OCR via Docling - layout-aware, preserves tables and reading order."""
        try:
            from docling.document_converter import DocumentConverter
        except ImportError:
            raise RuntimeError(
                "docling not installed. Install with: pip install docling"
            )

        if self._docling_converter is None:
            self._docling_converter = DocumentConverter()

        # Docling expects a path or stream; write to temp file
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=Path(filename).suffix, delete=False) as tmp:
            tmp.write(content)
            tmp_path = tmp.name

        try:
            result = self._docling_converter.convert(tmp_path)
            doc = result.document
            # Docling produces structured Markdown which preserves headings, tables, lists
            md_text = doc.export_to_markdown()

            return ExtractedDocument(
                text=md_text,
                page_count=getattr(doc, "num_pages", 1),
                ocr_used=True,
                extraction_method="docling",
                metadata={"docling_version": "latest"},
            )
        finally:
            Path(tmp_path).unlink(missing_ok=True)
