"""S3 / object store client.

Compatible with AWS S3, MinIO, and any S3-compatible store.
Uses boto3, configured for IRSA on OCP or env credentials locally.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

import boto3
from botocore.config import Config

logger = logging.getLogger(__name__)


@dataclass
class S3Object:
    bucket: str
    key: str
    size: int
    content_type: str | None = None


class S3Client:
    def __init__(
        self,
        endpoint_url: str | None = None,
        region: str = "us-east-1",
    ):
        config = Config(
            region_name=region,
            retries={"max_attempts": 3, "mode": "standard"},
            signature_version="s3v4",
        )
        # boto3 picks up creds from env vars, ~/.aws/credentials, or
        # IAM role for service accounts (IRSA) on OCP automatically
        self.client = boto3.client(
            "s3",
            endpoint_url=endpoint_url or None,
            config=config,
        )

    def list_documents(
        self,
        bucket: str,
        prefix: str = "",
        extensions: tuple[str, ...] = (".pdf", ".docx", ".png", ".jpg", ".jpeg", ".tiff", ".txt"),
    ) -> Iterator[S3Object]:
        """List document objects under prefix matching given extensions."""
        paginator = self.client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []) or []:
                key: str = obj["Key"]
                if key.endswith("/"):
                    continue
                if not key.lower().endswith(extensions):
                    continue
                yield S3Object(bucket=bucket, key=key, size=obj["Size"])

    def download_to_bytes(self, bucket: str, key: str) -> bytes:
        logger.info(f"Downloading s3://{bucket}/{key}")
        resp = self.client.get_object(Bucket=bucket, Key=key)
        return resp["Body"].read()

    def download_to_file(self, bucket: str, key: str, dest: str | Path) -> None:
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        self.client.download_file(bucket, key, str(dest))

    def upload_json(
        self,
        data: dict,
        bucket: str,
        key: str,
    ) -> None:
        body = json.dumps(data, indent=2, default=str).encode("utf-8")
        logger.info(f"Uploading result to s3://{bucket}/{key} ({len(body)} bytes)")
        self.client.put_object(
            Bucket=bucket,
            Key=key,
            Body=body,
            ContentType="application/json",
        )

    def upload_jsonl_line(
        self,
        bucket: str,
        key: str,
        record: dict,
        existing: bytes | None = None,
    ) -> None:
        """Append a JSONL record. Reads existing object, appends, writes back.

        Note: not safe under concurrent writers. Use separate keys per worker.
        """
        line = (json.dumps(record, default=str) + "\n").encode("utf-8")
        body = (existing or b"") + line
        self.client.put_object(
            Bucket=bucket,
            Key=key,
            Body=body,
            ContentType="application/x-ndjson",
        )

    def object_exists(self, bucket: str, key: str) -> bool:
        try:
            self.client.head_object(Bucket=bucket, Key=key)
            return True
        except self.client.exceptions.ClientError:
            return False
