"""Schema and config loading with environment variable interpolation."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


# ----- Environment variable interpolation -----

_ENV_PATTERN = re.compile(r"\$\{([A-Z_][A-Z0-9_]*)(?::-([^}]*))?\}")


def _interpolate_env(value: Any) -> Any:
    """Recursively replace ${VAR} or ${VAR:-default} with env values."""
    if isinstance(value, str):
        def replace(match: re.Match) -> str:
            var_name = match.group(1)
            default = match.group(2) or ""
            return os.environ.get(var_name, default)
        return _ENV_PATTERN.sub(replace, value)
    if isinstance(value, dict):
        return {k: _interpolate_env(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_interpolate_env(v) for v in value]
    return value


def load_yaml(path: str | Path) -> dict[str, Any]:
    """Load YAML file with env var interpolation."""
    with open(path) as f:
        raw = yaml.safe_load(f)
    return _interpolate_env(raw)


# ----- Typed schema objects -----

@dataclass
class FieldDefinition:
    name: str
    type: str
    description: str
    required: bool = False
    format: str | None = None
    enum: list[str] | None = None
    extraction_rules: list[str] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)
    item_schema: list[FieldDefinition] | None = None  # for array types

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FieldDefinition:
        item_schema = None
        if data.get("item_schema"):
            item_schema = [cls.from_dict(item) for item in data["item_schema"]]
        return cls(
            name=data["name"],
            type=data["type"],
            description=data.get("description", ""),
            required=data.get("required", False),
            format=data.get("format"),
            enum=data.get("enum"),
            extraction_rules=data.get("extraction_rules", []),
            examples=data.get("examples", []),
            item_schema=item_schema,
        )


@dataclass
class ValidationRule:
    name: str
    description: str
    severity: str = "warning"
    tolerance: float = 0.0


@dataclass
class FewShotExample:
    input_excerpt: str
    output: dict[str, Any]
    notes: str = ""


@dataclass
class ExtractionSchema:
    document_type: str
    description: str
    fields: list[FieldDefinition]
    validation_rules: list[ValidationRule] = field(default_factory=list)
    few_shot_examples: list[FewShotExample] = field(default_factory=list)

    @classmethod
    def from_yaml(cls, path: str | Path) -> ExtractionSchema:
        data = load_yaml(path)
        return cls(
            document_type=data["document_type"],
            description=data.get("description", ""),
            fields=[FieldDefinition.from_dict(f) for f in data["fields"]],
            validation_rules=[
                ValidationRule(**v) for v in data.get("validation_rules", []) or []
            ],
            few_shot_examples=[
                FewShotExample(**e) for e in data.get("few_shot_examples", []) or []
            ],
        )

    def to_json_schema(self) -> dict[str, Any]:
        """Convert to JSON Schema for structured LLM output."""
        return {
            "type": "object",
            "properties": {f.name: self._field_to_json_schema(f) for f in self.fields},
            "required": [f.name for f in self.fields if f.required],
        }

    def _field_to_json_schema(self, fd: FieldDefinition) -> dict[str, Any]:
        type_map = {
            "string": "string",
            "number": "number",
            "integer": "integer",
            "boolean": "boolean",
            "date": "string",  # ISO date as string
            "array": "array",
            "object": "object",
        }
        prop: dict[str, Any] = {
            "type": type_map.get(fd.type, "string"),
            "description": fd.description,
        }
        if fd.type == "date":
            prop["format"] = "date"
        if fd.enum:
            prop["enum"] = fd.enum
        if fd.type == "array" and fd.item_schema:
            prop["items"] = {
                "type": "object",
                "properties": {
                    item.name: self._field_to_json_schema(item)
                    for item in fd.item_schema
                },
                "required": [i.name for i in fd.item_schema if i.required],
            }
        if not fd.required:
            # allow null for optional fields
            prop = {"anyOf": [prop, {"type": "null"}]}
        return prop


# ----- Pipeline config -----

@dataclass
class PipelineConfig:
    """Runtime config - kept loose since it's mostly passed to clients."""
    raw: dict[str, Any]

    @classmethod
    def from_yaml(cls, path: str | Path) -> PipelineConfig:
        return cls(raw=load_yaml(path))

    def get(self, *keys: str, default: Any = None) -> Any:
        node = self.raw
        for k in keys:
            if not isinstance(node, dict) or k not in node:
                return default
            node = node[k]
        return node
