"""Local filesystem storage backend.

`location` is treated as the root folder. `key` is the relative path.
This lets you run the same pipeline locally without any S3 setup.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Iterator

from core.storage.base import StorageBackend, StoredObject

logger = logging.getLogger(__name__)


class LocalStorage(StorageBackend):
    def list_documents(
        self,
        location: str,
        prefix: str = "",
        extensions: tuple[str, ...] = (".pdf", ".docx", ".png", ".jpg", ".jpeg", ".tiff", ".txt"),
    ) -> Iterator[StoredObject]:
        root = Path(location).resolve()
        scan_dir = root / prefix if prefix else root
        if not scan_dir.exists():
            logger.warning(f"Folder does not exist: {scan_dir}")
            return
        for path in sorted(scan_dir.rglob("*")):
            if path.is_file() and path.suffix.lower() in extensions:
                rel = path.relative_to(root).as_posix()
                yield StoredObject(location=str(root), key=rel, size=path.stat().st_size)

    def download_to_bytes(self, location: str, key: str) -> bytes:
        path = Path(location) / key
        return path.read_bytes()

    def upload_json(self, data: dict, location: str, key: str) -> None:
        path = Path(location) / key
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2, default=str))
        logger.info(f"Wrote {path} ({path.stat().st_size} bytes)")

    def object_exists(self, location: str, key: str) -> bool:
        return (Path(location) / key).exists()

    def describe(self, location: str, key: str) -> str:
        return f"file://{Path(location).resolve()}/{key}"
