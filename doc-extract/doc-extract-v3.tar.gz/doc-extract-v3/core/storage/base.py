"""Storage backend abstraction.

Pipeline stages depend on this interface, not on S3 or local FS directly.
Concrete backends: S3Storage (boto3), LocalStorage (filesystem).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Iterator


@dataclass
class StoredObject:
    """A document in storage. `location` is bucket-or-folder, `key` is the path within."""
    location: str
    key: str
    size: int = 0


class StorageBackend(ABC):
    """Interface implemented by S3Storage and LocalStorage."""

    @abstractmethod
    def list_documents(
        self,
        location: str,
        prefix: str = "",
        extensions: tuple[str, ...] = (".pdf", ".docx", ".png", ".jpg", ".jpeg", ".tiff", ".txt"),
    ) -> Iterator[StoredObject]:
        ...

    @abstractmethod
    def download_to_bytes(self, location: str, key: str) -> bytes:
        ...

    @abstractmethod
    def upload_json(self, data: dict, location: str, key: str) -> None:
        ...

    @abstractmethod
    def object_exists(self, location: str, key: str) -> bool:
        ...

    @abstractmethod
    def describe(self, location: str, key: str) -> str:
        """Human-readable URI for logging, e.g. s3://bucket/key or file://path"""
        ...
