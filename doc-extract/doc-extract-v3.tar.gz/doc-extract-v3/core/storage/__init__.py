"""Storage factory - reads pipeline.yaml storage config and returns backend."""

from __future__ import annotations

from core.storage.base import StorageBackend
from core.storage.local import LocalStorage
from core.storage.s3 import S3Storage


def build_storage(config: dict) -> StorageBackend:
    """Build a storage backend from `storage:` section of pipeline.yaml.

    Expected config:
      storage:
        backend: local | s3
        s3:                 # only used if backend == s3
          endpoint_url: ...
          region: ...
    """
    backend = (config.get("backend") or "local").lower()
    if backend == "local":
        return LocalStorage()
    if backend == "s3":
        s3_cfg = config.get("s3", {}) or {}
        return S3Storage(
            endpoint_url=s3_cfg.get("endpoint_url") or None,
            region=s3_cfg.get("region", "us-east-1"),
        )
    raise ValueError(f"Unknown storage backend: {backend}")
