"""S3 storage backend - implements the StorageBackend interface."""

from __future__ import annotations

from typing import Iterator

from core.s3_client import S3Client
from core.storage.base import StorageBackend, StoredObject


class S3Storage(StorageBackend):
    def __init__(self, endpoint_url: str | None = None, region: str = "us-east-1"):
        self._s3 = S3Client(endpoint_url=endpoint_url, region=region)

    def list_documents(self, location, prefix="", extensions=(".pdf", ".docx", ".png", ".jpg", ".jpeg", ".tiff", ".txt")):
        for obj in self._s3.list_documents(location, prefix=prefix, extensions=extensions):
            yield StoredObject(location=obj.bucket, key=obj.key, size=obj.size)

    def download_to_bytes(self, location: str, key: str) -> bytes:
        return self._s3.download_to_bytes(location, key)

    def upload_json(self, data: dict, location: str, key: str) -> None:
        self._s3.upload_json(data, location, key)

    def object_exists(self, location: str, key: str) -> bool:
        return self._s3.object_exists(location, key)

    def describe(self, location: str, key: str) -> str:
        return f"s3://{location}/{key}"
