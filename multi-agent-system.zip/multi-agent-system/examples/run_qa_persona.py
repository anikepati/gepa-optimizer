"""
examples/run_qa_persona.py
Run the full QA persona end-to-end from the command line.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from db.db import init_db
from orchestrators.persona_orchestrator import PersonaOrchestrator
import json

def main():
    # Initialize database
    init_db()

    print("\n" + "="*60)
    print("  MULTI-AGENT SYSTEM — QA Persona Demo")
    print("="*60)

    orch = PersonaOrchestrator()

    # ---- Run QA Agent persona (EDR + RRO) ----
    result = orch.run(
        persona_name="qa-agent",
        user_input={
            "edr_account_number": "ACC-12345",
            "rro_property_ids":   ["PROP-001", "PROP-002", "PROP-003"]
        }
    )

    print("\n" + "="*60)
    print("  FINAL RESULTS")
    print("="*60)
    fv = result["final_verdict"]
    print(f"\n  Overall Verdict: {fv['overall_verdict']}")
    for v in fv["use_case_verdicts"]:
        print(f"  {v['use_case']:20s} → {v['verdict']} ({v['match_pct']}% match)")
        print(f"    {v['summary']}")

    print("\n  Full result saved to: output_qa_agent.json")
    with open("output_qa_agent.json", "w") as f:
        json.dump(result, f, indent=2, default=str)

if __name__ == "__main__":
    main()
