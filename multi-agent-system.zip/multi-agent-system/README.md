# Multi-Agent System
## Persona-Based Architecture — Google ADK + SQLite (upgradeable to PostgreSQL)

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the web UI
python ui/app.py
# Open http://localhost:5000

# 3. Or run examples directly
python examples/run_qa_persona.py
```

---

## Architecture — Three-Level Orchestration

```
User selects persona (e.g. "qa-agent")
  │
  ▼
Level 1: PersonaOrchestrator          orchestrators/persona_orchestrator.py
  │  Loads persona from SQLite
  │  Validates user input
  │  Chains use cases in order
  │
  ├──▶ Level 2: UseCaseOrchestrator   orchestrators/use_case_orchestrator.py
  │      Loads use case flow from SQLite
  │      Sequences agents step by step
  │      Resolves {{ }} template params
  │      Passes outputs between steps
  │
  │      ├──▶ Level 3: AgentOrchestrator   orchestrators/agent_orchestrator.py
  │      │      Loads skill (L2 progressive disclosure)
  │      │      Loads tool definition
  │      │      Binds resolved params to tool
  │      │      Executes skill via skill_executor
  │      │      Returns structured output
  │      │
  │      │      Calls: skills/skill_executor.py
  │      │               → fetch-source-data  → tools/sqlite_query_tool.py
  │      │               → fetch-source-data  → tools/mock_api_tool.py
  │      │               → compare-two-sources (pure logic)
  │      │               → verdict-summary    (pure logic)
  │
  └──▶ Consolidated Verdict (PASS / FAIL)
```

---

## Project Structure

```
multi-agent-system/
├── db/
│   ├── schema.sql              # SQLite schema
│   ├── seed_data.sql           # Tools, skills, use cases, personas + sample data
│   └── db.py                   # DB connection helpers
│
├── orchestrators/
│   ├── persona_orchestrator.py # Level 1
│   ├── use_case_orchestrator.py # Level 2
│   ├── agent_orchestrator.py   # Level 3
│   └── template_engine.py      # {{ }} resolver
│
├── skills/
│   └── skill_executor.py       # Skill implementations
│
├── tools/
│   ├── sqlite_query_tool.py    # SQLite query executor
│   └── mock_api_tool.py        # Mock REST API
│
├── ui/
│   ├── app.py                  # Flask web server
│   ├── templates/              # HTML templates
│   └── static/style.css        # Styles
│
├── examples/
│   └── run_qa_persona.py       # CLI demo
│
└── requirements.txt
```

---

## Registries (stored in SQLite)

| Registry | Table | Purpose |
|----------|-------|---------|
| Tools | `tools` | Reusable integrations (sqlite_query, mock_api_get) |
| Skills | `skills` | Templates: fetch-source-data, compare-two-sources, verdict-summary |
| Use Cases | `use_cases` | Workflows: edr-qa, rro-qa |
| Personas | `personas` | Roles: qa-agent, data-auditor |

---

## Migrating to PostgreSQL

1. Replace `db/db.py` with `asyncpg` connection
2. Update `schema.sql` syntax (UUID, gen_random_uuid(), JSONB)
3. Set `DATABASE_URL` environment variable
4. Everything else stays the same

---

## Sample Data

- **EDR records:** ACC-12345 (3 records), ACC-99999 (1 record)
- **RRO records:** PROP-001, PROP-002, PROP-003
- **Deliberate mismatch:** PROP-002 revenue differs between DB (20000) and API (99999) → RRO QA will FAIL
