"""
tools/sqlite_query_tool.py
Executes parameterized SQL queries against the local SQLite database.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from db.db import fetchall


def execute_sqlite_query(params: dict) -> list[dict]:
    """
    Execute a SQL SELECT query and return rows as list of dicts.
    params must contain 'query' and optionally 'params' (list of bind values).
    """
    query      = params.get("query", "")
    bind_params = params.get("params", [])

    # Flatten nested lists (e.g. property_ids passed as [[...]])
    flat_params = []
    for p in bind_params:
        if isinstance(p, list):
            flat_params.extend(p)
        else:
            flat_params.append(p)

    try:
        rows = fetchall(query, tuple(flat_params))
        return rows
    except Exception as e:
        return [{"error": str(e), "query": query}]
