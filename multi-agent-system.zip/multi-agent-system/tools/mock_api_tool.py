"""
tools/mock_api_tool.py
Simulates external REST API responses for EDR and RRO sources.
Replace with real aiohttp calls when connecting to live APIs.
"""

# Mock API data — simulates what external systems would return
_MOCK_EDR_API = {
    "ACC-12345": [
        {"record_id": "R001", "account_number": "ACC-12345", "field_a": "ValueA1", "field_b": "ValueB1", "amount": 1000.0, "status": "active"},
        {"record_id": "R002", "account_number": "ACC-12345", "field_a": "ValueA2", "field_b": "ValueB2", "amount": 2000.0, "status": "active"},
        {"record_id": "R003", "account_number": "ACC-12345", "field_a": "ValueA3", "field_b": "ValueB3", "amount": 3000.0, "status": "inactive"},
    ],
    "ACC-99999": [
        {"record_id": "R004", "account_number": "ACC-99999", "field_a": "ValueX1", "field_b": "ValueY1", "amount": 500.0, "status": "active"},
    ]
}

# RRO API has a deliberate mismatch on PROP-002 revenue to demonstrate FAIL
_MOCK_RRO_API = {
    "PROP-001": {"record_id": "P001-R1", "property_id": "PROP-001", "revenue": 10000.0, "period": "2024-Q1", "status": "active"},
    "PROP-002": {"record_id": "P002-R1", "property_id": "PROP-002", "revenue": 99999.0, "period": "2024-Q1", "status": "active"},  # ← mismatch
    "PROP-003": {"record_id": "P003-R1", "property_id": "PROP-003", "revenue": 30000.0, "period": "2024-Q1", "status": "active"},
}


def execute_mock_api(params: dict) -> list[dict]:
    """
    Simulate an API call based on the endpoint and params.
    Returns a list of records.
    """
    endpoint = params.get("endpoint", "")
    api_params = params.get("params", {})

    if endpoint == "edr_api":
        account = api_params.get("account_number", "")
        return _MOCK_EDR_API.get(account, [])

    elif endpoint == "rro_api":
        property_ids = api_params.get("property_ids", [])
        if isinstance(property_ids, str):
            property_ids = [p.strip() for p in property_ids.split(",")]
        return [_MOCK_RRO_API[pid] for pid in property_ids if pid in _MOCK_RRO_API]

    return [{"error": f"Unknown endpoint: {endpoint}"}]
