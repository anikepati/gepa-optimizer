"""
skills/skill_executor.py
Executes skill logic directly in Python (no LLM needed for demo).
In production, each skill would be run via a Google ADK LlmAgent.
Swap out execute_skill() to plug in real ADK calls.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from tools.sqlite_query_tool import execute_sqlite_query
from tools.mock_api_tool import execute_mock_api


def execute_skill(skill_name: str, tool_name: str | None, params: dict) -> any:
    """
    Route to the correct skill executor based on skill_name.
    In production: load skill instruction from Skills Registry,
    pass to Google ADK LlmAgent, return parsed response.
    """
    if skill_name == "fetch-source-data":
        return _fetch_source_data(tool_name, params)
    elif skill_name == "compare-two-sources":
        return _compare_two_sources(params)
    elif skill_name == "verdict-summary":
        return _verdict_summary(params)
    else:
        raise ValueError(f"Unknown skill: {skill_name}")


# -----------------------------------------------------------------------------
# Skill: fetch-source-data
# -----------------------------------------------------------------------------
def _fetch_source_data(tool_name: str | None, params: dict) -> list[dict]:
    """Fetch data from a tool and return raw records."""
    if tool_name == "sqlite_query":
        return execute_sqlite_query(params)
    elif tool_name == "mock_api_get":
        return execute_mock_api(params)
    else:
        raise ValueError(f"Unknown tool for fetch-source-data: {tool_name}")


# -----------------------------------------------------------------------------
# Skill: compare-two-sources
# -----------------------------------------------------------------------------
def _compare_two_sources(params: dict) -> dict:
    """Compare two lists of records field by field using a key field."""
    source_a  = params.get("source_a", [])
    source_b  = params.get("source_b", [])
    key_field = params.get("key_field", "id")

    # Build lookup maps
    map_a = {str(r.get(key_field)): r for r in source_a}
    map_b = {str(r.get(key_field)): r for r in source_b}

    matched    = []
    mismatched = []
    only_in_a  = []
    only_in_b  = []

    for key, rec_a in map_a.items():
        if key not in map_b:
            only_in_a.append(rec_a)
        else:
            rec_b = map_b[key]
            all_keys = set(rec_a.keys()) | set(rec_b.keys())
            diffs = {}
            for field in all_keys:
                val_a = rec_a.get(field)
                val_b = rec_b.get(field)
                if str(val_a) != str(val_b):
                    diffs[field] = {"source_a": val_a, "source_b": val_b}
            if diffs:
                mismatched.append({"key": key, "record_a": rec_a, "record_b": rec_b, "differences": diffs})
            else:
                matched.append(rec_a)

    for key, rec_b in map_b.items():
        if key not in map_a:
            only_in_b.append(rec_b)

    total     = len(map_a) + len(only_in_b)
    match_pct = (len(matched) / max(len(map_a), 1)) * 100

    return {
        "matched":    matched,
        "mismatched": mismatched,
        "only_in_a":  only_in_a,
        "only_in_b":  only_in_b,
        "summary": {
            "total_a":   len(map_a),
            "total_b":   len(map_b),
            "matched":   len(matched),
            "mismatched": len(mismatched),
            "only_in_a": len(only_in_a),
            "only_in_b": len(only_in_b),
            "match_pct": round(match_pct, 2)
        }
    }


# -----------------------------------------------------------------------------
# Skill: verdict-summary
# -----------------------------------------------------------------------------
def _verdict_summary(params: dict) -> dict:
    """Produce a PASS/FAIL verdict from a comparison result."""
    result     = params.get("comparison_result", {})
    use_case   = params.get("use_case_name", "Unknown")
    summary    = result.get("summary", {})

    total      = summary.get("total_a", 0)
    matched    = summary.get("matched", 0)
    mismatched = summary.get("mismatched", 0)
    only_in_a  = summary.get("only_in_a", 0)
    only_in_b  = summary.get("only_in_b", 0)
    match_pct  = summary.get("match_pct", 0.0)

    verdict = "PASS" if match_pct == 100.0 and only_in_a == 0 and only_in_b == 0 else "FAIL"

    details = ""
    if mismatched > 0:
        mismatch_list = result.get("mismatched", [])
        details = "; ".join(
            f"[{m['key']}] " + ", ".join(f"{k}: {v['source_a']}≠{v['source_b']}" for k, v in m["differences"].items())
            for m in mismatch_list[:5]
        )

    text_summary = (
        f"{use_case}: {total} records checked. "
        f"{matched} matched, {mismatched} mismatched, "
        f"{only_in_a} only in source A, {only_in_b} only in source B. "
        f"Match: {match_pct}%. "
        + (f"Mismatches: {details}. " if details else "")
        + f"Verdict: {verdict}."
    )

    return {
        "use_case":   use_case,
        "total":      total,
        "matched":    matched,
        "mismatched": mismatched,
        "only_in_a":  only_in_a,
        "only_in_b":  only_in_b,
        "match_pct":  match_pct,
        "verdict":    verdict,
        "summary":    text_summary
    }
