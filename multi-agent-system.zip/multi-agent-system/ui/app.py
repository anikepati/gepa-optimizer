"""
ui/app.py — Flask web UI for the multi-agent platform.
Run: python ui/app.py
Open: http://localhost:5000
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from flask import Flask, render_template, request, jsonify
from db.db import init_db, fetchall, fetchone, json_field
from orchestrators.persona_orchestrator import PersonaOrchestrator

app = Flask(__name__, template_folder="templates", static_folder="static")


@app.route("/")
def index():
    personas = fetchall("SELECT persona_name, description, input_schema FROM personas ORDER BY persona_name")
    for p in personas:
        p["input_schema"] = json.loads(p["input_schema"]) if isinstance(p["input_schema"], str) else p["input_schema"]
    return render_template("index.html", personas=personas)


@app.route("/api/persona/<name>")
def get_persona(name):
    persona = fetchone("SELECT * FROM personas WHERE persona_name = ?", (name,))
    if not persona:
        return jsonify({"error": "Persona not found"}), 404
    persona["input_schema"] = json_field(persona, "input_schema")
    persona["use_cases"]    = json_field(persona, "use_cases")
    return jsonify(persona)


@app.route("/api/run", methods=["POST"])
def run_persona():
    data         = request.json
    persona_name = data.get("persona_name")
    user_input   = data.get("user_input", {})

    if not persona_name:
        return jsonify({"error": "persona_name required"}), 400

    # Convert comma-separated property IDs to list
    if "rro_property_ids" in user_input:
        val = user_input["rro_property_ids"]
        if isinstance(val, str):
            user_input["rro_property_ids"] = [p.strip() for p in val.split(",") if p.strip()]

    try:
        orch   = PersonaOrchestrator()
        result = orch.run(persona_name=persona_name, user_input=user_input)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/registries")
def registries():
    tools    = fetchall("SELECT tool_name, tool_type, description FROM tools")
    skills   = fetchall("SELECT skill_name, description, allowed_tools FROM skills")
    cases    = fetchall("SELECT use_case_name, description FROM use_cases")
    personas = fetchall("SELECT persona_name, description FROM personas")
    return render_template("registries.html", tools=tools, skills=skills, use_cases=cases, personas=personas)


if __name__ == "__main__":
    init_db()
    print("\n✓ Multi-Agent System ready at http://localhost:5000\n")
    app.run(debug=True, port=5000)
