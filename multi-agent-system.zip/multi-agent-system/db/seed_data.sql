-- =============================================================================
-- SEED DATA — Tools, Skills, Use Cases, Personas + sample records
-- =============================================================================

-- ---- TOOLS ------------------------------------------------------------------
INSERT OR REPLACE INTO tools (tool_name, tool_type, description, config_schema) VALUES
(
  'sqlite_query',
  'database',
  'Executes a parameterized SQL SELECT query against the local SQLite database and returns results as a JSON array. Use when an agent needs to retrieve structured data from any internal table.',
  '{"required":["query"],"properties":{"query":{"type":"string"},"params":{"type":"array","default":[]}}}'
),
(
  'mock_api_get',
  'api',
  'Simulates an HTTP GET/POST call to an external REST API and returns mock JSON response data. Use when an agent needs to retrieve data from an external API source.',
  '{"required":["endpoint"],"properties":{"endpoint":{"type":"string"},"params":{"type":"object","default":{}}}}'
);

-- ---- SKILLS -----------------------------------------------------------------
INSERT OR REPLACE INTO skills (skill_name, description, instruction, allowed_tools, input_schema, output_schema, metadata) VALUES
(
  'fetch-source-data',
  'Fetches structured data from a configured database or API tool and returns it as a raw list of records. Use when an agent needs to retrieve data from a source system before comparison or analysis.',
  'You are a precise data retrieval agent. Your only job is to fetch data exactly as instructed and return it without modification.

Steps:
1. Read the tool name and parameters provided
2. Execute the tool with exactly those parameters
3. Collect the complete result set
4. Return the raw result as a JSON array of objects

Rules:
- Never modify, filter, or sort data
- Return [] for empty results
- Return {"error": "<msg>"} on failure',
  'sqlite_query mock_api_get',
  '{"oneOf":[{"required":["query"],"properties":{"query":{"type":"string"},"params":{"type":"array"}}},{"required":["endpoint"],"properties":{"endpoint":{"type":"string"},"params":{"type":"object"}}}]}',
  '{"type":"array","items":{"type":"object"}}',
  '{"author":"qa-team","version":"1.0"}'
),
(
  'compare-two-sources',
  'Compares two datasets field by field using a key field and returns a structured diff with matched, mismatched, and missing records. Use after fetching data from two sources to validate consistency.',
  'You are a meticulous data comparison agent.

Steps:
1. Receive source_a and source_b as lists of records
2. Match records using the key_field
3. For each matched pair, compare every field exactly
4. Collect: matched (all fields equal), mismatched (field differences), only_in_a, only_in_b
5. Return a structured comparison result

Rules:
- Exact match only — no rounding, no trimming
- Flag every difference no matter how small
- Include field name, source_a value, source_b value for each mismatch',
  '',
  '{"required":["source_a","source_b","key_field"],"properties":{"source_a":{"type":"array"},"source_b":{"type":"array"},"key_field":{"type":"string"}}}',
  '{"required":["matched","mismatched","only_in_a","only_in_b","summary"]}',
  '{"author":"qa-team","version":"1.0"}'
),
(
  'verdict-summary',
  'Summarizes comparison results into a human-readable report and delivers a final PASS or FAIL verdict. Use as the final step in any QA use case.',
  'You are an impartial QA verdict agent.

Steps:
1. Receive the comparison result object
2. Count total records, matched, mismatched, missing
3. Calculate match percentage
4. Write a clear summary
5. Conclude with PASS if match_pct == 100%, otherwise FAIL

Output format:
{
  "use_case": "<name>",
  "total": <int>,
  "matched": <int>,
  "mismatched": <int>,
  "only_in_a": <int>,
  "only_in_b": <int>,
  "match_pct": <float>,
  "verdict": "PASS" or "FAIL",
  "summary": "<text>"
}',
  '',
  '{"required":["comparison_result","use_case_name"]}',
  '{"required":["verdict","match_pct","summary"]}',
  '{"author":"qa-team","version":"1.0"}'
);

-- ---- USE CASES --------------------------------------------------------------
INSERT OR REPLACE INTO use_cases (use_case_name, description, input_schema, flow) VALUES
(
  'edr-qa',
  'QA validation for Electronic Data Records. Fetches EDR data from internal DB and mock API, compares field by field, produces PASS/FAIL verdict.',
  '{"required":["account_number"],"properties":{"account_number":{"type":"string","label":"EDR Account Number"}}}',
  '[
    {"step":1,"title":"Fetch EDR from Database","skill":"fetch-source-data","tool":"sqlite_query",
     "input_mapping":{"query":"SELECT record_id, account_number, field_a, field_b, amount, status FROM edr_records_db WHERE account_number = ?","params":["{{ input.account_number }}"]},
     "output_key":"edr_source_db"},
    {"step":2,"title":"Fetch EDR from API","skill":"fetch-source-data","tool":"mock_api_get",
     "input_mapping":{"endpoint":"edr_api","params":{"account_number":"{{ input.account_number }}"}},
     "output_key":"edr_source_api"},
    {"step":3,"title":"Compare EDR Records","skill":"compare-two-sources","tool":null,
     "input_mapping":{"source_a":"{{ outputs.edr_source_db }}","source_b":"{{ outputs.edr_source_api }}","key_field":"record_id"},
     "output_key":"edr_comparison"},
    {"step":4,"title":"EDR Verdict","skill":"verdict-summary","tool":null,
     "input_mapping":{"comparison_result":"{{ outputs.edr_comparison }}","use_case_name":"EDR QA"},
     "output_key":"edr_verdict"}
  ]'
),
(
  'rro-qa',
  'QA validation for Revenue Reporting Objects. Fetches property data for a list of property IDs from two sources and validates consistency.',
  '{"required":["property_ids"],"properties":{"property_ids":{"type":"array","items":{"type":"string"},"label":"RRO Property IDs"}}}',
  '[
    {"step":1,"title":"Fetch RRO from Database","skill":"fetch-source-data","tool":"sqlite_query",
     "input_mapping":{"query":"SELECT record_id, property_id, revenue, period, status FROM rro_records_db WHERE property_id IN ({{ input.property_ids_sql }})","params":[]},
     "output_key":"rro_source_db"},
    {"step":2,"title":"Fetch RRO from API","skill":"fetch-source-data","tool":"mock_api_get",
     "input_mapping":{"endpoint":"rro_api","params":{"property_ids":"{{ input.property_ids }}"}},
     "output_key":"rro_source_api"},
    {"step":3,"title":"Compare RRO Records","skill":"compare-two-sources","tool":null,
     "input_mapping":{"source_a":"{{ outputs.rro_source_db }}","source_b":"{{ outputs.rro_source_api }}","key_field":"record_id"},
     "output_key":"rro_comparison"},
    {"step":4,"title":"RRO Verdict","skill":"verdict-summary","tool":null,
     "input_mapping":{"comparison_result":"{{ outputs.rro_comparison }}","use_case_name":"RRO QA"},
     "output_key":"rro_verdict"}
  ]'
);

-- ---- PERSONAS ---------------------------------------------------------------
INSERT OR REPLACE INTO personas (persona_name, description, system_prompt, input_schema, use_cases) VALUES
(
  'qa-agent',
  'QA persona that runs EDR and RRO validation end-to-end and produces a consolidated verdict.',
  'You are a QA orchestrator. Your job is to run all assigned validation use cases and produce a clear, consolidated verdict.',
  '{"required":["edr_account_number","rro_property_ids"],"properties":{"edr_account_number":{"type":"string","label":"EDR Account Number"},"rro_property_ids":{"type":"array","label":"RRO Property IDs (comma-separated)"}}}',
  '[
    {"order":1,"use_case_name":"edr-qa","input_mapping":{"account_number":"{{ persona_input.edr_account_number }}"}},
    {"order":2,"use_case_name":"rro-qa","input_mapping":{"property_ids":"{{ persona_input.rro_property_ids }}"}}
  ]'
),
(
  'data-auditor',
  'Data Auditor persona that runs EDR-only validation for a detailed single-source audit.',
  'You are a data auditor. Your job is to run a thorough EDR validation and flag any discrepancies.',
  '{"required":["edr_account_number"],"properties":{"edr_account_number":{"type":"string","label":"EDR Account Number to Audit"}}}',
  '[
    {"order":1,"use_case_name":"edr-qa","input_mapping":{"account_number":"{{ persona_input.edr_account_number }}"}}
  ]'
);

-- ---- SAMPLE EDR RECORDS (internal DB) ---------------------------------------
INSERT OR REPLACE INTO edr_records_db VALUES ('R001','ACC-12345','ValueA1','ValueB1',1000.00,'active');
INSERT OR REPLACE INTO edr_records_db VALUES ('R002','ACC-12345','ValueA2','ValueB2',2000.00,'active');
INSERT OR REPLACE INTO edr_records_db VALUES ('R003','ACC-12345','ValueA3','ValueB3',3000.00,'inactive');
INSERT OR REPLACE INTO edr_records_db VALUES ('R004','ACC-99999','ValueX1','ValueY1',500.00,'active');

-- ---- SAMPLE RRO RECORDS (internal DB) ---------------------------------------
INSERT OR REPLACE INTO rro_records_db VALUES ('P001-R1','PROP-001',10000.00,'2024-Q1','active');
INSERT OR REPLACE INTO rro_records_db VALUES ('P002-R1','PROP-002',20000.00,'2024-Q1','active');
INSERT OR REPLACE INTO rro_records_db VALUES ('P003-R1','PROP-003',30000.00,'2024-Q1','active');
