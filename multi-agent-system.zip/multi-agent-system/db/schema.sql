-- =============================================================================
-- MULTI-AGENT SYSTEM — SQLite Schema
-- Four registries: tools, skills, use_cases, personas
-- =============================================================================

CREATE TABLE IF NOT EXISTS tools (
    tool_id    TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    tool_name  TEXT UNIQUE NOT NULL,
    tool_type  TEXT NOT NULL,
    description TEXT NOT NULL,
    config_schema TEXT NOT NULL,  -- JSON string
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS skills (
    skill_id      TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    skill_name    TEXT UNIQUE NOT NULL,  -- lowercase-hyphenated
    -- L1: always loaded
    description   TEXT NOT NULL,
    -- L2: loaded when activated
    instruction   TEXT NOT NULL,
    allowed_tools TEXT,
    compatibility TEXT,
    -- L3: loaded on demand
    input_schema  TEXT,   -- JSON string
    output_schema TEXT,   -- JSON string
    -- metadata
    metadata      TEXT DEFAULT '{}',
    license       TEXT DEFAULT 'Proprietary',
    created_at    TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS use_cases (
    use_case_id   TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    use_case_name TEXT UNIQUE NOT NULL,
    description   TEXT NOT NULL,
    input_schema  TEXT NOT NULL,  -- JSON string
    flow          TEXT NOT NULL,  -- JSON string: ordered list of steps
    source_md     TEXT,
    created_at    TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS personas (
    persona_id    TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    persona_name  TEXT UNIQUE NOT NULL,
    description   TEXT NOT NULL,
    system_prompt TEXT NOT NULL,
    input_schema  TEXT NOT NULL,  -- JSON string
    use_cases     TEXT NOT NULL,  -- JSON string: ordered list with input mappings
    created_at    TEXT DEFAULT (datetime('now'))
);

-- Sample data tables for mock tool execution
CREATE TABLE IF NOT EXISTS edr_records_db (
    record_id      TEXT PRIMARY KEY,
    account_number TEXT NOT NULL,
    field_a        TEXT,
    field_b        TEXT,
    amount         REAL,
    status         TEXT
);

CREATE TABLE IF NOT EXISTS rro_records_db (
    record_id    TEXT PRIMARY KEY,
    property_id  TEXT NOT NULL,
    revenue      REAL,
    period       TEXT,
    status       TEXT
);
