"""
db/db.py — SQLite connection and helper functions.
Swap DATABASE_PATH for a PostgreSQL connection string when ready to migrate.
"""
import sqlite3
import json
import os

DATABASE_PATH = os.environ.get("DATABASE_PATH", "multi_agent.db")


def get_connection():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db():
    """Initialize database with schema and seed data."""
    conn = get_connection()
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    seed_path   = os.path.join(os.path.dirname(__file__), "seed_data.sql")
    with open(schema_path) as f:
        conn.executescript(f.read())
    with open(seed_path) as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()
    print("✓ Database initialized")


def fetchone(query: str, params: tuple = ()) -> dict | None:
    conn = get_connection()
    row = conn.execute(query, params).fetchone()
    conn.close()
    return dict(row) if row else None


def fetchall(query: str, params: tuple = ()) -> list[dict]:
    conn = get_connection()
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def execute(query: str, params: tuple = ()):
    conn = get_connection()
    conn.execute(query, params)
    conn.commit()
    conn.close()


def json_field(row: dict, field: str):
    """Parse a JSON string field from a row dict."""
    val = row.get(field)
    if val and isinstance(val, str):
        return json.loads(val)
    return val or {}
