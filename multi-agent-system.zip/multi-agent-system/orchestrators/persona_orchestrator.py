"""
orchestrators/persona_orchestrator.py — Level 1
Receives persona selection + user inputs, chains use cases in order.
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from db.db import fetchone, json_field
from orchestrators.template_engine import resolve_params
from orchestrators.use_case_orchestrator import UseCaseOrchestrator


class PersonaOrchestrator:
    """
    Level 1 Orchestrator — the entry point.
    User selects a persona and provides inputs.

    Responsibilities:
    1. Load persona definition from Personas Registry
    2. Validate user input against persona's input_schema
    3. For each use case in order: resolve input mapping, call UseCaseOrchestrator
    4. Consolidate all verdicts into a final overall verdict
    5. Return complete results
    """

    def run(self, persona_name: str, user_input: dict) -> dict:
        print(f"\n[L1 PersonaOrchestrator] persona={persona_name}")
        print(f"[L1 PersonaOrchestrator] user_input={user_input}")

        # Load persona from registry
        persona = fetchone("SELECT * FROM personas WHERE persona_name = ?", (persona_name,))
        if not persona:
            raise ValueError(f"Persona '{persona_name}' not found in registry")

        use_cases    = json_field(persona, "use_cases")
        all_outputs  = {}
        uc_orch      = UseCaseOrchestrator()

        print(f"[L1 PersonaOrchestrator] running {len(use_cases)} use case(s)...")

        for uc_config in sorted(use_cases, key=lambda x: x["order"]):
            uc_name = uc_config["use_case_name"]
            print(f"\n[L1 PersonaOrchestrator] → use case {uc_config['order']}: {uc_name}")

            # Resolve input mapping: bind persona inputs to use case inputs
            uc_input = resolve_params(
                uc_config.get("input_mapping", {}),
                {"persona_input": user_input, "outputs": all_outputs}
            )

            # Call Level 2: Use Case Orchestrator
            uc_result = uc_orch.run(use_case_name=uc_name, input_data=uc_input)
            all_outputs[uc_name] = uc_result

        # Consolidate verdicts
        final_verdict = self._consolidate(all_outputs)

        print(f"\n[L1 PersonaOrchestrator] ✓ Overall verdict: {final_verdict['overall_verdict']}")

        return {
            "persona":          persona_name,
            "user_input":       user_input,
            "use_case_outputs": all_outputs,
            "final_verdict":    final_verdict
        }

    def _consolidate(self, all_outputs: dict) -> dict:
        """Collect individual PASS/FAIL verdicts and produce overall."""
        verdicts = []
        for uc_name, outputs in all_outputs.items():
            # Find the verdict output key (any key ending in _verdict)
            verdict_key = next((k for k in outputs if k.endswith("_verdict")), None)
            if verdict_key and isinstance(outputs[verdict_key], dict):
                v = outputs[verdict_key]
                verdicts.append({
                    "use_case":  uc_name,
                    "verdict":   v.get("verdict", "UNKNOWN"),
                    "match_pct": v.get("match_pct", 0),
                    "summary":   v.get("summary", "")
                })

        overall = "PASS" if verdicts and all(v["verdict"] == "PASS" for v in verdicts) else "FAIL"

        return {
            "overall_verdict": overall,
            "use_case_verdicts": verdicts
        }
