"""
orchestrators/agent_orchestrator.py — Level 3
Binds skill + tool + resolved params, instantiates and runs one agent.
In production: loads Google ADK LlmAgent with skill instruction + bound tool.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from db.db import fetchone, json_field
from skills.skill_executor import execute_skill


class AgentOrchestrator:
    """
    Level 3 Orchestrator.
    Called once per step by UseCaseOrchestrator.

    Responsibilities:
    1. Load skill instruction from Skills Registry (L2 progressive disclosure)
    2. Load tool definition from Tools Registry
    3. Bind resolved runtime parameters to the tool
    4. Execute the skill (via ADK LlmAgent in production, direct Python here)
    5. Return structured output
    """

    def run(self, agent_name: str, skill_name: str, tool_name: str | None, resolved_params: dict) -> any:
        print(f"      [L3 AgentOrchestrator] agent={agent_name}")
        print(f"      [L3 AgentOrchestrator] skill={skill_name} | tool={tool_name or 'none'}")

        # Step 1: L2 — Load skill from Skills Registry
        skill = fetchone("SELECT * FROM skills WHERE skill_name = ?", (skill_name,))
        if not skill:
            raise ValueError(f"Skill '{skill_name}' not found in skills registry")

        # Step 2: Load tool definition (if needed)
        tool = None
        if tool_name:
            tool = fetchone("SELECT * FROM tools WHERE tool_name = ?", (tool_name,))
            if not tool:
                raise ValueError(f"Tool '{tool_name}' not found in tools registry")

        # Step 3 + 4: Execute skill with bound params
        # In production: LlmAgent(instruction=skill['instruction'], tools=[bound_tool])
        result = execute_skill(skill_name, tool_name, resolved_params)

        print(f"      [L3 AgentOrchestrator] ✓ done")
        return result
