"""
orchestrators/use_case_orchestrator.py — Level 2
Sequences agents within a use case, passes outputs between steps.
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from db.db import fetchone, json_field
from orchestrators.template_engine import resolve_params
from orchestrators.agent_orchestrator import AgentOrchestrator


class UseCaseOrchestrator:
    """
    Level 2 Orchestrator.
    Called by PersonaOrchestrator for each use case.

    Responsibilities:
    1. Load use case flow from Use Cases Registry (PostgreSQL/SQLite)
    2. Iterate through steps in order
    3. Resolve {{ }} template parameters using input + prior outputs
    4. Call AgentOrchestrator (Level 3) for each step
    5. Collect and return all step outputs
    """

    def run(self, use_case_name: str, input_data: dict) -> dict:
        print(f"\n    [L2 UseCaseOrchestrator] use_case={use_case_name}")

        # Load use case from registry
        use_case = fetchone("SELECT * FROM use_cases WHERE use_case_name = ?", (use_case_name,))
        if not use_case:
            raise ValueError(f"Use case '{use_case_name}' not found in registry")

        flow     = json_field(use_case, "flow")
        outputs  = {}
        agent_orch = AgentOrchestrator()

        # Pre-process property_ids into SQL-safe format for RRO use case
        if "property_ids" in input_data:
            ids = input_data["property_ids"]
            if isinstance(ids, str):
                ids = [p.strip() for p in ids.split(",")]
            input_data["property_ids"] = ids
            # Build SQL IN clause placeholder
            input_data["property_ids_sql"] = ",".join(f"'{pid}'" for pid in ids)

        for step in sorted(flow, key=lambda x: x["step"]):
            print(f"\n      [L2] Step {step['step']}: {step['title']}")

            # Resolve {{ }} template parameters
            context = {"input": input_data, "outputs": outputs}
            resolved = resolve_params(step.get("input_mapping", {}), context)

            # Call Level 3: Agent Orchestrator
            result = agent_orch.run(
                agent_name    = f"agent_{step['output_key']}",
                skill_name    = step["skill"],
                tool_name     = step.get("tool"),
                resolved_params = resolved
            )

            outputs[step["output_key"]] = result

        print(f"\n    [L2 UseCaseOrchestrator] ✓ {use_case_name} complete")
        return outputs
