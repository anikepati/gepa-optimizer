"""
orchestrators/template_engine.py
Resolves {{ }} template expressions in parameter dicts.
"""
import re
import json
from typing import Any


def resolve_params(params: Any, context: dict) -> Any:
    """Recursively resolve {{ expr }} in any dict/list/string."""
    if isinstance(params, dict):
        return {k: resolve_params(v, context) for k, v in params.items()}
    if isinstance(params, list):
        return [resolve_params(i, context) for i in params]
    if isinstance(params, str):
        return _resolve_string(params, context)
    return params


def _resolve_string(value: str, context: dict) -> Any:
    pattern = re.compile(r"\{\{\s*(.+?)\s*\}\}")
    matches = pattern.findall(value)
    if not matches:
        return value
    # Whole string is one expression → return raw value
    if len(matches) == 1 and value.strip() == f"{{{{ {matches[0]} }}}}":
        return _lookup(matches[0], context)
    # Inline replacement
    def replace(m):
        result = _lookup(m.group(1), context)
        return json.dumps(result) if not isinstance(result, str) else result
    return pattern.sub(replace, value)


def _lookup(path: str, context: dict) -> Any:
    parts = path.split(".")
    val = context
    for part in parts:
        if isinstance(val, dict):
            val = val.get(part)
        else:
            return None
    return val
